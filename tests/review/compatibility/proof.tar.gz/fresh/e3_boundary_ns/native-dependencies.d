bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-revised.uX6BKM/compatibility/.build/acceptance/tb_acceptance_e3_boundary/794b607ce7355e10aecf1d92a8f627d2c1891071c077836fad7feaca0627c3a4/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
