bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-revised.uX6BKM/compatibility/.build/acceptance/tb_acceptance_e3_delayed/6c2a18b2e79731444d15d82ca9fc8e11134ade4e10dad6395e971004c71b8471/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
