bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-revised.uX6BKM/compatibility/.build/acceptance/tb_acceptance_cycle/2a612dbb9fa05ef1888a2b9b27fa4396d4c3a0ab596043481fc871cbc3302757/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
