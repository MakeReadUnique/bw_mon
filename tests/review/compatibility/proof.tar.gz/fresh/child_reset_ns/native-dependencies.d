bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-revised.uX6BKM/compatibility/.build/acceptance/tb_acceptance_ns/859c65218793f2878535dd92c4cb6221c14f9cd7212161494216c6fef350e2b9/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
