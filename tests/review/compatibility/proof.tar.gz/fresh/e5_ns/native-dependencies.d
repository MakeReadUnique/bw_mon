bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-revised.uX6BKM/compatibility/.build/acceptance/tb_acceptance_e5/2705edde960de5e969302102c41b4ffc89d7dff87d0ed75960780bd9bc197941/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
