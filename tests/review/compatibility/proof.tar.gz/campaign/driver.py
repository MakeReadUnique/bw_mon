#!/usr/bin/env python3
"""Explicitly invoked broad compatibility campaign; never schedules itself."""
import argparse
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import time

BASE = Path(__file__).resolve().parent
CHECKOUT = BASE.parent/'compatibility'
LOCK = BASE.parent/'qualification.lock'


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')


def git(*args):
    return subprocess.check_output(['git']+list(args), cwd=str(CHECKOUT), universal_newlines=True).strip()


def inputs():
    names = [p for p in (CHECKOUT/'rtl').rglob('*') if p.is_file()]
    names += list((CHECKOUT/'tests').glob('*.sv'))
    names += list((CHECKOUT/'tests/expect').glob('*.cfg'))
    names += list((CHECKOUT/'tests/acceptance').glob('*.py'))+[CHECKOUT/'tests/acceptance/scene.sv']
    names += [CHECKOUT/'tests/run.py', CHECKOUT/'tests/cases.json', CHECKOUT/'tests/scale/bounded.py']
    return {str(p.relative_to(CHECKOUT)):sha(p) for p in sorted(set(names))}


def component_audit(cases, before, log_path):
    text = log_path.read_text()
    records = re.findall(r'^(PASS|FAIL) ([^: ]+):', text, re.M)
    if len(records) != len(cases) or len(set(name for status,name in records)) != len(cases):
        raise AssertionError('component run does not contain every declared case exactly once')
    if {name for status,name in records if status == 'PASS'} != {c['name'] for c in cases}:
        raise AssertionError('component case failed or missing')
    out = BASE/'component-records';out.mkdir()
    result = []
    copied_tops = set()
    for case in cases:
        build = CHECKOUT/'.build/tests'/case['top']
        case_log = build/(case['name']+'.log')
        actual = case_log.read_text()
        if case.get('expect_error'):
            good = 'Fatal:' in actual and re.search(case['expect_error'],actual) and 'TB_PASS' not in actual and 'expected core error did not occur' not in actual
        else:
            good = 'TB_PASS' in actual and 'Fatal:' not in actual
        good = good and all(re.search(pattern,actual) is not None for pattern in case.get('expect_log',[]))
        good = good and all(len(re.findall(pattern,actual)) == count for pattern,count in case.get('expect_counts',{}).items())
        if not good:
            raise AssertionError('independent component log predicate: '+case['name'])
        dest = out/case['top'];dest.mkdir(exist_ok=True)
        shutil.copyfile(str(case_log),str(dest/case_log.name))
        result.append({'name':case['name'],'top':case['top'],'passed':True,'log_sha256':sha(case_log)})
        if case['top'] not in copied_tops:
            compile_log = build/'compile.log'
            if re.search(r'(?:Warning|Error)-\[',compile_log.read_text()):
                raise AssertionError('unexpected compile diagnostic: '+case['top'])
            for name in ('compile.log','source.sha256'):
                shutil.copyfile(str(build/name),str(dest/name))
            dependencies = sorted(build.rglob('bw_slot_settlement.d'))
            for n,dep in enumerate(dependencies):
                shutil.copyfile(str(dep),str(dest/('native-dependencies-'+str(n)+'.d')))
            binaries = {str(p.relative_to(build)):sha(p) for p in [build/'simv']+sorted(build.rglob('bw_slot_settlement.o')) if p.is_file()}
            save(dest/'binary-identities.json',binaries)
            copied_tops.add(case['top'])
    value={'status':'PASS','cases':len(result),'tops':len(copied_tops),'results':result,'source_input_count':len(before)}
    save(BASE/'component-verification.json',value)
    return value


def canonical_packets(log):
    prefixes = ('BW_EPISODE ','BW_PHASE ','BW_PHASE_METRICS ','BW_VARIATION ','BW_LAST_STEADY ',
                'BW_CHECK ','BW_SUMMARY ','BW_HINT_HIT ','BW_HINT_END ')
    values=[]
    for line in log.splitlines():
        if not line.startswith(prefixes):continue
        record=dict(re.findall(r'(\w+)=([^\s]+)',line))
        record.pop('cfg_file',None)
        values.append((line.split()[0],record))
    return sorted(json.dumps(v,sort_keys=True) for v in values)


def audit_e2e(before, historical, output):
    sys.path.insert(0,str(CHECKOUT/'tests/acceptance'))
    from model import PRIMARY,SUPPLEMENTAL
    expected=[s+'_'+b for s in PRIMARY for b in ('ns','cycle')]+[s+'_ns' for s in SUPPLEMENTAL]
    result=[];diffs=[]
    for name in expected:
        scene=output/name;old=historical/name
        comparison=json.loads((scene/'comparison.json').read_text())
        commands=json.loads((scene/'commands.json').read_text())
        if comparison['status'] != 'PASS' or comparison['human_review'] != 'PENDING':
            raise AssertionError('fresh scene failed or human status altered: '+name)
        for file,digest in commands['runtime_evidence']['source_snapshot_sha256'].items():
            if before[file] != digest:raise AssertionError('scene compiled different production: '+name+' '+file)
        if commands['base_revision'] != git('rev-parse','HEAD'):
            raise AssertionError('scene source revision mismatch: '+name)
        with tarfile.open(str(old/'trace.tar.gz'),'r:gz') as archive:
            for member in archive.getmembers():
                if member.name.endswith('.csv') or member.name == 'stimulus.txt':
                    original=archive.extractfile(member).read()
                    fresh=(scene/member.name).read_bytes()
                    if original != fresh:diffs.append({'scene':name,'file':member.name,'difference':'original/fresh bytes differ'})
            old_log=archive.extractfile('run.log').read().decode()
        if canonical_packets(old_log) != canonical_packets((scene/'run.log').read_text()):
            diffs.append({'scene':name,'file':'run.log','difference':'public final packets differ after cfg-path normalization'})
        if (old/'expect.cfg').read_bytes() != (scene/'expect.cfg').read_bytes():
            diffs.append({'scene':name,'file':'expect.cfg','difference':'configuration changed'})
        result.append({'scene':name,'status':'PASS','counts':comparison['counts'],'analysis_counts':comparison['analysis_counts'],
                       'report_reference':comparison['report_reference'],'source_head':commands['base_revision'],
                       'fsdb_sha256':sha(scene/'waves.fsdb'),'fsdb_bytes':(scene/'waves.fsdb').stat().st_size,
                       'human_review':'PENDING','source_archive_sha256':sha(scene/'source.tar.gz')})
    value={'status':'PASS' if not diffs else 'DIFFERENCES_REQUIRE_REVIEW','scenes':result,'scene_count':len(result),
           'differences':diffs,'human_review':'PENDING; historical approved assets remain unchanged',
           'comparison':'every original stimulus/16 public raw+receipt+window CSV and configured public final packet; only cfg path normalized'}
    save(BASE/'e2e-verification.json',value)
    return value


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-head',required=True)
    parser.add_argument('--run',action='store_true')
    args=parser.parse_args()
    if git('rev-parse','HEAD') != args.expected_head:raise AssertionError('checkout is not the reviewed frozen revision')
    cases=json.loads((CHECKOUT/'tests/cases.json').read_text())
    planned={'state':'PREPARED_ONLY','head':args.expected_head,'cases':len(cases),'tops':len({c['top'] for c in cases}),
             'commands':[['python3','tests/run.py','--no-cache'],['python3','tests/acceptance/run.py','--all']],
             'limits_seconds':{'components':7200,'e2e':1800},'condition':'explicit reviewed freeze and lock window; no automatic launch',
             'qualification_scope':'additional broad compatibility; outside revised quick/full timing budgets'}
    save(BASE/'plan.json',planned)
    if not args.run:return
    import fcntl
    with LOCK.open('a') as lock:
        wait=time.monotonic();fcntl.flock(lock.fileno(),fcntl.LOCK_EX);lock_wait=time.monotonic()-wait
        if git('rev-parse','HEAD') != args.expected_head or git('status','--porcelain','--','rtl','tests'):
            raise AssertionError('frozen source changed before launch')
        sys.path.insert(0,str(CHECKOUT/'tests/scale'))
        from bounded import execute_stage,tool_identity
        before=inputs();save(BASE/'source-before.json',before)
        freeze=json.loads((BASE.parent/'merger/production-freeze.json').read_text())
        if {k:v for k,v in before.items() if k.startswith('rtl/')} != freeze['production_sha256']:
            raise AssertionError('production inventory differs from independent freeze')
        save(BASE/'reviewed-production-freeze.json',freeze)
        tools,_=tool_identity();save(BASE/'tool-native-identities.json',tools)
        with tarfile.open(str(BASE/'source.tar.gz'),'w:gz') as archive:
            for name in before:archive.add(str(CHECKOUT/name),arcname=name,recursive=False)
        historical=BASE/'historical-checkout-assets';output=BASE/'fresh-e2e'
        if historical.exists() or output.exists():raise AssertionError('fresh campaign output already exists')
        historical_hashes={str(p.relative_to(CHECKOUT/'artifacts/acceptance')):sha(p) for p in (CHECKOUT/'artifacts/acceptance').rglob('*') if p.is_file()}
        save(BASE/'historical-assets-before.json',historical_hashes)
        shutil.move(str(CHECKOUT/'artifacts/acceptance'),str(historical));output.mkdir()
        (CHECKOUT/'artifacts/acceptance').symlink_to(output,target_is_directory=True)
        state={'state':'RUNNING','head':args.expected_head,'checkout_tree':git('rev-parse','HEAD^{tree}'),
               'lock_wait_seconds':lock_wait,'driver_sha256':sha(Path(__file__)), 'reviewed_production_inventory_sha256':freeze['production_inventory_sha256'], 'source_before_sha256':sha(BASE/'source-before.json'),'production_sha256':{k:v for k,v in before.items() if k.startswith('rtl/')},
               'case_count':len(cases),'e2e_expected_scenes':42,'concurrency':'serial qualification.lock','stages':{},
               'host':{'uname':subprocess.check_output(['uname','-a'],universal_newlines=True).strip(),
                       'load_start':Path('/proc/loadavg').read_text().strip(),'logical_cpus':os.cpu_count(),
                       'memory_start':subprocess.check_output(['free','-m'],universal_newlines=True).strip()},
               'environment':{key:os.environ.get(key,'') for key in ('VCS_HOME','VERDI_HOME','NOVAS_HOME','VCS_CC','VCS_CXX','CC','CXX','CFLAGS','LD_LIBRARY_PATH')}}
        save(BASE/'manifest.json',state)
        for name,command,limit in [('components',[sys.executable,str(CHECKOUT/'tests/run.py'),'--no-cache'],7200),
                                   ('e2e',[sys.executable,str(CHECKOUT/'tests/acceptance/run.py'),'--all'],1800)]:
            result=execute_stage(command,BASE/name,name,limit)
            state['stages'][name]=result;save(BASE/'manifest.json',state)
            if result['state'] != 'COMPLETED':
                state['state']=name.upper()+'_INCOMPLETE';save(BASE/'manifest.json',state);return 1
            if name=='components':state['component_verification']=component_audit(cases,before,BASE/name/(name+'.log'))
            else:state['e2e_verification']=audit_e2e(before,historical,output)
            save(BASE/'manifest.json',state)
        after=inputs();save(BASE/'source-after.json',after)
        native_after,_=tool_identity();save(BASE/'tool-native-identities-after.json',native_after)
        if tools != native_after:raise AssertionError('tool/native dependency identity changed during run')
        if before != after:raise AssertionError('source files changed during compatibility run')
        historical_after={str(p.relative_to(historical)):sha(p) for p in historical.rglob('*') if p.is_file()}
        if historical_hashes != historical_after:raise AssertionError('historical approved assets changed')
        state.update(state='VERIFIED' if state['e2e_verification']['status']=='PASS' else 'DIFFERENCES_REQUIRE_REVIEW',
                     source_unchanged=True,tool_native_identities_unchanged=True,historical_assets_unchanged=True,host_load_finish=Path('/proc/loadavg').read_text().strip(),human_review='PENDING for fresh outputs; no new human attestation')
        save(BASE/'manifest.json',state)
        print(state['state'],len(cases),'components;42 E2E; historical assets unchanged',flush=True)
        return int(state['state']!='VERIFIED')


if __name__=='__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        path=BASE/'manifest.json'
        if path.exists():
            state=json.loads(path.read_text());state.update(state='FAILED',error=repr(error));save(path,state)
        raise
