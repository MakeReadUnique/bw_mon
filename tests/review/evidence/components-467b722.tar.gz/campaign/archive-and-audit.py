#!/usr/bin/env python3
"""Audit exact merged-source full component campaign and pack lossless evidence."""
import datetime,gzip,hashlib,io,json,re,subprocess,tarfile
from pathlib import Path
ROOT=Path('/tmp/bw-mon-spec13-resume/components427-frozen-467b722')
EXT=Path(__file__).resolve().parent
OUT=EXT/'portable';OUT.mkdir(exist_ok=True)
sha=lambda data:hashlib.sha256(data).hexdigest()
def filehash(path):return sha(path.read_bytes())
freeze=json.loads((EXT/'freeze.json').read_text());full=EXT/'full';state=json.loads((full/'state.json').read_text())
assert state['state']=='VERIFIED' and state['cases']==state['passed_cases']==427 and state['compiled_top_groups']==168 and state['source_changed']==[]
assert (full/'source-before.json').read_bytes()==(full/'source-after.json').read_bytes()
for name,digest in freeze['rtl_sha256'].items():assert filehash(ROOT/name)==digest
for name,digest in freeze['native_header_sha256'].items():assert filehash(Path(name))==digest
cases=json.loads((ROOT/'tests/cases.json').read_text());tops={c['top'] for c in cases};assert len(cases)==427 and len(tops)==168
sources=sorted((ROOT/'rtl').glob('*.sv'),key=lambda p:(p.name!='bw_mon_pkg.sv',p.name))+sorted((ROOT/'rtl').glob('*.c'))
headers=sorted(p for p in (ROOT/'rtl').rglob('*') if p.suffix in {'.svh','.vh','.h'})
items={};runtime_warnings=[];runcases=[];toprecords=[]
for case in cases:
 build=ROOT/'.build/tests'/case['top'];log=build/(case['name']+'.log');text=log.read_text()
 if case.get('expect_error'):
  good='Fatal:' in text and re.search(case['expect_error'],text) is not None and 'TB_PASS' not in text and 'expected core error did not occur' not in text
 else:good='TB_PASS' in text and 'Fatal:' not in text
 assert good,('runtime',case['name'])
 assert all(re.search(p,text) is not None for p in case.get('expect_log',[])),('required log',case['name'])
 assert all(len(re.findall(p,text))==n for p,n in case.get('expect_counts',{}).items()),('log count',case['name'])
 if re.search(r'^Warning-\[',text,re.M):runtime_warnings.append(case['name'])
 assert log.stat().st_mtime >= (build/'source.sha256').stat().st_mtime,('runtime predates compile',case['name'])
 items['runtime/'+log.name]=log.read_bytes()
 runcases.append({'name':case['name'],'top':case['top'],'argv':[str(build/'simv'),'-no_save']+case.get('plusargs',[]),'cwd':str(build),'sha256':filehash(log),'expected_fatal':bool(case.get('expect_error')),'passed':True,'log':str(log)})
assert runtime_warnings==['report_unreadable'],runtime_warnings
assert 'Warning-[STASKW_CO]' in items['runtime/report_unreadable.log'].decode()
for top in sorted(tops):
 case=[c for c in cases if c['top']==top][-1];build=ROOT/'.build/tests'/top
 assert len({tuple(c.get('defines',[])) for c in cases if c['top']==top})==1
 files=sources+[ROOT/'tests'/n for n in case.get('sources',[])]+[ROOT/'tests'/(top+'.sv')]
 deps=files+headers
 digest=sha(str(ROOT).encode()+(ROOT/'tests/run.py').read_bytes()+json.dumps(case.get('defines',[])).encode()+b''.join(str(p).encode()+p.read_bytes() for p in deps))
 assert (build/'source.sha256').read_text()==digest,('cache digest',top)
 compilelog=(build/'compile.log').read_text();assert not re.search(r'(?:Warning|Error)-\[',compilelog),('compile diagnostics',top)
 native=build/'csrc/bw_slot_settlement.d';obj=build/'csrc/bw_slot_settlement.o';binary=build/'simv'
 native_deps=native.read_text().replace('\\\n',' ').split(':',1)[1].split()
 assert native_deps[0]==str(ROOT/'rtl/bw_slot_settlement.c') and set(native_deps[1:])==set(freeze['vendor_sdk_headers']),('native dependencies',top,native_deps)
 items['compile/'+top+'.log']=(build/'compile.log').read_bytes();items['stamps/'+top+'.sha256']=digest.encode();items['native/'+top+'.d']=native.read_bytes()
 sdk=Path(freeze['vendor_sdk_headers'][0]).parent
 compileargv=['vcs','-full64','-sverilog','-timescale=1ns/1fs','-debug_access+all','+incdir+'+str(ROOT/'rtl'),'+vpi','-CFLAGS','-I'+str(sdk)+(' -DBW_MON_TEST_FAULTS' if 'BW_MON_TEST_FAULTS' in case.get('defines',[]) else ''),'-assert','svaext','-top',top,'-o',str(binary)]+['+define+'+name for name in case.get('defines',[])]+[str(p) for p in files]
 toprecords.append({'top':top,'compile_argv_reconstructed_from_frozen_runner':compileargv,'cwd':str(build),'cache_digest':digest,'binary_sha256':filehash(binary),'native_object_sha256':filehash(obj),'native_dependencies_sha256':filehash(native),'compiler_diagnostics':0})
for name,digest in json.loads((full/'source-before.json').read_text()).items():
 assert filehash(ROOT/name)==digest,('consumed source changed',name);items['source/'+name]=(ROOT/name).read_bytes()
for p in full.iterdir():
 if p.is_file():items['campaign/'+p.name]=p.read_bytes()
items['freeze.json']=(EXT/'freeze.json').read_bytes()
items['campaign/shard-driver.py']=Path(freeze['runner']).read_bytes()
items['campaign/archive-and-audit.py']=Path(__file__).read_bytes()
commands={'note':'Actual shard argv/PIDs are in campaign/state.json. Compile/runtime argv here are exactly reconstructed from the unchanged frozen repository runner, checked source fingerprints, plusargs and per-top paths. Native object and simulator bytes are hashed but not copied.','cases':runcases,'tops':toprecords}
(EXT/'commands-audit.json').write_text(json.dumps(commands,indent=2,sort_keys=True)+'\n');items['campaign/commands-audit.json']=(EXT/'commands-audit.json').read_bytes()
# Carry the genuine before/after public regression logs and the pre-fix source
# separately; no old result is relabelled as the current source.
red=Path('/tmp/bw-mon-spec13-resume/review-fix-evidence')
for name in ['core-red.log','core-green.log','production-milestone.log','merger-targeted.log']:
 items['targeted/'+name]=(red/name).read_bytes()
oldcore=subprocess.check_output(['git','show','8e7543989c1dbacf90a86de0394a732c33dd0930:rtl/bw_stats_core.sv'],cwd=str(ROOT))
items['targeted/pre-fix-bw_stats_core.sv']=oldcore
items['targeted/source-context.json']=(json.dumps({'red_production_head':'8e7543989c1dbacf90a86de0394a732c33dd0930','pre_fix_core_sha256':sha(oldcore),'green_production_milestone':freeze['milestone'],'independent_targeted_production_merge':freeze['head'],'note':'Original RED/GREEN transcripts are historical captures. Current full source includes later unknown-last test coverage. Only pre-fix core production source is copied here; all17 other production files are unchanged. Current427 acceptance is source-qualified separately.'},indent=2)+'\n').encode()
filename='components-467b722.tar.gz';target=OUT/filename
with target.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=9) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as archive:
   for name,data in sorted(items.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;archive.addfile(info,io.BytesIO(data))
record={'source_head':freeze['head'],'source_tree':freeze['tree'],'production_milestone':freeze['milestone'],'cases':427,'top_groups':168,'source_unchanged':True,'source_files_verified':len(json.loads((full/'source-before.json').read_text())),'cache_stamps_verified':168,'runtime_contracts_verified':427,'native_build_records_verified':168,'native_transitive_header_hashes_verified':len(freeze['native_header_sha256']),'compiler_diagnostics':0,'expected_runtime_warning':{'case':'report_unreadable','code':'STASKW_CO','reason':'intentional absent cfg'},'independent_targeted_cases':8,'scope':'full component contracts only; scale and fresh waveform/human acceptance remain separate','archive':{'file':filename,'bytes':target.stat().st_size,'sha256':filehash(target),'files':{name:sha(data) for name,data in items.items()}},'archiver_sha256':filehash(Path(__file__)),'proprietary_header_or_binary_contents_copied':False,'verified_utc':datetime.datetime.utcnow().isoformat()+'Z'}
(OUT/'verification.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
(EXT/'final-audit.json').write_text(json.dumps({k:v for k,v in record.items() if k!='archive'},indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='archive'},indent=2))
