#!/usr/bin/env python3
"""Run the existing public component campaign by disjoint tops, preserving source evidence."""
import argparse,datetime,hashlib,json,re,subprocess,sys,time
from pathlib import Path

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def utc():return datetime.datetime.utcnow().isoformat()+'Z'
def snapshot(component_root):
    paths=[p for p in (component_root/'rtl').rglob('*') if p.is_file()]
    paths += [component_root/'tests/run.py',component_root/'tests/cases.json']
    paths += [p for p in (component_root/'tests').rglob('*') if p.is_file() and p.suffix in ('.sv','.svh','.vh','.cfg') and 'evidence' not in p.parts]
    return {str(p.relative_to(component_root)):sha(p) for p in sorted(set(paths))}
def save(p,value):p.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def main():
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('--worktree',type=Path,required=True);a.add_argument('--output',type=Path,required=True);a.add_argument('--workers',type=int,default=4);args=a.parse_args()
    root=args.worktree.resolve();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    cases=json.loads((root/'tests/cases.json').read_text());tops={}
    for c in cases:tops.setdefault(c['top'],[]).append(c['name'])
    bins=[dict(tops=[],names=[],weight=0.0) for _ in range(args.workers)]
    for top,names in sorted(tops.items(),key=lambda x:(-len(x[1]),x[0])):
        b=min(bins,key=lambda x:x['weight']);b['tops'].append(top);b['names']+=names;b['weight']+=1+0.03*len(names)
    before=snapshot(root);save(out/'source-before.json',before)
    state=dict(started_utc=utc(),root=str(root),head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=str(root),universal_newlines=True).strip(),source_status=subprocess.check_output(['git','status','--short'],cwd=str(root),universal_newlines=True),cases=len(cases),compiled_top_groups=len(tops),workers=args.workers,shards=[])
    running=[]
    for i,b in enumerate(bins):
        log=out/('shard-'+str(i)+'.log');f=log.open('w');cmd=[sys.executable,'-u',str(root/'tests/run.py')]+b['names'];p=subprocess.Popen(cmd,cwd=str(root),stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        row=dict(index=i,pid=p.pid,command=cmd,log=str(log),cases=len(b['names']),tops=b['tops'],state='RUNNING');state['shards'].append(row);running.append((p,f,row))
    save(out/'state.json',state);print('START '+str(out),flush=True)
    while any(p.poll() is None for p,_,_ in running):time.sleep(1)
    allgood=True
    for p,f,row in running:
        f.close();rc=p.wait();text=Path(row['log']).read_text();counts=re.findall(r'^(\d+)/(\d+) contract cases passed$',text,re.M);failures=re.findall(r'^FAIL ([^:]+):',text,re.M)
        good=rc==0 and counts and tuple(map(int,counts[-1]))==(row['cases'],row['cases']) and not failures
        row.update(state='PASSED' if good else 'FAILED',returncode=rc,summary=counts[-1] if counts else None,failures=failures);allgood=bool(good) and allgood
    after=snapshot(root);save(out/'source-after.json',after);changed=[p for p in sorted(set(before)|set(after)) if before.get(p)!=after.get(p)]
    state.update(finished_utc=utc(),source_changed=changed,all_passed=allgood and not changed,passed_cases=sum(r['cases'] for r in state['shards'] if r['state']=='PASSED'),state='VERIFIED' if allgood and not changed else 'FAILED_OR_SOURCE_CHANGED');save(out/'state.json',state)
    print(json.dumps(dict(state=state['state'],cases=state['cases'],passed_cases=state['passed_cases'],top_groups=len(tops),source_changed=changed,proof=str(out/'state.json'))),flush=True);return 0 if state['all_passed'] else 1
if __name__=='__main__':sys.exit(main())
