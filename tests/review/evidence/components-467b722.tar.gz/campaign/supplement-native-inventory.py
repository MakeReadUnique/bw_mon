#!/usr/bin/env python3
"""Read actual VCS native argv and supplement the original plain-M freeze."""
import datetime,hashlib,json,os,shlex,shutil,subprocess,time
from pathlib import Path
ROOT=Path('/tmp/bw-mon-spec13-resume/components427-frozen-467b722')
EXT=Path(__file__).resolve().parent
OUT=EXT/'native-postrun-supplement';OUT.mkdir(exist_ok=True)
sha=lambda data:hashlib.sha256(data).hexdigest()
def filehash(path):return sha(Path(path).read_bytes())
def stat_record(path):
 p=Path(path);s=p.stat();return {'path':str(p),'resolved_path':str(p.resolve()),'sha256':filehash(p),'size':s.st_size,'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns}
freeze_path=EXT/'freeze.json';freeze_bytes=freeze_path.read_bytes();freeze=json.loads(freeze_bytes.decode());state=json.loads((EXT/'full/state.json').read_text())
campaign_start=int(datetime.datetime.strptime(state['started_utc'],'%Y-%m-%dT%H:%M:%S.%fZ').replace(tzinfo=datetime.timezone.utc).timestamp()*10**9)
cases=json.loads((ROOT/'tests/cases.json').read_text());tops=sorted({c['top'] for c in cases});assert len(tops)==168
normalization={};groups=[];rows=[]
for top in tops:
 build=ROOT/'.build/tests'/top;log=build/'compile.log';lines=log.read_text().splitlines()
 matches=[(i+1,line,shlex.split(line)) for i,line in enumerate(lines) if line.startswith('gcc ') and ' -c ' in line and str(ROOT/'rtl/bw_slot_settlement.c') in line]
 assert len(matches)==1,(top,matches)
 number,line,argv=matches[0];assert argv.count('-O')==1 and argv[-2:]==['-c',str(ROOT/'rtl/bw_slot_settlement.c')]
 key=tuple(argv)
 if key not in normalization:
  index=len(groups);normalization[key]=index
  query=argv[:-2]+['-M',argv[-1]]
  completed=subprocess.run(query,cwd=str(build/'csrc'),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  assert completed.returncode==0 and not completed.stderr,(top,completed.stderr)
  dependency_file='actual-native-group-%d.full-M.d'%index;(OUT/dependency_file).write_bytes(completed.stdout)
  deps=completed.stdout.decode().replace('\\\n',' ').split(':',1)[1].split();assert deps[0]==str(ROOT/'rtl/bw_slot_settlement.c')
  headers=sorted(set(deps[1:]));assert len(headers)==50 and len(deps)==51
  assert set(headers)-set(freeze['native_header_sha256'])=={'/usr/include/bits/stdlib-bsearch.h'}
  assert not set(freeze['native_header_sha256'])-set(headers)
  groups.append({'index':index,'representative_top':top,'original_native_argv':argv,'original_cwd':str(build/'csrc'),'actual_compile_log_line':number,'actual_compile_log_sha256':filehash(log),'dependency_query_argv':query,'dependency_query_cwd':str(build/'csrc'),'dependency_query_returncode':completed.returncode,'dependency_query_stderr':completed.stderr.decode(),'dependency_file':dependency_file,'dependency_sha256':sha(completed.stdout),'header_paths':headers,'header_count':50,'tops':[]})
 group=groups[normalization[key]];group['tops'].append(top)
 rows.append({'top':top,'group_index':group['index'],'compile_log_line':number,'compile_log_line_text':line,'compile_log_sha256':filehash(log),'native_dependency_sha256':filehash(build/'csrc/bw_slot_settlement.d'),'native_object_sha256':filehash(build/'csrc/bw_slot_settlement.o'),'simulator_sha256':filehash(build/'simv')})
assert len(groups)==2 and {('-DBW_MON_TEST_FAULTS' in group['original_native_argv']) for group in groups}=={True,False}
assert groups[0]['header_paths']==groups[1]['header_paths']
headers=groups[0]['header_paths'];before={name:stat_record(name) for name in headers}
for name,digest in freeze['native_header_sha256'].items():assert before[name]['sha256']==digest
for name,info in before.items():assert max(info['mtime_ns'],info['ctime_ns'])<campaign_start,(name,'header changed during/after campaign')
compiler=stat_record(Path(shutil.which('gcc')).resolve());assert max(compiler['mtime_ns'],compiler['ctime_ns'])<campaign_start
version=subprocess.run(['gcc','--version'],stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert version.returncode==0
# Repeat both optimized dependency-only queries after taking stat/hash records.
# This does not compile code, relink a simulator or execute VCS.
for group in groups:
 completed=subprocess.run(group['dependency_query_argv'],cwd=group['dependency_query_cwd'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 assert completed.returncode==0 and not completed.stderr and sha(completed.stdout)==group['dependency_sha256']
after={name:stat_record(name) for name in headers};assert before==after
assert stat_record(Path(shutil.which('gcc')).resolve())==compiler
assert freeze_path.read_bytes()==freeze_bytes
record={'kind':'post-run metadata supplement; not a pre-run50-header freeze','recorded_utc':datetime.datetime.utcnow().isoformat()+'Z','source_head':freeze['head'],'source_tree':freeze['tree'],'original_freeze_sha256':sha(freeze_bytes),'original_plain_M_inventory_count':49,'original_plain_M_argv':['gcc','-M','-I'+str(Path(freeze['vendor_sdk_headers'][0]).parent),str(ROOT/'rtl/bw_slot_settlement.c')],'full_observed_native_flag_inventory_count':50,'added_header_paths':['/usr/include/bits/stdlib-bsearch.h'],'header_sha256':{name:info['sha256'] for name,info in before.items()},'header_file_stability':before,'file_stability_rechecked_after_dependency_queries':True,'all_header_mtime_and_ctime_precede_campaign_start':True,'campaign_started_utc':state['started_utc'],'campaign_start_epoch_ns':campaign_start,'campaign_finished_utc':state['finished_utc'],'compiler_binary':compiler,'compiler_version':version.stdout.decode(),'relevant_current_include_environment':{name:os.environ.get(name) for name in ['CPATH','C_INCLUDE_PATH','CPLUS_INCLUDE_PATH','OBJC_INCLUDE_PATH','GCC_EXEC_PREFIX','COMPILER_PATH']},'groups':groups,'actual_native_commands_verified':rows,'native_command_count':168,'native_dot_d_scope':'Original VCS .d files remain unchanged: source and2SDKheaders only; system headers are represented by this separate full-M inventory.','inference':'Actual recorded gcc commands include -O, so a plain gcc-M replay omits stdlib-bsearch.h. Dependency-only replays of both actual command variants show50 headers. Original49 hashes still match; all50 current file mtime/ctime and compiler mtime/ctime predate the actual campaign and stayed stable across replay. This retrospectively supplements dependency provenance; it is not a new simulation or a claim of a pre-run50-header snapshot.','simulation_or_native_rebuild_performed':False,'vendor_or_system_header_contents_copied':False}
(OUT/'native-full-flags-supplement.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps({'groups':len(groups),'actual_native_commands':len(rows),'full_headers':len(headers),'added_headers':record['added_header_paths'],'mtime_ctime_precede_campaign':True,'original_freeze_preserved':True,'output':str(OUT/'native-full-flags-supplement.json')}))
