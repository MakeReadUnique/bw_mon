bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-resume/components427-frozen-467b722/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
