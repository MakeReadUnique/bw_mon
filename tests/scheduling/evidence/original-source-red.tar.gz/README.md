# Original source RED regressions

Stable production base5cf489b (RTL byte-equal8de785c), three public-entry patterns,
six scheduling modes. The three ordinary module/Active controls pass, while the
three program/ReNBA modes fail their exact symptoms. No production edits yet.

Commands actually run:

    python3 tests/run.py settle_reset_module_nba settle_reset_program_renba settle_hint_active_clock settle_hint_program_renba
    python3 tests/run.py settle_phase_module_nba settle_phase_program_renba

First command2/4; second1/2 after correcting a log-pattern prefix (scope_kind
precedes scope in formal records). The phase ReNBA case wrongly confirms/emits a
steady fragment atT3 before its same-T reset, while the moduleNBA control emits
only the RESET_INTERRUPTED episode48B/6events and no phase. Hint cases also require
exactly one HIT and one END log; the original ReNBA run has zero HIT. This is
terminal diagnostic/positive-marker checking, not exit-status-only acceptance.
