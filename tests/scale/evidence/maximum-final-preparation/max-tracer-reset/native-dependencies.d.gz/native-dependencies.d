bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-resume/max30-final-complete-campaign/max-tracer-reset-e690e3704998f98f6182/builds/3253bab6383555f2efaeca58c9c5eab0ade7d4223677c41da69246571d4db773/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
