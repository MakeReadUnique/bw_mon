bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-resume/max30-final-complete-campaign/max-tracer-unknown-fef6a6b0ec486b8ea230/builds/8992887e5116bd02f225be5ec42ca38316c92e7c2c724626b878bbed8128412d/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
