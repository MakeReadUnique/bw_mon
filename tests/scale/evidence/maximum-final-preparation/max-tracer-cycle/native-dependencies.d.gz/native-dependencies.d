bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-resume/max30-final-complete-campaign/max-tracer-cycle-88044ee38b4877dbf8ea/builds/7a6e7a078a48e63727a64686294c9c06a85d5a0549f1ee1f865fddecf779235e/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
