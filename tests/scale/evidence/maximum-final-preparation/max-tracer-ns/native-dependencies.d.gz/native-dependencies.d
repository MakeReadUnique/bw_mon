bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-resume/max30-final-complete-campaign/max-tracer-ns-a4143e383995db719f46/builds/b95e4dbad357c051d540fe10817c32b6872a94438a5d43d724498aa431a92ff1/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
