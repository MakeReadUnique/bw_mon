package bw_scale_input_pkg;
  timeunit 1fs;timeprecision 1fs;
  typedef longint unsigned ref_u64;
  localparam ref_u64 POINTS=64'd32;
  localparam ref_u64 GROUPS=64'd24;
  localparam ref_u64 SCOPES=64'd56;
  localparam ref_u64 EDGES=64'd480;
  localparam ref_u64 END_TICKS=64'd240000000;
  localparam ref_u64 BASIS=64'd0;
  localparam ref_u64 WIDTH=64'd100;
  localparam ref_u64 STRIDE=64'd10;
  localparam ref_u64 RESET_START=64'd100100000;
  localparam ref_u64 RESET_END=64'd101100000;
  localparam ref_u64 UNKNOWN_TICK=64'd100250000;
  int variant=0; //0 baseline,1 unknown-size on p0,2 p0 known reset.
  int actual_fd=0,completed_scopes=0;
  bit observation_end=0;
typedef struct {
  ref_u64 seq;
  ref_u64 epoch;
  ref_u64 left;
  ref_u64 right;
  ref_u64 left_cycle;
  ref_u64 right_cycle;
  ref_u64 coverage_ticks;
  ref_u64 coverage_cycles;
  ref_u64 bytes;
  ref_u64 events;
  ref_u64 warmup;
  ref_u64 full;
  ref_u64 bytes_complete;
  ref_u64 events_complete;
  ref_u64 denominator_valid;
  ref_u64 window_valid;
  ref_u64 reset;
  real gbps;
  real bpc;
} ref_window_t;
typedef struct {
  ref_u64 seq;
  ref_u64 epoch;
  ref_u64 tick;
  ref_u64 edge_index;
  ref_u64 byte_inc;
  ref_u64 event_inc;
  ref_u64 bytes_complete;
  ref_u64 events_complete;
  ref_u64 reset_points;
  ref_u64 total_bytes;
  ref_u64 total_events;
  ref_u64 source_epoch;
} ref_raw_t;
  function automatic ref_u64 clock_tick(ref_u64 edge_index);
    ref_u64 k;k=edge_index;
    if(k<=480)return 250000+(k-1)*500000;k-=480;
    $fatal(1,"SCALE_REFERENCE_CLOCK edge_index=%0d",edge_index);return 0;
  endfunction
  function automatic ref_u64 rank_lt(ref_u64 tick);
    ref_u64 n,total;total=0;
    n=0;if(tick>250000)n=(tick-250000+500000-1)/500000;if(n>480)n=480;total+=n;
    return total;
  endfunction
  function automatic ref_u64 cardinality(bit is_group,int index);
    if(!is_group)return 1;
    case(index)
      0:return 3;
      1:return 4;
      2:return 5;
      3:return 6;
      4:return 7;
      5:return 8;
      6:return 9;
      7:return 10;
      8:return 4;
      9:return 4;
      10:return 4;
      11:return 4;
      12:return 4;
      13:return 4;
      14:return 4;
      15:return 4;
      16:return 4;
      17:return 4;
      18:return 4;
      19:return 4;
      20:return 4;
      21:return 4;
      22:return 4;
      23:return 6;
      default:$fatal(1,"SCALE_REFERENCE_GROUP index=%0d",index);
    endcase
    return 0;
  endfunction
  function automatic ref_u64 direct_count(int index);
    case(index)
      0:return 3;
      1:return 2;
      2:return 2;
      3:return 2;
      4:return 2;
      5:return 2;
      6:return 2;
      7:return 2;
      8:return 2;
      9:return 2;
      10:return 2;
      11:return 2;
      12:return 2;
      13:return 2;
      14:return 2;
      15:return 2;
      16:return 2;
      17:return 2;
      18:return 2;
      19:return 2;
      20:return 2;
      21:return 2;
      22:return 2;
      23:return 6;
      default:$fatal(1,"SCALE_REFERENCE_GROUP index=%0d",index);
    endcase
    return 0;
  endfunction
  function automatic bit affected(bit is_group,int index);
    if(!is_group)return index==0;
    case(index)
      0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22:return 1;
      default:return 0;
    endcase
  endfunction
  function automatic string expected_id(bit is_group,int index);
    if(is_group)return $sformatf("scale.g%0d",index);
    return $sformatf("tb_bw_scale.points[%0d].slot.mon",index);
  endfunction
  function automatic ref_u64 pre_reset_count();
    if(BASIS==0)return RESET_START/(STRIDE*1000000);
    return (rank_lt(RESET_START)-1)/STRIDE;
  endfunction
  function automatic ref_u64 publication_count(bit own);
    if(own && variant==2)begin
      if(BASIS==0)return pre_reset_count()+(END_TICKS-RESET_END)/(STRIDE*1000000);
      return pre_reset_count()+(EDGES-rank_lt(RESET_END)-1)/STRIDE;
    end
    if(BASIS==0)return END_TICKS/(STRIDE*1000000);
    return (EDGES-1)/STRIDE;
  endfunction
  function automatic ref_window_t interval_counts(ref_u64 m,bit hit,bit own,ref_u64 left,ref_u64 right);
    ref_window_t v;ref_u64 a,b,n;
    v.bytes=64*m*(rank_lt(right)-rank_lt(left));v.events=m*(rank_lt(right)-rank_lt(left));
    v.bytes_complete=1;v.events_complete=1;v.reset=0;
    if(hit && variant==1 && left<=UNKNOWN_TICK && UNKNOWN_TICK<right)begin v.bytes-=64;v.bytes_complete=0;end
    if(hit && variant==2)begin
      a=(left>RESET_START)?left:RESET_START;b=(right<RESET_END)?right:RESET_END;
      if(a<b)begin n=rank_lt(b)-rank_lt(a);v.bytes-=64*n;v.events-=n;v.reset=!own;end
    end
    return v;
  endfunction
  function automatic ref_window_t reference_window(ref_u64 seq,ref_u64 m,bit hit,bit own);
    ref_window_t v;ref_u64 rank,origin,anchor,left,right,lc,rc,cc;bit after_reset,full;
    after_reset=own && variant==2 && seq>pre_reset_count();
    rank=after_reset ? seq-pre_reset_count() : seq;origin=after_reset ? RESET_END : 0;
    lc=0;rc=0;cc=0;
    if(BASIS==0)begin
      right=origin+rank*STRIDE*1000000;left=(right-origin>=WIDTH*1000000)?right-WIDTH*1000000:origin;
      full=right-origin>=WIDTH*1000000;
    end else begin
      anchor=rank_lt(origin)+1;rc=anchor+rank*STRIDE;lc=(rc-anchor>=WIDTH)?rc-WIDTH:anchor;
      left=clock_tick(lc);right=clock_tick(rc);cc=rc-lc;full=cc==WIDTH;
    end
    v=interval_counts(m,hit,own,left,right);v.seq=seq;v.epoch=after_reset;v.left=left;v.right=right;
    v.left_cycle=lc;v.right_cycle=rc;v.coverage_ticks=right-left;v.coverage_cycles=cc;v.full=full;v.warmup=!full;
    v.denominator_valid=right>left;v.window_valid=full && v.bytes_complete && v.denominator_valid;
    v.gbps=v.denominator_valid ? real'(v.bytes)*1000000.0/real'(right-left) : 0;
    v.bpc=(cc!=0)?real'(v.bytes)/real'(cc):0;
    return v;
  endfunction
  function automatic ref_raw_t reference_raw(ref_u64 edge_index,ref_u64 m,bit hit,bit own);
    ref_raw_t r;ref_window_t v,total;ref_u64 tick,left;bit epoch;
    tick=clock_tick(edge_index);epoch=own && variant==2 && tick>=RESET_START;left=epoch ? RESET_END : 0;
    v=interval_counts(m,hit,own,tick,tick+1);
    if(epoch && tick<RESET_END)begin total.bytes=0;total.events=0;end
    else total=interval_counts(m,hit,own,left,tick+1);
    r.seq=edge_index;r.epoch=epoch;r.tick=tick;r.edge_index=edge_index;r.byte_inc=v.bytes;r.event_inc=v.events;
    r.bytes_complete=v.bytes_complete;r.events_complete=v.events_complete;
    r.reset_points=hit && variant==2 && RESET_START<=tick && tick<RESET_END;
    r.total_bytes=total.bytes;r.total_events=total.events;r.source_epoch=epoch;return r;
  endfunction
  function automatic bit close_real(real actual,real expected);
    return $abs(actual-expected)<=1e-9+1e-12*$abs(expected);
  endfunction
endpackage
