bw_slot_settlement.o: \
 /tmp/bw-mon-spec13/common29-newsource-3bba72c/common-ns-reset/builds/93b4fa677c296bfc7beef690d83ac618d1b07f1833a63a1eabf646e8bb730193/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
