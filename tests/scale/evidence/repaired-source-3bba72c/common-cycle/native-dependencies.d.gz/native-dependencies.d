bw_slot_settlement.o: \
 /tmp/bw-mon-spec13/common29-newsource-3bba72c/common-cycle/builds/f4e341f98836c17cfecd522005fc6e0884f1e19706f76947f299d99d43f7585b/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
