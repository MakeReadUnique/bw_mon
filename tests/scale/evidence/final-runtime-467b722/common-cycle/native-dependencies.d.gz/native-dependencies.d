bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-resume/common29-final-467b722-50732b4bc8365bd2/common-cycle/builds/4e103e1d730f7a8fd0cbd8e7bc7784d35b3ba0b9d0ecd39c70dafdd8a4b018e4/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
