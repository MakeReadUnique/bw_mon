bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-resume/common29-final-467b722-50732b4bc8365bd2/common-ns-unknown/builds/899171a1fd97cbff29ee8f271fc2004a1c0fa90a0fb15e12911522180ae687bf/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
