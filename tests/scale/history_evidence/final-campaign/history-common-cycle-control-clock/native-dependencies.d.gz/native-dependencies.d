bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-resume/history31-final-campaign/history-common-cycle-control-clock-026129de69e8eac6c941/builds/dfc636e5500db97262b87ced47023d9c2afa32955afa83c150f318ad94917531/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
