bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-resume/history31-final-campaign/history-common-cycle-long-dense-a47955bebc7cd9bf05d2/builds/ccd74223e95db411220e9e021177d9908dd60b491c83a27584caf81b4f701030/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
