bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-resume/history31-final-campaign/history-common-ns-long-dense-a817d8b7df44d6147256/builds/2c94d793abf6394b3587684a58932d9d7215606e6261832ec48d45f19a706cf4/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
