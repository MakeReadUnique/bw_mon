bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-resume/history31-final-campaign/history-common-cycle-short-dense-34ed4195e842731bb72c/builds/807ef555f93aa1a0ba98ecbd1ab62f3c5a75600c29b91ae5f2195454638a685b/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
