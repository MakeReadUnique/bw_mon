bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-resume/history31-final-campaign/history-common-ns-short-dense-47d5a0dcbc5f648782eb/builds/6027f19d27c93b92caa98ee157c642f96d9f2cdf8426a976bab7ea4b5407d8ff/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
