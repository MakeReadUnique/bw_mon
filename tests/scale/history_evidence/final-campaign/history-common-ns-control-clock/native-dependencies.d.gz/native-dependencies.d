bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-resume/history31-final-campaign/history-common-ns-control-clock-7eeb0029c9840fcaf438/builds/a1e2067d19abf2f821771c64aedce7adf0375dd9e42ba615dc4ffeeb10050d62/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
