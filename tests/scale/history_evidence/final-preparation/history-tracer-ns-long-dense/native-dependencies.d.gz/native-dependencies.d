bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-resume/history31-final-campaign/history-tracer-ns-long-dense-1c23a45afd7d325d5eed/builds/819b9e3aac142a6de97f08edd714e754453eeed11579ecd377e91aadddeb7310/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
