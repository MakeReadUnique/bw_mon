module bw_scale_checker(
  input bit is_group,
  input int scope_index,
  input string scope_id,
  input bit local_done,
  input int source_handle,
  input bw_mon_pkg::bw_record_t raw_record,
  input logic [63:0] accepted_record_seq,
  input logic [63:0] result_seq,
  input logic [63:0] stats_epoch,
  input logic [63:0] window_start_ticks,
  input logic [63:0] window_end_ticks,
  input logic [63:0] window_start_cycle,
  input logic [63:0] window_end_cycle,
  input logic [63:0] coverage_ticks,
  input logic [63:0] coverage_cycles,
  input logic [63:0] window_bytes,
  input logic [63:0] window_events,
  input logic [63:0] window_warmup,
  input logic [63:0] window_full,
  input logic [63:0] bytes_complete,
  input logic [63:0] events_complete,
  input logic [63:0] denominator_valid,
  input logic [63:0] window_valid,
  input logic [63:0] member_reset_coverage,
  input real bandwidth_gbps,
  input real bytes_per_cycle,
  input logic [63:0] total_bytes,total_events
);
  timeunit 1fs;timeprecision 1fs;
  import bw_mon_pkg::*;import bw_scale_input_pkg::*;
  ref_u64 windows=0,records=0,m;bit hit,own,done=0;
  ref_window_t window_snapshot;ref_raw_t raw_snapshot;
  initial begin wait(monitor_ready);m=cardinality(is_group,scope_index);hit=affected(is_group,scope_index);own=!is_group && scope_index==0;
    if(scope_id!=expected_id(is_group,scope_index))$fatal(1,"SCALE_ID_MISMATCH expected=%s actual=%s",expected_id(is_group,scope_index),scope_id);
  end
  always @(accepted_record_seq) if(monitor_ready && accepted_record_seq!=0)begin
    ref_raw_t e;records++;e=reference_raw(records,m,hit,own);
    if(raw_record.record_seq!==records ||
       accepted_record_seq!==e.seq ||
       stats_epoch!==e.epoch ||
       raw_record.timestamp_ticks!==e.tick ||
       raw_record.edge_index!==e.edge_index ||
       raw_record.byte_inc!==e.byte_inc ||
       raw_record.event_inc!==e.event_inc ||
       raw_record.bytes_complete!==e.bytes_complete ||
       raw_record.events_complete!==e.events_complete ||
       raw_record.reset_points!==e.reset_points ||
       total_bytes!==e.total_bytes ||
       total_events!==e.total_events ||
       raw_record.source_epoch!==e.source_epoch)
      $fatal(1,"SCALE_RAW_MISMATCH scope=%s checked=%0d receipt=%0d tick=%0d bytes=%0d/%0d events=%0d/%0d total_bytes=%0d/%0d total_events=%0d/%0d quality=%0b/%0b expected=%0b/%0b epoch=%0d/%0d",
        scope_id,records,accepted_record_seq,raw_record.timestamp_ticks,raw_record.byte_inc,e.byte_inc,raw_record.event_inc,e.event_inc,
        total_bytes,e.total_bytes,total_events,e.total_events,raw_record.bytes_complete,raw_record.events_complete,e.bytes_complete,e.events_complete,stats_epoch,e.epoch);
    raw_snapshot.seq=accepted_record_seq;
    raw_snapshot.epoch=stats_epoch;
    raw_snapshot.tick=raw_record.timestamp_ticks;
    raw_snapshot.edge_index=raw_record.edge_index;
    raw_snapshot.byte_inc=raw_record.byte_inc;
    raw_snapshot.event_inc=raw_record.event_inc;
    raw_snapshot.bytes_complete=raw_record.bytes_complete;
    raw_snapshot.events_complete=raw_record.events_complete;
    raw_snapshot.reset_points=raw_record.reset_points;
    raw_snapshot.total_bytes=total_bytes;
    raw_snapshot.total_events=total_events;
    raw_snapshot.source_epoch=raw_record.source_epoch;
  end
  always @(result_seq) if(monitor_ready && result_seq!=0)begin
    ref_window_t e;windows++;e=reference_window(windows,m,hit,own);
    if(result_seq!==e.seq ||
       stats_epoch!==e.epoch ||
       window_start_ticks!==e.left ||
       window_end_ticks!==e.right ||
       window_start_cycle!==e.left_cycle ||
       window_end_cycle!==e.right_cycle ||
       coverage_ticks!==e.coverage_ticks ||
       coverage_cycles!==e.coverage_cycles ||
       window_bytes!==e.bytes ||
       window_events!==e.events ||
       window_warmup!==e.warmup ||
       window_full!==e.full ||
       bytes_complete!==e.bytes_complete ||
       events_complete!==e.events_complete ||
       denominator_valid!==e.denominator_valid ||
       window_valid!==e.window_valid ||
       member_reset_coverage!==e.reset ||
       !close_real(bandwidth_gbps,e.gbps) ||
       !close_real(bytes_per_cycle,e.bpc))
      $fatal(1,"SCALE_WINDOW_MISMATCH scope=%s checked=%0d seq=%0d bounds=%0d/%0d expected=%0d/%0d bytes=%0d/%0d events=%0d/%0d quality=%0b/%0b expected=%0b/%0b gbps=%.17g/%.17g",
        scope_id,windows,result_seq,window_start_ticks,window_end_ticks,e.left,e.right,window_bytes,e.bytes,window_events,e.events,
        bytes_complete,events_complete,e.bytes_complete,e.events_complete,bandwidth_gbps,e.gbps);
    window_snapshot.seq=result_seq;
    window_snapshot.epoch=stats_epoch;
    window_snapshot.left=window_start_ticks;
    window_snapshot.right=window_end_ticks;
    window_snapshot.left_cycle=window_start_cycle;
    window_snapshot.right_cycle=window_end_cycle;
    window_snapshot.coverage_ticks=coverage_ticks;
    window_snapshot.coverage_cycles=coverage_cycles;
    window_snapshot.bytes=window_bytes;
    window_snapshot.events=window_events;
    window_snapshot.warmup=window_warmup;
    window_snapshot.full=window_full;
    window_snapshot.bytes_complete=bytes_complete;
    window_snapshot.events_complete=events_complete;
    window_snapshot.denominator_valid=denominator_valid;
    window_snapshot.window_valid=window_valid;
    window_snapshot.reset=member_reset_coverage;
    window_snapshot.gbps=bandwidth_gbps;
    window_snapshot.bpc=bytes_per_cycle;
  end
  always @(observation_end or local_done or windows or records)begin
    if(observation_end && local_done && !done && windows==publication_count(own) && records==EDGES)begin
      if(retained_frame_count(source_handle)!=0 || retained_control_count(source_handle)!=0)
        $fatal(1,"SCALE_TRANSPORT_NOT_RELEASED scope=%s",scope_id);
      done=1;
      $fdisplay(actual_fd,"%s,%0d,%s,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0.17g,%0.17g,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d",is_group?"group":"point",scope_index,scope_id,m,is_group?direct_count(scope_index):0,windows,records,window_snapshot.seq,window_snapshot.epoch,window_snapshot.left,window_snapshot.right,window_snapshot.left_cycle,window_snapshot.right_cycle,window_snapshot.coverage_ticks,window_snapshot.coverage_cycles,window_snapshot.bytes,window_snapshot.events,window_snapshot.warmup,window_snapshot.full,window_snapshot.bytes_complete,window_snapshot.events_complete,window_snapshot.denominator_valid,window_snapshot.window_valid,window_snapshot.reset,window_snapshot.gbps,window_snapshot.bpc,raw_snapshot.seq,raw_snapshot.epoch,raw_snapshot.tick,raw_snapshot.edge_index,raw_snapshot.byte_inc,raw_snapshot.event_inc,raw_snapshot.bytes_complete,raw_snapshot.events_complete,raw_snapshot.reset_points,raw_snapshot.total_bytes,raw_snapshot.total_events,raw_snapshot.source_epoch,0);
      completed_scopes++;
    end
  end
endmodule
