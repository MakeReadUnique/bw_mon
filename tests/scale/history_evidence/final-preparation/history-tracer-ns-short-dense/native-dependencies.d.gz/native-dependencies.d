bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-resume/history31-final-campaign/history-tracer-ns-short-dense-ccd6144781c9457f65dc/builds/dd16b0566f64c2f5f1d2b26262512f4040e6293322e7ed82b305f0cf52514d35/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
