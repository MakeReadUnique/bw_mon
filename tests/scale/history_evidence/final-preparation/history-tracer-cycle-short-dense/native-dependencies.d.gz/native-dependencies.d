bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-resume/history31-final-campaign/history-tracer-cycle-short-dense-5549966d6434a3cc902f/builds/bd8d562731d118cb2999491b1ee1fcdab142bcd85b0bdb31cd79ca21430d1576/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
