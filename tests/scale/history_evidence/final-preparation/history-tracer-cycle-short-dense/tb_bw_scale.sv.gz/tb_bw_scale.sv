module bw_scale_point #(parameter bw_mon_pkg::bw_protocol_t PROTOCOL=bw_mon_pkg::BW_VALID_ONLY,parameter bit DYNAMIC=0)
  (input logic clk,input int scope_index);
  timeunit 1fs;timeprecision 1fs;
  import bw_mon_pkg::*;import bw_scale_input_pkg::*;
  logic reset_n=1;logic [63:0] size_bytes=64;bit local_done=0;
  initial begin
    wait(monitor_ready);
    if(scope_index==0 && variant==1)begin #(UNKNOWN_TICK-1);size_bytes='x;#2;size_bytes=64;end
  end
  initial begin
    wait(monitor_ready);
    if(scope_index==0 && variant==2)begin #RESET_START;reset_n=0;#(RESET_END-RESET_START);reset_n=1;end
  end
  bw_point_mon #(.WINDOW_BASIS(bw_mon_pkg::bw_basis_t'(bw_scale_input_pkg::BASIS)),.WINDOW_WIDTH(bw_scale_input_pkg::WIDTH),.UPDATE_STRIDE(bw_scale_input_pkg::STRIDE),.FIXED_BYTES(64),.DYNAMIC_BYTES(DYNAMIC),.PROTOCOL(PROTOCOL),
    .CREDIT_ENABLE(PROTOCOL==BW_CREDIT),.CREDIT_CAPACITY(16),.CREDIT_INITIAL(16),.CREDIT_INITIAL_KNOWN(1),.CREDIT_RETURN_TIMING(BW_RETURN_NEXT_CYCLE),
    .BACKPRESSURE_ENABLE(PROTOCOL==BW_VALID_READY),.BACKPRESSURE_BASIS(bw_basis_t'(BASIS)),.BACKPRESSURE_THRESHOLD(8),
    .SHORTAGE_ENABLE(PROTOCOL==BW_CREDIT),.SHORTAGE_BASIS(bw_basis_t'(BASIS)),.SHORTAGE_THRESHOLD(8),.EPISODE_ENABLE(1),.SILENCE_THRESHOLD(60),.PHASE_ENABLE(1),.PHASE_N(3),.PHASE_MIN_SPAN(4),.PHASE_K(4),
    .PHASE_STEADY_ENTER_ABS(0),.PHASE_STEADY_ENTER_REL(0),.PHASE_STEADY_EXIT_ABS(0),.PHASE_STEADY_EXIT_REL(0),
    .PHASE_RMS_ENTER_ABS(1e-6),.PHASE_RMS_ENTER_REL(0),.PHASE_RMS_EXIT_ABS(1e-6),.PHASE_RMS_EXIT_REL(0),
    .PHASE_TREND_ABS(1),.PHASE_TREND_REL(0)) mon
    (.clk(clk),.reset_n(reset_n),.valid(1'b1),.ready(1'b1),.flitv(1'b1),.lcrdv(1'b1),.size_bytes(size_bytes),.size_known(1'b1));
  bw_scale_checker checker(.is_group(1'b0),
    .scope_index(scope_index),
    .scope_id(mon.scope_id),
    .local_done(local_done),
    .source_handle(mon.transport_source),
    .raw_record(mon.raw_record),
    .accepted_record_seq(mon.accepted_record_seq),
    .result_seq(64'(mon.result_seq)),
    .stats_epoch(64'(mon.stats_epoch)),
    .window_start_ticks(64'(mon.window_start_ticks)),
    .window_end_ticks(64'(mon.window_end_ticks)),
    .window_start_cycle(64'(mon.window_start_cycle)),
    .window_end_cycle(64'(mon.window_end_cycle)),
    .coverage_ticks(64'(mon.coverage_ticks)),
    .coverage_cycles(64'(mon.coverage_cycles)),
    .window_bytes(64'(mon.window_bytes)),
    .window_events(64'(mon.window_events)),
    .window_warmup(64'(mon.window_warmup)),
    .window_full(64'(mon.window_full)),
    .bytes_complete(64'(mon.bytes_complete)),
    .events_complete(64'(mon.events_complete)),
    .denominator_valid(64'(mon.denominator_valid)),
    .window_valid(64'(mon.window_valid)),
    .member_reset_coverage(64'(mon.member_reset_coverage)),
    .bandwidth_gbps(mon.bandwidth_gbps),
    .bytes_per_cycle(mon.bytes_per_cycle),
    .total_bytes(mon.total_bytes),
    .total_events(mon.total_events));
  always @(observation_end)if(observation_end)begin
    if(mon.raw_control.control_seq!=((scope_index==0 && variant==2)?3:1) ||
       mon.backpressure_supported!=(PROTOCOL==BW_VALID_READY) || mon.backpressure_enabled!=(PROTOCOL==BW_VALID_READY) ||
       mon.shortage_supported!=(PROTOCOL==BW_CREDIT) || mon.shortage_enabled!=(PROTOCOL==BW_CREDIT) ||
       mon.backpressure_hit_count!=0 || mon.shortage_hit_count!=0 ||
       ((PROTOCOL==BW_CREDIT) && (!mon.credit_trusted || mon.credit_anomaly || mon.credit_balance!=16)))
      $fatal(1,"SCALE_HINT_CONTROL_MISMATCH scope=%s protocol=%0d",mon.scope_id,PROTOCOL);
    local_done=1;
  end
endmodule
module bw_scale_group #(parameter string GROUP_ID="") (input logic clk,input int scope_index);
  timeunit 1fs;timeprecision 1fs;
  import bw_mon_pkg::*;import bw_scale_input_pkg::*;
  bit local_done=0;
  bw_group_mon #(.GROUP_ID(GROUP_ID),.WINDOW_BASIS(bw_mon_pkg::bw_basis_t'(bw_scale_input_pkg::BASIS)),.WINDOW_WIDTH(bw_scale_input_pkg::WIDTH),.UPDATE_STRIDE(bw_scale_input_pkg::STRIDE),.EPISODE_ENABLE(1),.SILENCE_THRESHOLD(60),.PHASE_ENABLE(1),.PHASE_N(3),.PHASE_MIN_SPAN(4),.PHASE_K(4),
    .PHASE_STEADY_ENTER_ABS(0),.PHASE_STEADY_ENTER_REL(0),.PHASE_STEADY_EXIT_ABS(0),.PHASE_STEADY_EXIT_REL(0),
    .PHASE_RMS_ENTER_ABS(1e-6),.PHASE_RMS_ENTER_REL(0),.PHASE_RMS_EXIT_ABS(1e-6),.PHASE_RMS_EXIT_REL(0),
    .PHASE_TREND_ABS(1),.PHASE_TREND_REL(0)) mon(.clk(clk),.reset_n(1'b1));
  bw_scale_checker checker(.is_group(1'b1),
    .scope_index(scope_index),
    .scope_id(mon.scope_id),
    .local_done(local_done),
    .source_handle(mon.transport_source),
    .raw_record(mon.raw_record),
    .accepted_record_seq(mon.accepted_record_seq),
    .result_seq(64'(mon.result_seq)),
    .stats_epoch(64'(mon.stats_epoch)),
    .window_start_ticks(64'(mon.window_start_ticks)),
    .window_end_ticks(64'(mon.window_end_ticks)),
    .window_start_cycle(64'(mon.window_start_cycle)),
    .window_end_cycle(64'(mon.window_end_cycle)),
    .coverage_ticks(64'(mon.coverage_ticks)),
    .coverage_cycles(64'(mon.coverage_cycles)),
    .window_bytes(64'(mon.window_bytes)),
    .window_events(64'(mon.window_events)),
    .window_warmup(64'(mon.window_warmup)),
    .window_full(64'(mon.window_full)),
    .bytes_complete(64'(mon.bytes_complete)),
    .events_complete(64'(mon.events_complete)),
    .denominator_valid(64'(mon.denominator_valid)),
    .window_valid(64'(mon.window_valid)),
    .member_reset_coverage(64'(mon.member_reset_coverage)),
    .bandwidth_gbps(mon.bandwidth_gbps),
    .bytes_per_cycle(mon.bytes_per_cycle),
    .total_bytes(mon.total_bytes),
    .total_events(mon.total_events));
  always @(observation_end)if(observation_end)begin
    if(mon.direct_member_count!=direct_count(scope_index) || mon.recursive_point_count!=cardinality(1,scope_index) ||
       mon.accepted_control_count!=cardinality(1,scope_index)+((variant==2 && affected(1,scope_index))?2:0))
      $fatal(1,"SCALE_GROUP_MEMBERS_CONTROLS scope=%s",mon.scope_id);
    for(int m=0;m<mon.direct_member_count;m++)
      if(acknowledged_frame_seq(mon.group_handle,m)!=EDGES)$fatal(1,"SCALE_ACK_MISMATCH scope=%s member=%0d",mon.scope_id,m);
    local_done=1;
  end
endmodule
module tb_bw_scale;
  timeunit 1fs;timeprecision 1fs;
  import bw_mon_pkg::*;import bw_scale_input_pkg::*;
  logic clk=0;bit deadline=0;string variant_name,actual_path;
  bw_mon_setup #(.EXPECTED_POINT_COUNT(POINTS),.EXPECTED_GROUP_COUNT(GROUPS)) setup();
  for(genvar p=0;p<POINTS;p++)begin:points
    bw_scale_point #(.PROTOCOL(bw_protocol_t'(p%3)),.DYNAMIC(p%2==0)) slot(.clk(clk),.scope_index(p));
  end
  for(genvar g=0;g<GROUPS;g++)begin:groups
    bw_scale_group #(.GROUP_ID($sformatf("scale.g%0d",g))) slot(.clk(clk),.scope_index(g));
  end
  initial begin
    if(!$value$plusargs("VARIANT=%s",variant_name))variant_name="baseline";
    case(variant_name)"baseline":variant=0;"unknown":variant=1;"reset":variant=2;default:$fatal(1,"SCALE_VARIANT_INVALID");endcase
    if(!$value$plusargs("ACTUAL=%s",actual_path))actual_path="actual.csv";
    actual_fd=$fopen(actual_path,"w");if(actual_fd==0)$fatal(1,"SCALE_ACTUAL_OPEN");
    $fdisplay(actual_fd,"kind,index,scope,cardinality,direct_members,checked_windows,checked_records,window_seq,window_epoch,window_left,window_right,window_left_cycle,window_right_cycle,window_coverage_ticks,window_coverage_cycles,window_bytes,window_events,window_warmup,window_full,window_bytes_complete,window_events_complete,window_denominator_valid,window_window_valid,window_reset,window_gbps,window_bpc,raw_seq,raw_epoch,raw_tick,raw_edge_index,raw_byte_inc,raw_event_inc,raw_bytes_complete,raw_events_complete,raw_reset_points,raw_total_bytes,raw_total_events,raw_source_epoch,diff_count");
    define_group("scale.g0",5);
    add_point_member("scale.g0","tb_bw_scale.points[0].slot.mon");
    add_point_member("scale.g0","tb_bw_scale.points[1].slot.mon");
    add_point_member("scale.g0","tb_bw_scale.points[2].slot.mon");
    add_point_member("scale.g0","tb_bw_scale.points[3].slot.mon");
    add_point_member("scale.g0","tb_bw_scale.points[4].slot.mon");
    define_group("scale.g1",5);
    add_point_member("scale.g1","tb_bw_scale.points[5].slot.mon");
    add_point_member("scale.g1","tb_bw_scale.points[6].slot.mon");
    add_point_member("scale.g1","tb_bw_scale.points[7].slot.mon");
    add_point_member("scale.g1","tb_bw_scale.points[8].slot.mon");
    add_point_member("scale.g1","tb_bw_scale.points[9].slot.mon");
    define_group("scale.g2",5);
    add_point_member("scale.g2","tb_bw_scale.points[10].slot.mon");
    add_point_member("scale.g2","tb_bw_scale.points[11].slot.mon");
    add_point_member("scale.g2","tb_bw_scale.points[12].slot.mon");
    add_point_member("scale.g2","tb_bw_scale.points[13].slot.mon");
    add_point_member("scale.g2","tb_bw_scale.points[14].slot.mon");
    define_group("scale.g3",5);
    add_point_member("scale.g3","tb_bw_scale.points[15].slot.mon");
    add_point_member("scale.g3","tb_bw_scale.points[16].slot.mon");
    add_point_member("scale.g3","tb_bw_scale.points[17].slot.mon");
    add_point_member("scale.g3","tb_bw_scale.points[18].slot.mon");
    add_point_member("scale.g3","tb_bw_scale.points[19].slot.mon");
    define_group("scale.g4",4);
    add_point_member("scale.g4","tb_bw_scale.points[20].slot.mon");
    add_point_member("scale.g4","tb_bw_scale.points[21].slot.mon");
    add_point_member("scale.g4","tb_bw_scale.points[22].slot.mon");
    add_point_member("scale.g4","tb_bw_scale.points[23].slot.mon");
    define_group("scale.g5",4);
    add_point_member("scale.g5","tb_bw_scale.points[24].slot.mon");
    add_point_member("scale.g5","tb_bw_scale.points[25].slot.mon");
    add_point_member("scale.g5","tb_bw_scale.points[26].slot.mon");
    add_point_member("scale.g5","tb_bw_scale.points[27].slot.mon");
    define_group("scale.g6",4);
    add_point_member("scale.g6","tb_bw_scale.points[28].slot.mon");
    add_point_member("scale.g6","tb_bw_scale.points[29].slot.mon");
    add_point_member("scale.g6","tb_bw_scale.points[30].slot.mon");
    add_point_member("scale.g6","tb_bw_scale.points[31].slot.mon");
    define_group("scale.g7",7);
    add_group_member("scale.g7","scale.g0");
    add_group_member("scale.g7","scale.g1");
    add_group_member("scale.g7","scale.g2");
    add_group_member("scale.g7","scale.g3");
    add_group_member("scale.g7","scale.g4");
    add_group_member("scale.g7","scale.g5");
    add_group_member("scale.g7","scale.g6");
    finish_configuration();wait(monitor_ready);
    if($time!=0 || measurement_start_ticks!=0)$fatal(1,"SCALE_READY_ORIGIN");
    $display("SCALE_RUN_START points=%0d groups=%0d scopes=%0d edges=%0d end_ticks=%0d basis=%0d W=%0d S=%0d variant=%s waves=0",POINTS,GROUPS,SCOPES,EDGES,END_TICKS,BASIS,WIDTH,STRIDE,variant_name);
    #END_TICKS;deadline<=1;observation_end=1;
    wait(completed_scopes==SCOPES);
    if($time!=END_TICKS || core_failure_pending())$fatal(1,"SCALE_FINAL_FAILURE");
    $fclose(actual_fd);
    $display("SCALE_PASS points=%0d groups=%0d scopes=%0d checked_raw=%0d end_ticks=%0d",POINTS,GROUPS,completed_scopes,EDGES*SCOPES,$time);
    $finish;
  end
  initial begin
    wait(monitor_ready);
    for(ref_u64 k=1;k<=EDGES;k++)begin
      #(clock_tick(k)-$time);clk=1;#1;clk=0;
    end
  end
  initial begin
    wait(monitor_ready);
    for(ref_u64 n=1;n*1000000000<END_TICKS;n++)begin
      #1000000000;
      $display("SCALE_PROGRESS at_ticks=%0d input_edges_before=%0d",$time,rank_lt($time));
    end
  end
  always @(deadline or completed_scopes)if(deadline)begin
    SCALE_ALL_SCOPES_SETTLED:assert final(completed_scopes==SCOPES)else end_failure();
  end
  function automatic void end_failure();
    if(completed_scopes!=SCOPES)$fatal(1,"SCALE_END_INCOMPLETE completed=%0d expected=%0d time=%0d",completed_scopes,SCOPES,$time);
  endfunction
endmodule
