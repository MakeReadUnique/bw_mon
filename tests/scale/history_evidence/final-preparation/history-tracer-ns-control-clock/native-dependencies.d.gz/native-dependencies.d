bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-resume/history31-final-campaign/history-tracer-ns-control-clock-e73411d3c707e0d2c0a1/builds/d39151ccaa51274ba056ce8935d69a6ef18daca921a5cfdb541ae48f142f199d/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
