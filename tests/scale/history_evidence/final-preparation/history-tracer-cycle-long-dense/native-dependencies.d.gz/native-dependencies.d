bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-resume/history31-final-campaign/history-tracer-cycle-long-dense-5624d4ec7450fbc7128f/builds/4e3707270cd7d2e133397b5b9659b2fb694c0ad58beaabb606efe7546bad6040/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
