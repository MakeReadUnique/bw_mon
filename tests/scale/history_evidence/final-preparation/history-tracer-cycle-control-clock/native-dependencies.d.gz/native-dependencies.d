bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-resume/history31-final-campaign/history-tracer-cycle-control-clock-bfebb1405e2752d94dcf/builds/7c5c29136592b06bb7011ecca357d6ede54f89b5febf1f6752c31cebc9b28bbe/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
