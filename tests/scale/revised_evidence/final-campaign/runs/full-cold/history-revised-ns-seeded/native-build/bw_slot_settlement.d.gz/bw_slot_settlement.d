bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-revised.uX6BKM/final-campaign/builds/b5dfb666e5829fab91c7363cc8f57f06f43b1eadb3787e654c83257a0fe0294d/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
