bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-revised.uX6BKM/final-campaign/builds/ec0dea86c11eb16fbc6113e72f91afbfc13fa9668255b494d22d0b53b137a188/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
