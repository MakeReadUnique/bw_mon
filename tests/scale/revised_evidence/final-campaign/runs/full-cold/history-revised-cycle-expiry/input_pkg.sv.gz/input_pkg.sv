package bw_history_input_pkg;
  timeunit 1fs; timeprecision 1fs;
  import bw_mon_pkg::*;
  int actual_fd=0,storage_fd=0,completed_scopes=0;
  bit observation_end=0;
  localparam bw_u64_t BASIS=64'd1;
  localparam bw_u64_t WIDTH=64'd257;
  localparam bw_u64_t STRIDE=64'd3;
  localparam bw_u64_t EDGES=64'd8192;
  localparam bw_u64_t WINDOWS=64'd2730;
  localparam bw_u64_t END_TICKS=64'd6145250000;
  localparam bw_u64_t EXPIRY=64'd1;
  localparam bw_u64_t SNAPSHOT_STRIDE=64'd512;
  function automatic bit close_real(real actual,real expected);
    return $abs(actual-expected)<=1e-9+1e-12*$abs(expected);
  endfunction
endpackage
