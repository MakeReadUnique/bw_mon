bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-revised.uX6BKM/final-campaign/builds/b4e02f58e1f5845beb1050c3a5098b3f6688dbc91421c2cc5b8254df4d962c15/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
