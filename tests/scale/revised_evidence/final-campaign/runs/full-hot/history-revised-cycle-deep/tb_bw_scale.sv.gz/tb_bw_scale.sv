module bw_history_point #(parameter int INDEX=0)(input logic clk,valid,known,input logic [63:0] size_bytes,input int scope_index);
  timeunit 1fs;timeprecision 1fs;
  import bw_mon_pkg::*;import bw_history_input_pkg::*;
  bw_point_mon #(.POINT_ID($sformatf("history.p%0d",INDEX)),.DYNAMIC_BYTES(1),.WINDOW_BASIS(bw_basis_t'(BASIS)),.WINDOW_WIDTH(WIDTH),.UPDATE_STRIDE(STRIDE),.EPISODE_ENABLE(1),.SILENCE_THRESHOLD(60),.PHASE_ENABLE(1),.PHASE_N(3),.PHASE_MIN_SPAN(2),.PHASE_K(4),
    .PHASE_STEADY_ENTER_ABS(0),.PHASE_STEADY_ENTER_REL(0),.PHASE_STEADY_EXIT_ABS(0),.PHASE_STEADY_EXIT_REL(0),
    .PHASE_RMS_ENTER_ABS(1e-6),.PHASE_RMS_ENTER_REL(0),.PHASE_RMS_EXIT_ABS(1e-6),.PHASE_RMS_EXIT_REL(0),
    .PHASE_TREND_ABS(1),.PHASE_TREND_REL(0)) mon
    (.clk(clk),.reset_n(1'b1),.valid(valid),.size_bytes(size_bytes),.size_known(known));
  bit local_done=0;
  bw_history_checker checker(.scope_index(scope_index),
    .local_done(local_done),
    .source_handle(mon.transport_source),
    .scope_id(mon.scope_id),
    .raw_record(mon.raw_record),
    .accepted_record_seq(mon.accepted_record_seq),
    .total_bytes(mon.total_bytes),
    .total_events(mon.total_events),
    .result_seq(64'(mon.result_seq)),
    .stats_epoch(64'(mon.stats_epoch)),
    .window_start_ticks(64'(mon.window_start_ticks)),
    .window_end_ticks(64'(mon.window_end_ticks)),
    .window_start_cycle(64'(mon.window_start_cycle)),
    .window_end_cycle(64'(mon.window_end_cycle)),
    .coverage_ticks(64'(mon.coverage_ticks)),
    .coverage_cycles(64'(mon.coverage_cycles)),
    .window_bytes(64'(mon.window_bytes)),
    .window_events(64'(mon.window_events)),
    .window_warmup(64'(mon.window_warmup)),
    .window_full(64'(mon.window_full)),
    .bytes_complete(64'(mon.bytes_complete)),
    .events_complete(64'(mon.events_complete)),
    .denominator_valid(64'(mon.denominator_valid)),
    .window_valid(64'(mon.window_valid)),
    .member_reset_coverage(64'(mon.member_reset_coverage)),
    .bandwidth_gbps(mon.bandwidth_gbps),
    .bytes_per_cycle(mon.bytes_per_cycle));
  int snapshot_seq=0;
  bw_u64_t last_snapshot_edge=0;
  task automatic dump_storage();
    snapshot_seq++;
    $fdisplay(storage_fd,"S %0d %0d %0d %0d %0d %0d",scope_index,snapshot_seq,$time,
      mon.accepted_record_seq,mon.window_start_ticks,mon.window_start_cycle);
    foreach(mon.core.history[i])begin
      $fdisplay(storage_fd,"E %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",
        scope_index,snapshot_seq,mon.core.history[i].first_ticks,mon.core.history[i].first_edge,
        mon.core.history[i].count,mon.core.history[i].step_ticks,mon.core.history[i].step_edges,
        mon.core.history[i].byte_inc,mon.core.history[i].event_inc,mon.core.history[i].bytes_complete,
        mon.core.history[i].events_complete,mon.core.history[i].has_reset,mon.core.history[i].last_ticks,mon.core.history[i].last_edge);
    end
    foreach(mon.core.clock_runs[i])begin
      $fdisplay(storage_fd,"C %0d %0d %0d %0d %0d %0d %0d",scope_index,snapshot_seq,
        mon.core.clock_runs[i].first_ticks,mon.core.clock_runs[i].first_edge,mon.core.clock_runs[i].count,
        mon.core.clock_runs[i].step_ticks,mon.core.clock_runs[i].last_ticks);
    end
    $fdisplay(storage_fd,"Z %0d %0d",scope_index,snapshot_seq);
  endtask
  always @(observation_end or mon.result_seq or mon.accepted_record_seq)
    if(observation_end && mon.result_seq==WINDOWS && mon.accepted_record_seq==EDGES && !local_done)
      begin dump_storage();local_done=1;end
  always @(mon.accepted_record_seq or mon.result_seq)if(monitor_ready)begin
    int ep_count,ph_count;
    ep_count=0;ph_count=0;
    foreach(mon.core.episode_pending_samples[i])ep_count+=mon.core.episode_pending_samples[i].count;
    foreach(mon.core.phase_pending_samples[i])ph_count+=mon.core.phase_pending_samples[i].count;
    checker.observe_storage(mon.core.history.size(),mon.core.clock_runs.size(),mon.core.phase_samples.size(),
      mon.core.episode_pending_samples.size(),ep_count,mon.core.phase_pending_samples.size(),ph_count);
    if(SNAPSHOT_STRIDE!=0 && mon.accepted_record_seq!=0 && mon.accepted_record_seq%SNAPSHOT_STRIDE==0 &&
       last_snapshot_edge!=mon.accepted_record_seq)begin
      dump_storage();last_snapshot_edge=mon.accepted_record_seq;
    end
  end
endmodule
module bw_history_group(input logic clk,input int scope_index);
  timeunit 1fs;timeprecision 1fs;
  import bw_mon_pkg::*;import bw_history_input_pkg::*;
  bw_group_mon #(.GROUP_ID("history.group"),.WINDOW_BASIS(bw_basis_t'(BASIS)),.WINDOW_WIDTH(WIDTH),.UPDATE_STRIDE(STRIDE),.EPISODE_ENABLE(1),.SILENCE_THRESHOLD(60),.PHASE_ENABLE(1),.PHASE_N(3),.PHASE_MIN_SPAN(2),.PHASE_K(4),
    .PHASE_STEADY_ENTER_ABS(0),.PHASE_STEADY_ENTER_REL(0),.PHASE_STEADY_EXIT_ABS(0),.PHASE_STEADY_EXIT_REL(0),
    .PHASE_RMS_ENTER_ABS(1e-6),.PHASE_RMS_ENTER_REL(0),.PHASE_RMS_EXIT_ABS(1e-6),.PHASE_RMS_EXIT_REL(0),
    .PHASE_TREND_ABS(1),.PHASE_TREND_REL(0)) mon(.clk(clk),.reset_n(1'b1));
  bit local_done=0;
  bw_history_checker checker(.scope_index(scope_index),
    .local_done(local_done),
    .source_handle(mon.transport_source),
    .scope_id(mon.scope_id),
    .raw_record(mon.raw_record),
    .accepted_record_seq(mon.accepted_record_seq),
    .total_bytes(mon.total_bytes),
    .total_events(mon.total_events),
    .result_seq(64'(mon.result_seq)),
    .stats_epoch(64'(mon.stats_epoch)),
    .window_start_ticks(64'(mon.window_start_ticks)),
    .window_end_ticks(64'(mon.window_end_ticks)),
    .window_start_cycle(64'(mon.window_start_cycle)),
    .window_end_cycle(64'(mon.window_end_cycle)),
    .coverage_ticks(64'(mon.coverage_ticks)),
    .coverage_cycles(64'(mon.coverage_cycles)),
    .window_bytes(64'(mon.window_bytes)),
    .window_events(64'(mon.window_events)),
    .window_warmup(64'(mon.window_warmup)),
    .window_full(64'(mon.window_full)),
    .bytes_complete(64'(mon.bytes_complete)),
    .events_complete(64'(mon.events_complete)),
    .denominator_valid(64'(mon.denominator_valid)),
    .window_valid(64'(mon.window_valid)),
    .member_reset_coverage(64'(mon.member_reset_coverage)),
    .bandwidth_gbps(mon.bandwidth_gbps),
    .bytes_per_cycle(mon.bytes_per_cycle));
  int snapshot_seq=0;
  bw_u64_t last_snapshot_edge=0;
  task automatic dump_storage();
    snapshot_seq++;
    $fdisplay(storage_fd,"S %0d %0d %0d %0d %0d %0d",scope_index,snapshot_seq,$time,
      mon.accepted_record_seq,mon.window_start_ticks,mon.window_start_cycle);
    foreach(mon.core.history[i])begin
      $fdisplay(storage_fd,"E %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",
        scope_index,snapshot_seq,mon.core.history[i].first_ticks,mon.core.history[i].first_edge,
        mon.core.history[i].count,mon.core.history[i].step_ticks,mon.core.history[i].step_edges,
        mon.core.history[i].byte_inc,mon.core.history[i].event_inc,mon.core.history[i].bytes_complete,
        mon.core.history[i].events_complete,mon.core.history[i].has_reset,mon.core.history[i].last_ticks,mon.core.history[i].last_edge);
    end
    foreach(mon.core.clock_runs[i])begin
      $fdisplay(storage_fd,"C %0d %0d %0d %0d %0d %0d %0d",scope_index,snapshot_seq,
        mon.core.clock_runs[i].first_ticks,mon.core.clock_runs[i].first_edge,mon.core.clock_runs[i].count,
        mon.core.clock_runs[i].step_ticks,mon.core.clock_runs[i].last_ticks);
    end
    $fdisplay(storage_fd,"Z %0d %0d",scope_index,snapshot_seq);
  endtask
  always @(observation_end or mon.result_seq or mon.accepted_record_seq)
    if(observation_end && mon.result_seq==WINDOWS && mon.accepted_record_seq==EDGES && !local_done)
      begin dump_storage();local_done=1;end
  always @(mon.accepted_record_seq or mon.result_seq)if(monitor_ready)begin
    int ep_count,ph_count;
    ep_count=0;ph_count=0;
    foreach(mon.core.episode_pending_samples[i])ep_count+=mon.core.episode_pending_samples[i].count;
    foreach(mon.core.phase_pending_samples[i])ph_count+=mon.core.phase_pending_samples[i].count;
    checker.observe_storage(mon.core.history.size(),mon.core.clock_runs.size(),mon.core.phase_samples.size(),
      mon.core.episode_pending_samples.size(),ep_count,mon.core.phase_pending_samples.size(),ph_count);
    if(SNAPSHOT_STRIDE!=0 && mon.accepted_record_seq!=0 && mon.accepted_record_seq%SNAPSHOT_STRIDE==0 &&
       last_snapshot_edge!=mon.accepted_record_seq)begin
      dump_storage();last_snapshot_edge=mon.accepted_record_seq;
    end
  end
endmodule
module tb_bw_scale;
  timeunit 1fs;timeprecision 1fs;
  import bw_mon_pkg::*;import bw_history_input_pkg::*;
  logic clk=0,valid0=0,valid1=0,known0=1,known1=1;
  logic [63:0] bytes0=0,bytes1=0;
  bit deadline=0;
  string directory,actual_path;
  bw_mon_setup #(.EXPECTED_POINT_COUNT(2),.EXPECTED_GROUP_COUNT(1)) setup();
  bw_history_point #(.INDEX(0)) p0(clk,valid0,known0,bytes0,0);
  bw_history_point #(.INDEX(1)) p1(clk,valid1,known1,bytes1,1);
  bw_history_group g0(clk,2);
  initial begin
    if(!$value$plusargs("HISTORY_DIR=%s",directory) || !$value$plusargs("ACTUAL=%s",actual_path))
      $fatal(1,"HISTORY_ARGUMENTS_REQUIRED");
    storage_fd=$fopen({directory,"/storage-runs.txt"},"w");if(!storage_fd)$fatal(1,"HISTORY_STORAGE_OPEN");
    actual_fd=$fopen(actual_path,"w");if(!actual_fd)$fatal(1,"HISTORY_ACTUAL_OPEN");
    $fdisplay(actual_fd,"scope,records,windows,total_bytes,total_events,event_segments_peak,clock_segments_peak,phase_samples_peak,episode_pending_runs_peak,episode_pending_count_peak,phase_pending_runs_peak,phase_pending_count_peak,event_segments_final,clock_segments_final,transport_frames_final,transport_controls_final,drain_checkpoints");
    define_group("history.group",2);add_point_member("history.group","history.p0");add_point_member("history.group","history.p1");
    finish_configuration();wait(monitor_ready);
    if($time!=0)$fatal(1,"HISTORY_READY_ORIGIN");
    // Known numeric API literals complement the actual >32-bit public sums.
    if(checked_add(64'hffffffffffffffff,0,"history.numeric")!=64'hffffffffffffffff ||
       checked_mul(64'hffffffffffffffff,1,"history.numeric")!=64'hffffffffffffffff ||
       checked_sub(64'hffffffffffffffff,64'hfffffffffffffffe,"history.numeric")!=1 ||
       checked_mul(16384,checked_mul(80001,64'd4294967295,"history.numeric"),"history.numeric")!=64'd5629569901646561280 ||
       ns_to_ticks(40000,"history.numeric")!=64'd40000000000)
      $fatal(1,"HISTORY_NUMERIC_LITERAL");
    $display("HISTORY_RUN_START scopes=3 edges=%0d windows=%0d end_ticks=%0d",EDGES,WINDOWS,END_TICKS);
    #END_TICKS;observation_end=1;deadline<=1;
    wait(completed_scopes==3);
    if($time!=END_TICKS || core_failure_pending())$fatal(1,"HISTORY_FINAL_FAILURE");
    if(acknowledged_frame_seq(g0.mon.group_handle,0)!=EDGES || acknowledged_frame_seq(g0.mon.group_handle,1)!=EDGES)
      $fatal(1,"HISTORY_ACK_INCOMPLETE");
    $fclose(actual_fd);$fclose(storage_fd);
    $display("HISTORY_PASS scopes=3 raw=%0d windows=%0d end_ticks=%0d",EDGES*3,WINDOWS*3,$time);$finish;
  end
  initial begin
    int fd,rc,v0,k0,v1,k1;
    bw_u64_t tick,b0,b1;
    wait(monitor_ready);
    fd=$fopen({directory,"/event-input.txt"},"r");if(!fd)$fatal(1,"HISTORY_INPUT_OPEN");
    for(bw_u64_t i=1;i<=EDGES;i++)begin
      rc=$fscanf(fd,"%d %d %d %d %d %d %d\n",tick,v0,k0,b0,v1,k1,b1);
      if(rc!=7)$fatal(1,"HISTORY_INPUT_EOF edge=%0d",i);
      #(tick-$time-1);valid0=(v0==2)?1'bx:v0[0];known0=k0[0];bytes0=b0;
      valid1=(v1==2)?1'bx:v1[0];known1=k1[0];bytes1=b1;
      #1;clk=1;#1;clk=0;
    end
    if($fscanf(fd,"%d",tick)!=-1)$fatal(1,"HISTORY_INPUT_UNCONSUMED");$fclose(fd);
  end
  always @(deadline or completed_scopes)if(deadline)begin
    HISTORY_ALL_SETTLED:assert final(completed_scopes==3)else end_failure();
  end
  function automatic void end_failure();
    if(completed_scopes!=3)$fatal(1,"HISTORY_END_INCOMPLETE completed=%0d",completed_scopes);
  endfunction
endmodule
