bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-revised.uX6BKM/final-campaign/builds/c81639d6d7c9c4c75ee2befc1fb4bb8a152154e54fa11164c72e61975f7f645e/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
