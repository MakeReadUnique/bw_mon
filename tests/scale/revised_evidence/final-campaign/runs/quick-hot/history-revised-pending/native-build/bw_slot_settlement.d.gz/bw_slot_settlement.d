bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-revised.uX6BKM/final-campaign/builds/5ab9cf36c4e3c4759c29e248422ce796059f620511a6360c6d5e8fcee82aae73/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
