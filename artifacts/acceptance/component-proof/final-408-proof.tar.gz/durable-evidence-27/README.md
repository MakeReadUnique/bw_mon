# Functional and numeric regression proof

This bundle preserves the 408/408 VCS contract-case result across 160 compiled
tops from the final ticket27 source tree. The tested feature commit and merged
integration commit have identical trees; see `provenance.json` and
`merge-evidence.json`. `source-manifest.json` gives repository-relative source
paths and content SHA-256 values. `files.sha256.json` hashes the preserved proof.

`verification.json` records the source/fixture/header/runner fingerprints and
case audit. `cases.json` and `expect/` preserve the actual test contracts and cfg.
`compile/`, `runtime/` and `full-regression.log` are the genuine logs, retaining
the original absolute build paths. Their paths are provenance, not an additional
installation requirement. From this source tree, rerun `python3 tests/run.py`
with VCS on PATH and a configured license. The runner compiles each current
fingerprint and independently checks normal or expected-fatal behavior.

This bundle proves the component/integration regression. Waveform, human, common
scale, maximum topology and retained-history evidence is recorded separately.
