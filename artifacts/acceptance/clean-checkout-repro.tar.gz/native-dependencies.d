bw_slot_settlement.o: \
 /tmp/bw-mon-spec13-resume/ticket28-clean-cd07/.build/acceptance/tb_acceptance_ns/a76e87b3b976e78ef168028990819f9a6af337683db9d94004f8d84a8e5b6c80/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
