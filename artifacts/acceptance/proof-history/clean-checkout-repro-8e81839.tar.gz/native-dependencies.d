bw_slot_settlement.o: \
 /tmp/bw-mon-spec13/ticket-28-clean-8e81839/.build/acceptance/tb_acceptance_ns/source-125c4eb3f6d56926ac54dec0e9bcf9377b0857bc6f763dc793d09f93ddeb66fd/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
