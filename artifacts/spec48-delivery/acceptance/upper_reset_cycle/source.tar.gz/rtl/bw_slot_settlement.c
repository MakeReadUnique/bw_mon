/* Kernel scheduling only: all monitor state and arithmetic remain in SV. */
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include "svdpi.h"
#include "vpi_user.h"

#ifdef __cplusplus
extern "C" {
#endif
extern void bw_slot_settlement_arrived(void);
extern void bw_native_reset_seen(svBit prepare, svLogic previous, svLogic current);
extern void bw_native_point_edge(void);
extern int bw_native_point_audit(void);
extern void bw_native_scheduler_failed(void);

typedef struct point_watch {
    svScope scope;
    vpiHandle object, callback;
    s_vpi_time time;
    s_vpi_value value;
    svLogic previous;
    int dirty, indexed;
    unsigned long long pending_grant;
    struct point_watch *next, *next_dirty, *next_indexed;
} point_watch;
static point_watch *point_watches, *dirty_point_watches;
static unsigned long long slot_generation = 0;
static int settlement_cancelled = 0;
/* Settlement observability: public end-of-run counters behind the
   BW_SETTLE_STATS marker. Creation totals survive the release callback so the
   marker stays truthful regardless of end-callback order. */
static unsigned long long settle_rounds, settle_audits, settle_edges,
    settle_dirty_audits, settle_deferred, point_watch_creations;

/* Dirty watcher set: a settlement round audits only watchers with audit-
   relevant activity since their last audit. Activity sources: this scope's
   raw clock or reset transitions (native callbacks), settlement/continuation
   receipts reported by the SV owner (bw_native_mark_settlement_watch), a
   newly registered watcher, and a watcher whose own audit requested a
   re-audit (its outcome can change once the shared generation advances). */
static void mark_point_dirty(point_watch *watch)
{
    /* Reset observers can fire (and snapshot) before any point watcher of
       that scope exists; a missing owner simply contributes no activity. */
    if (!watch) return;
    if (!watch->dirty) {
        watch->dirty = 1;
        watch->next_dirty = dirty_point_watches;
        dirty_point_watches = watch;
    }
}

/* A watcher whose latest grant still awaits the shared generation would only
   answer "grant pending" this round; defer its dispatch and re-dirty it for
   the next round, so once the generation crosses, that round runs the deep
   completion checks exactly as an immediate dispatch sequence would. */
static void defer_point_watch(point_watch *watch)
{
    settle_deferred++;
    mark_point_dirty(watch);
}

/* Scope -> watcher index so reset observers can dirty their owning watcher. */
#define BW_SCOPE_BUCKETS 64
static point_watch *scope_buckets[BW_SCOPE_BUCKETS];
static unsigned scope_bucket(svScope scope)
{
    size_t value = (size_t)scope;
    value = (value >> 4) ^ (value >> 12);
    return (unsigned)(value % BW_SCOPE_BUCKETS);
}
static void index_point_watch(point_watch *watch)
{
    unsigned bucket = scope_bucket(watch->scope);
    if (watch->scope && !watch->indexed) {
        watch->indexed = 1;
        watch->next_indexed = scope_buckets[bucket];
        scope_buckets[bucket] = watch;
    }
}
static point_watch *find_point_watch(svScope scope)
{
    point_watch *watch;
    if (!scope) return NULL;
    for (watch = scope_buckets[scope_bucket(scope)]; watch; watch = watch->next_indexed)
        if (watch->scope == scope) return watch;
    return NULL;
}

static PLI_INT32 point_clock_changed(p_cb_data callback)
{
    point_watch *watch = (point_watch *)callback->user_data;
    svLogic old = watch->previous;
    int raw = callback->value->value.scalar;
    svLogic value = raw == vpi0 ? sv_0 : raw == vpi1 ? sv_1 : raw == vpiZ ? sv_z : sv_x;
    svScope previous;
    settle_edges++;
    watch->previous = value;
    mark_point_dirty(watch);
    /* IEEE four-state posedge: 0->1/X/Z, X/Z->1. */
    if ((old == sv_0 && value != sv_0) ||
        ((old == sv_x || old == sv_z) && value == sv_1)) {
        previous = svSetScope(watch->scope);
        bw_native_point_edge();
        if (previous) svSetScope(previous);
    }
    return 0;
}

void *bw_native_watch_point_clock(const char *scope_path)
{
    point_watch *watch;
    s_cb_data callback;
    s_vpi_value value;
    size_t length = strlen(scope_path);
    char *path;
    if (length > SIZE_MAX - 5) return NULL;
    watch = (point_watch *)calloc(1, sizeof(*watch));
    path = (char *)malloc(length + 5);
    if (!watch || !path) { free(watch); free(path); return NULL; }
    memcpy(path, scope_path, length); memcpy(path + length, ".clk", 5);
    watch->scope = svGetScopeFromName(scope_path);
    watch->object = vpi_handle_by_name((PLI_BYTE8 *)path, NULL);
    free(path);
    if (!watch->scope || !watch->object) { free(watch); return NULL; }
    memset(&value, 0, sizeof(value)); value.format = vpiScalarVal;
    vpi_get_value(watch->object, &value);
    watch->previous = value.value.scalar == vpi0 ? sv_0 : value.value.scalar == vpi1 ? sv_1 :
                      value.value.scalar == vpiZ ? sv_z : sv_x;
    watch->time.type = vpiSimTime; watch->value.format = vpiScalarVal;
    memset(&callback, 0, sizeof(callback));
    callback.reason = cbValueChange; callback.cb_rtn = point_clock_changed;
    callback.obj = watch->object; callback.time = &watch->time; callback.value = &watch->value;
    callback.user_data = (PLI_BYTE8 *)watch;
    watch->callback = vpi_register_cb(&callback);
    if (!watch->callback) { free(watch); return NULL; }
    watch->next = point_watches; point_watches = watch;
    index_point_watch(watch);
    mark_point_dirty(watch);
    point_watch_creations++;
    return watch;
}

typedef struct reset_watch {
    svScope scope;
    vpiHandle object, callback;
    s_vpi_value value;
    s_vpi_time time;
    svLogic previous;
    int dirty;
    struct reset_watch *next, *next_dirty;
} reset_watch;
static reset_watch *reset_watches, *dirty_resets;
static unsigned long long reset_watch_count;
static int reset_watch_error;
#ifdef BW_MON_TEST_FAULTS
static int fail_next_reset_allocation;
static int fail_next_slot_registration;
void bw_native_fail_reset_allocation(void) { fail_next_reset_allocation = 1; }
void bw_native_fail_slot_registration(void) { fail_next_slot_registration = 1; }
#endif

static svLogic scalar_logic(int value)
{
    return value == vpi0 ? sv_0 : value == vpi1 ? sv_1 : value == vpiZ ? sv_z : sv_x;
}

static void mark_reset_dirty(reset_watch *watch)
{
    if (!watch->dirty) {
        watch->dirty = 1;
        watch->next_dirty = dirty_resets;
        dirty_resets = watch;
    }
}

static PLI_INT32 reset_changed(p_cb_data callback)
{
    reset_watch *watch = (reset_watch *)callback->user_data;
    svLogic previous = watch->previous;
    svLogic current = scalar_logic(callback->value->value.scalar);
    svScope previous_scope;
    watch->previous = current;
    mark_reset_dirty(watch);
    mark_point_dirty(find_point_watch(watch->scope));
    previous_scope = svSetScope(watch->scope);
    bw_native_reset_seen(0, previous, current);
    if (previous_scope) svSetScope(previous_scope);
    return 0;
}

static PLI_INT32 release_reset_watches(p_cb_data callback)
{
    reset_watch *watch;
    point_watch *point;
    unsigned bucket;
    (void)callback;
    dirty_resets = NULL;
    dirty_point_watches = NULL;
    for (bucket = 0; bucket < BW_SCOPE_BUCKETS; bucket++) scope_buckets[bucket] = NULL;
    while (reset_watches) {
        watch = reset_watches;
        reset_watches = watch->next;
        vpi_remove_cb(watch->callback);
        free(watch);
    }
    reset_watch_count = 0;
    while (point_watches) {
        point = point_watches; point_watches = point->next;
        vpi_remove_cb(point->callback); free(point);
    }
    return 0;
}

void *bw_native_watch_reset(const char *scope_path, const char *signal_name)
{
    reset_watch *watch;
    s_cb_data callback;
    s_vpi_value value;
    size_t scope_length = strlen(scope_path), signal_length = strlen(signal_name);
    char *path;
    reset_watch_error = 0;
#ifdef BW_MON_TEST_FAULTS
    if (fail_next_reset_allocation) {
        fail_next_reset_allocation = 0; reset_watch_error = 1; return NULL;
    }
#endif
    if (signal_length > SIZE_MAX - 2 || scope_length > SIZE_MAX - signal_length - 2 ||
        reset_watch_count == UINT64_MAX) {
        reset_watch_error = 1;
        return NULL;
    }
    path = (char *)malloc(scope_length + signal_length + 2);
    watch = (reset_watch *)calloc(1, sizeof(reset_watch));
    if (!path || !watch) {
        free(path); free(watch); reset_watch_error = 1; return NULL;
    }
    memcpy(path, scope_path, scope_length);
    path[scope_length] = '.';
    memcpy(path + scope_length + 1, signal_name, signal_length + 1);
    watch->scope = svGetScopeFromName(scope_path);
    watch->object = vpi_handle_by_name((PLI_BYTE8 *)path, NULL);
    free(path);
    if (!watch->scope || !watch->object) { free(watch); return NULL; }
    memset(&value, 0, sizeof(value));
    value.format = vpiScalarVal;
    vpi_get_value(watch->object, &value);
    watch->previous = scalar_logic(value.value.scalar);
    watch->value.format = vpiScalarVal;
    watch->time.type = vpiSimTime;
    memset(&callback, 0, sizeof(callback));
    callback.reason = cbValueChange;
    callback.cb_rtn = reset_changed;
    callback.obj = watch->object;
    callback.time = &watch->time;
    callback.value = &watch->value;
    callback.user_data = (PLI_BYTE8 *)watch;
    watch->callback = vpi_register_cb(&callback);
    if (!watch->callback) { free(watch); return NULL; }
    if (reset_watch_count == 0) {
        memset(&callback, 0, sizeof(callback));
        callback.reason = cbEndOfSimulation;
        callback.cb_rtn = release_reset_watches;
        if (!vpi_register_cb(&callback)) {
            vpi_remove_cb(watch->callback); free(watch); return NULL;
        }
    }
    watch->next = reset_watches;
    reset_watches = watch;
    reset_watch_count++;
    return watch;
}

int bw_native_reset_watch_error(void) { return reset_watch_error; }
unsigned long long bw_native_reset_watch_count(void) { return reset_watch_count; }

void bw_native_reset_snapshot(void *handle)
{
    reset_watch *watch = (reset_watch *)handle;
    svScope previous;
    s_vpi_value value;
    if (!watch) return;
    memset(&value, 0, sizeof(value)); value.format = vpiScalarVal;
    vpi_get_value(watch->object, &value);
    watch->previous = scalar_logic(value.value.scalar);
    mark_reset_dirty(watch);
    mark_point_dirty(find_point_watch(watch->scope));
    previous = svSetScope(watch->scope);
    bw_native_reset_seen(0, watch->previous, watch->previous);
    if (previous) svSetScope(previous);
}

/* SV owners report audit-relevant receipts (continuations, publications,
   grants, batch ledgers) that no native raw-signal callback observed. */
void bw_native_mark_settlement_watch(void *handle)
{
    if (handle) mark_point_dirty((point_watch *)handle);
}

/* The settlement generation advance lets deferred grant-wait watchers run
   their deep completion checks in the next round. */
void bw_native_note_generation(unsigned long long generation)
{
    slot_generation = generation;
}

/* Shared/fatal failure freezes the generation. Outstanding grants must reach
   the SV failure guard instead of waiting forever for that frozen counter. */
void bw_native_cancel_slot_settlement(void)
{
    settlement_cancelled = 1;
}

/* Combined hot request path: report the requester's latest grant, mark its
   watcher dirty and register the end-of-slot callback in one crossing. The
   registration result is returned; the caller owns the failure diagnostic. */
int bw_native_request_slot_settlement(void);
int bw_native_settlement_activity_request(void *handle, unsigned long long grant)
{
    point_watch *watch = (point_watch *)handle;
    if (watch) {
        if (grant > watch->pending_grant) watch->pending_grant = grant;
        mark_point_dirty(watch);
    }
    return bw_native_request_slot_settlement();
}

static int callback_pending = 0;
static svScope package_scope;

static PLI_INT32 report_settle_stats(p_cb_data callback)
{
    (void)callback;
    if (settle_rounds)
        vpi_printf("BW_SETTLE_STATS rounds=%llu audits=%llu watchers=%llu edges=%llu dirty_audits=%llu deferred=%llu\n",
                   settle_rounds, settle_audits, point_watch_creations, settle_edges,
                   settle_dirty_audits, settle_deferred);
    return 0;
}

static PLI_INT32 settle_slot(p_cb_data callback)
{
    svScope previous;
    reset_watch *watch;
    point_watch *point, *pending, *next;
    int reaudit = 0;
    (void)callback;
    settle_rounds++;
    // Capture is ordered at value change; dispatch waits until all raw input
    // and combinational-condition updates have settled, before granting work.
    while (dirty_resets) {
        watch = dirty_resets; dirty_resets = watch->next_dirty;
        watch->dirty = 0; watch->next_dirty = NULL;
        previous = svSetScope(watch->scope);
        bw_native_reset_seen(1, sv_x, sv_x);
        if (previous) svSetScope(previous);
    }
    callback_pending = 0;
    /* Audit the PREVIOUS grant only after its SV continuations. A callback is
       not a completion receipt and callback registration order is irrelevant.
       Only watchers with activity since their last audit are visited; a
       re-audit request keeps its watcher dirty for the next round because the
       shared generation advance can change its outcome. Marks arriving while
       this round runs (receipts of just-audited continuations) are consumed
       by the next round. */
    pending = dirty_point_watches;
    dirty_point_watches = NULL;
    for (point = pending; point; point = next) {
        next = point->next_dirty;
        point->next_dirty = NULL;
        point->dirty = 0;
        if (!settlement_cancelled && point->pending_grant > slot_generation) {
            /* The SV audit would stop at its generation guard: keep the slot
               open for the granted continuations without paying a dispatch. */
            reaudit = 1;
            defer_point_watch(point);
            continue;
        }
        previous = svSetScope(point->scope);
        settle_audits++;
        settle_dirty_audits++;
        if (bw_native_point_audit()) {
            reaudit = 1;
            mark_point_dirty(point);
        }
        if (previous) svSetScope(previous);
    }
    previous = svSetScope(package_scope);
    bw_slot_settlement_arrived();
    if (reaudit && !bw_native_request_slot_settlement()) bw_native_scheduler_failed();
    if (previous) svSetScope(previous);
    if ((settle_rounds & 8191u) == 0) {
        s_vpi_time now;
        now.type = vpiSimTime;
        vpi_get_time(NULL, &now);
        vpi_printf("BW_SETTLE_PROGRESS rounds=%llu audits=%llu deferred=%llu ticks=%llu\n",
                   settle_rounds, settle_audits, settle_deferred,
                   (unsigned long long)(((uint64_t)now.high << 32) | now.low));
    }
    return 0;
}

int bw_native_request_slot_settlement(void)
{
    s_cb_data callback;
    s_vpi_time delay;
    vpiHandle handle;
    static int stats_registered = 0;
    if (callback_pending) return 1;
#ifdef BW_MON_TEST_FAULTS
    if (fail_next_slot_registration) { fail_next_slot_registration = 0; return 0; }
#endif
    package_scope = svGetScope();
    if (!package_scope) return 0;
    if (!stats_registered) {
        memset(&callback, 0, sizeof(callback));
        callback.reason = cbEndOfSimulation;
        callback.cb_rtn = report_settle_stats;
        /* A lost stats registration never affects settlement semantics. */
        if (vpi_register_cb(&callback)) stats_registered = 1;
    }
    memset(&callback, 0, sizeof(callback));
    memset(&delay, 0, sizeof(delay));
    delay.type = vpiSimTime;
    callback.reason = cbAtEndOfSimTime;
    callback.cb_rtn = settle_slot;
    callback.time = &delay;
    handle = vpi_register_cb(&callback);
    if (!handle) return 0;
    callback_pending = 1;
    return 1;
}
#ifdef __cplusplus
}
#endif
