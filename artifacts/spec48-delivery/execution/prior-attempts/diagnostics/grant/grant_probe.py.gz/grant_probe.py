import json, os, shutil, signal, subprocess, time
from pathlib import Path
suite=json.load(open('/home/eda/bw-mon-ticket62-delivery-runs/revised/suite-full-cold.json'))
receipt=Path(next(p['manifest'] for p in suite['profiles'] if p['name']=='topology-max-ns'));m=json.load(receipt.open());build=Path(m['build'])
out=Path('/home/eda/bw-mon-ticket62-grant-probe');out.mkdir(exist_ok=True)
source=out/'source';shutil.copytree(m['source_snapshot'],str(source))
p=source/'rtl/bw_slot_settlement.svh';text=p.read_text()
text=text.replace('chandle watch=null,bw_scope_t kind=BW_POINT);','chandle watch=null,bw_scope_t kind=BW_POINT,bw_u64_t pending_grant=0);')
text=text.replace('    slot_settlement_pending=1;','    if(watch!=null && pending_grant==required)return required;\n    slot_settlement_pending=1;')
p.write_text(text)
p=source/'rtl/bw_mon_transport.svh';text=p.read_text();text=text.replace('    grant=request_slot_settlement(group.id,group.settlement_watch,BW_GROUP);','    grant=request_slot_settlement(group.id,group.settlement_watch,BW_GROUP,group.ledger.grant);');p.write_text(text)
p=source/'rtl/bw_scope_runtime.svh';text=p.read_text();text=text.replace('    bw_u64_t grant;','    bw_u64_t grant,pending_grant;');text=text.replace("    grant=bw_mon_pkg::request_slot_settlement(context_id,watch,bw_scope_t'(scope_kind));","    pending_grant=0;\n    if(scope_kind==BW_POINT && my_point_ledger!=null)pending_grant=my_point_ledger.grant;\n    else if(scope_kind==BW_GROUP && my_group_ledger!=null)pending_grant=my_group_ledger.grant;\n    grant=bw_mon_pkg::request_slot_settlement(context_id,watch,bw_scope_t'(scope_kind),pending_grant);");p.write_text(text)
p=source/'rtl/bw_point_completion.svh';text=p.read_text().replace('request_slot_settlement(id,watch);','request_slot_settlement(id,watch,BW_POINT,batch.grant);').replace('request_slot_settlement(id,batch.settlement_watch)','request_slot_settlement(id,batch.settlement_watch,BW_POINT,batch.grant)');p.write_text(text)
p=source/'rtl/bw_group_completion.svh';text=p.read_text().replace('request_slot_settlement(id,watch,BW_GROUP),watch,batch);','request_slot_settlement(id,watch,BW_GROUP,batch.grant),watch,batch);');p.write_text(text)
args=m['stages']['compile']['command'][4:];args=[str(out/'simv') if a==str(build/'simv') else a.replace(m['source_snapshot'],str(source)) for a in args]
(out/'compile-command.json').write_text(json.dumps(args,indent=2)+'\n')
env=os.environ.copy();env['SNPSLMD_LICENSE_FILE']='27080@localhost.localdomain'
with (out/'compile.log').open('w') as f:r=subprocess.run(args,cwd=str(out),env=env,stdout=f,stderr=subprocess.STDOUT)
print('compile',r.returncode,flush=True)
if r.returncode:raise SystemExit(r.returncode)
results=[]
for label,binary in [('before',build/'simv'),('after',out/'simv')]:
 folder=out/label;folder.mkdir();(folder/'prefix.do').write_text('run 32ns\nputs __BW_PREFIX_DONE__\nflush stdout\n')
 command=[str(binary),'-no_save','-ucli','-do',str(folder/'prefix.do'),'+VARIANT=reset','+ACTUAL='+str(folder/'actual.csv'),'+BW_EXPECT='+str(receipt.parent/'expect.cfg')]
 record=dict(label=label,diagnostic_only=True,qualification=False,command=command)
 start=time.monotonic();p=subprocess.Popen(command,cwd=str(folder),env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,universal_newlines=True,start_new_session=True)
 try:
  with (folder/'simulation.log').open('w') as f:
   for line in p.stdout:
    f.write(line);f.flush()
    if line.strip()=='__BW_PREFIX_DONE__':
     stat=Path('/proc/%d/stat'%p.pid).read_text().rsplit(')',1)[1].split()
     record.update(state='PREFIX_MEASURED',elapsed_seconds=time.monotonic()-start,user_seconds=int(stat[11])/os.sysconf('SC_CLK_TCK'),system_seconds=int(stat[12])/os.sysconf('SC_CLK_TCK'),minor_faults=int(stat[7]))
     record['smaps']=Path('/proc/%d/smaps_rollup'%p.pid).read_text()
     break
   else:record['state']='EXITED_BEFORE_PREFIX'
 finally:
  if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
  record['returncode']=p.wait();record['note']='Intentionally killed after diagnostic prefix; not an acceptance run.'
  (folder/'result.json').write_text(json.dumps(record,indent=2)+'\n');results.append(record)
 print(json.dumps(record),flush=True)
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
