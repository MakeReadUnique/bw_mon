import json, os, shutil, signal, subprocess, time
from pathlib import Path
suite=json.load(open('/home/eda/bw-mon-ticket62-delivery-runs/revised/suite-full-cold.json'))
receipt=Path(next(p['manifest'] for p in suite['profiles'] if p['name']=='topology-max-ns'));m=json.load(receipt.open());build=Path(m['build'])
out=Path('/home/eda/bw-mon-ticket62-peek-probe');out.mkdir(exist_ok=True)
source=out/'source';shutil.copytree(m['source_snapshot'],str(source))
p=source/'rtl/bw_mon_transport.svh';text=p.read_text()
text=text.replace('member_index,output bw_record_t frame);\n    bw_source_state source;','member_index,ref bw_record_t frame);\n    bw_source_state source;')
text=text.replace('member_index,output bw_control_frame_t control);\n    bw_source_state source;','member_index,ref bw_control_frame_t control);\n    bw_source_state source;')
text=text.replace("    frame='0;\n    owner=",'    owner=').replace("    control='0;\n    owner=",'    owner=')
text=text.replace('    return peek_member_frame_at(index,member_index,frame);',"    frame='0;\n    return peek_member_frame_at(index,member_index,frame);")
text=text.replace('    return peek_member_control_at(index,member_index,control);',"    control='0;\n    return peek_member_control_at(index,member_index,control);")
p.write_text(text)
args=m['stages']['compile']['command'][4:];args=[str(out/'simv') if a==str(build/'simv') else a.replace(m['source_snapshot'],str(source)) for a in args]
(out/'compile-command.json').write_text(json.dumps(args,indent=2)+'\n')
env=os.environ.copy();env['SNPSLMD_LICENSE_FILE']='27080@localhost.localdomain'
with (out/'compile.log').open('w') as f:r=subprocess.run(args,cwd=str(out),env=env,stdout=f,stderr=subprocess.STDOUT)
print('compile',r.returncode,flush=True)
if r.returncode:raise SystemExit(r.returncode)
results=[]
for label,binary in [('before',build/'simv'),('after',out/'simv')]:
 folder=out/label;folder.mkdir();(folder/'prefix.do').write_text('run 32ns\nputs __BW_PREFIX_DONE__\nflush stdout\n')
 command=[str(binary),'-no_save','-ucli','-do',str(folder/'prefix.do'),'+VARIANT=reset','+ACTUAL='+str(folder/'actual.csv'),'+BW_EXPECT='+str(receipt.parent/'expect.cfg')]
 record=dict(label=label,diagnostic_only=True,qualification=False,command=command)
 start=time.monotonic();p=subprocess.Popen(command,cwd=str(folder),env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,universal_newlines=True,start_new_session=True)
 try:
  with (folder/'simulation.log').open('w') as f:
   for line in p.stdout:
    f.write(line);f.flush()
    if line.strip()=='__BW_PREFIX_DONE__':
     stat=Path('/proc/%d/stat'%p.pid).read_text().rsplit(')',1)[1].split()
     record.update(state='PREFIX_MEASURED',elapsed_seconds=time.monotonic()-start,user_seconds=int(stat[11])/os.sysconf('SC_CLK_TCK'),system_seconds=int(stat[12])/os.sysconf('SC_CLK_TCK'),minor_faults=int(stat[7]))
     record['smaps']=Path('/proc/%d/smaps_rollup'%p.pid).read_text()
     break
   else:record['state']='EXITED_BEFORE_PREFIX'
 finally:
  if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
  record['returncode']=p.wait();record['note']='Intentionally killed after diagnostic prefix; not an acceptance run.'
  (folder/'result.json').write_text(json.dumps(record,indent=2)+'\n');results.append(record)
 print(json.dumps(record),flush=True)
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
