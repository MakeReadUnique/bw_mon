memory_advice.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/654b6f3f0d11c016fe4cec51357ea07fba6325d149d62d1cea423c9e5a83c98b/source/tests/scale/memory_advice.c
