bw_end_coordinator.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/e2385c6a56a6195383b0e8ec12a0db639de74db59c7cc45bca23d3ab78219de8/source/rtl/bw_end_coordinator.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
