bw_slot_settlement.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/8484ab968b60302b301875cdaf3d8ea488e1f3b3ddd94b781f6b3324dc614a52/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
