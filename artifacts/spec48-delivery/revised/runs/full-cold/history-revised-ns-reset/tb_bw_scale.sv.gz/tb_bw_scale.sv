module bw_history_point #(parameter int INDEX=0)(input logic clk,valid,known,reset_n,input logic [63:0] size_bytes,input int scope_index);
  timeunit 1fs;timeprecision 1fs;
  import bw_mon_pkg::*;import bw_history_input_pkg::*;
  bw_point_mon #(.POINT_ID($sformatf("history.p%0d",INDEX)),.DYNAMIC_BYTES(1),.WINDOW_BASIS(bw_basis_t'(BASIS)),.WINDOW_WIDTH(WIDTH),.UPDATE_STRIDE(STRIDE),.EPISODE_ENABLE(1),.SILENCE_THRESHOLD(30)) mon
    (.clk(clk),.reset_n(reset_n),.valid(valid),.size_bytes(size_bytes),.size_known(known));
  bit local_done=0;
  bw_history_checker checker(.scope_index(scope_index),
    .local_done(local_done),
    .source_handle(mon.transport_source),
    .scope_id(mon.scope_id),
    .raw_record(mon.raw_record),
    .accepted_record_seq(mon.accepted_record_seq),
    .total_bytes(mon.total_bytes),
    .total_events(mon.total_events),
    .result_seq(64'(mon.result_seq)),
    .stats_epoch(64'(mon.stats_epoch)),
    .window_start_ticks(64'(mon.window_start_ticks)),
    .window_end_ticks(64'(mon.window_end_ticks)),
    .window_start_cycle(64'(mon.window_start_cycle)),
    .window_end_cycle(64'(mon.window_end_cycle)),
    .coverage_ticks(64'(mon.coverage_ticks)),
    .coverage_cycles(64'(mon.coverage_cycles)),
    .window_bytes(64'(mon.window_bytes)),
    .window_events(64'(mon.window_events)),
    .window_warmup(64'(mon.window_warmup)),
    .window_full(64'(mon.window_full)),
    .bytes_complete(64'(mon.bytes_complete)),
    .events_complete(64'(mon.events_complete)),
    .denominator_valid(64'(mon.denominator_valid)),
    .window_valid(64'(mon.window_valid)),
    .member_reset_coverage(64'(mon.member_reset_coverage)),
    .bandwidth_gbps(mon.bandwidth_gbps),
    .bytes_per_cycle(mon.bytes_per_cycle));
  int snapshot_seq=0;
  bw_u64_t last_snapshot_edge=0;
  task automatic dump_storage();
    snapshot_seq++;
    $fdisplay(storage_fd,"S %0d %0d %0d %0d %0d %0d",scope_index,snapshot_seq,$time,
      mon.accepted_record_seq,mon.window_start_ticks,mon.window_start_cycle);
    foreach(mon.core.history[i])begin
      $fdisplay(storage_fd,"E %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",
        scope_index,snapshot_seq,mon.core.history[i].first_ticks,mon.core.history[i].first_edge,
        mon.core.history[i].count,mon.core.history[i].step_ticks,mon.core.history[i].step_edges,
        mon.core.history[i].byte_inc,mon.core.history[i].event_inc,mon.core.history[i].bytes_complete,
        mon.core.history[i].events_complete,mon.core.history[i].has_reset,mon.core.history[i].last_ticks,mon.core.history[i].last_edge);
    end
    foreach(mon.core.clock_runs[i])begin
      $fdisplay(storage_fd,"C %0d %0d %0d %0d %0d %0d %0d",scope_index,snapshot_seq,
        mon.core.clock_runs[i].first_ticks,mon.core.clock_runs[i].first_edge,mon.core.clock_runs[i].count,
        mon.core.clock_runs[i].step_ticks,mon.core.clock_runs[i].last_ticks);
    end
    $fdisplay(storage_fd,"Z %0d %0d",scope_index,snapshot_seq);
  endtask
  always @(observation_end or mon.result_seq or mon.accepted_record_seq)
    if(observation_end && mon.result_seq==expected_windows(scope_index) && mon.accepted_record_seq==EDGES && !local_done)
      begin dump_storage();local_done=1;end
  always @(mon.accepted_record_seq or mon.result_seq)if(monitor_ready)begin
    int ep_count,ph_count;
    ep_count=0;ph_count=0;
    foreach(mon.core.episode_pending_samples[i])ep_count+=mon.core.episode_pending_samples[i].count;
    foreach(mon.core.phase_pending_samples[i])ph_count+=mon.core.phase_pending_samples[i].count;
    checker.observe_storage(mon.core.history.size(),mon.core.clock_runs.size(),mon.core.phase_samples.size(),
      mon.core.episode_pending_samples.size(),ep_count,mon.core.phase_pending_samples.size(),ph_count);
    if(SNAPSHOT_STRIDE!=0 && mon.accepted_record_seq!=0 && mon.accepted_record_seq%SNAPSHOT_STRIDE==0 &&
       last_snapshot_edge!=mon.accepted_record_seq)begin
      dump_storage();last_snapshot_edge=mon.accepted_record_seq;
    end
  end
endmodule
module bw_history_group(input logic clk,reset_n,input int scope_index);
  timeunit 1fs;timeprecision 1fs;
  import bw_mon_pkg::*;import bw_history_input_pkg::*;
  bw_group_mon #(.GROUP_ID("history.group"),.WINDOW_BASIS(bw_basis_t'(BASIS)),.WINDOW_WIDTH(WIDTH),.UPDATE_STRIDE(STRIDE),.EPISODE_ENABLE(1),.SILENCE_THRESHOLD(30)) mon(.clk(clk),.reset_n(reset_n));
  bit local_done=0;
  bw_history_checker checker(.scope_index(scope_index),
    .local_done(local_done),
    .source_handle(mon.transport_source),
    .scope_id(mon.scope_id),
    .raw_record(mon.raw_record),
    .accepted_record_seq(mon.accepted_record_seq),
    .total_bytes(mon.total_bytes),
    .total_events(mon.total_events),
    .result_seq(64'(mon.result_seq)),
    .stats_epoch(64'(mon.stats_epoch)),
    .window_start_ticks(64'(mon.window_start_ticks)),
    .window_end_ticks(64'(mon.window_end_ticks)),
    .window_start_cycle(64'(mon.window_start_cycle)),
    .window_end_cycle(64'(mon.window_end_cycle)),
    .coverage_ticks(64'(mon.coverage_ticks)),
    .coverage_cycles(64'(mon.coverage_cycles)),
    .window_bytes(64'(mon.window_bytes)),
    .window_events(64'(mon.window_events)),
    .window_warmup(64'(mon.window_warmup)),
    .window_full(64'(mon.window_full)),
    .bytes_complete(64'(mon.bytes_complete)),
    .events_complete(64'(mon.events_complete)),
    .denominator_valid(64'(mon.denominator_valid)),
    .window_valid(64'(mon.window_valid)),
    .member_reset_coverage(64'(mon.member_reset_coverage)),
    .bandwidth_gbps(mon.bandwidth_gbps),
    .bytes_per_cycle(mon.bytes_per_cycle));
  int snapshot_seq=0;
  bw_u64_t last_snapshot_edge=0;
  task automatic dump_storage();
    snapshot_seq++;
    $fdisplay(storage_fd,"S %0d %0d %0d %0d %0d %0d",scope_index,snapshot_seq,$time,
      mon.accepted_record_seq,mon.window_start_ticks,mon.window_start_cycle);
    foreach(mon.core.history[i])begin
      $fdisplay(storage_fd,"E %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",
        scope_index,snapshot_seq,mon.core.history[i].first_ticks,mon.core.history[i].first_edge,
        mon.core.history[i].count,mon.core.history[i].step_ticks,mon.core.history[i].step_edges,
        mon.core.history[i].byte_inc,mon.core.history[i].event_inc,mon.core.history[i].bytes_complete,
        mon.core.history[i].events_complete,mon.core.history[i].has_reset,mon.core.history[i].last_ticks,mon.core.history[i].last_edge);
    end
    foreach(mon.core.clock_runs[i])begin
      $fdisplay(storage_fd,"C %0d %0d %0d %0d %0d %0d %0d",scope_index,snapshot_seq,
        mon.core.clock_runs[i].first_ticks,mon.core.clock_runs[i].first_edge,mon.core.clock_runs[i].count,
        mon.core.clock_runs[i].step_ticks,mon.core.clock_runs[i].last_ticks);
    end
    $fdisplay(storage_fd,"Z %0d %0d",scope_index,snapshot_seq);
  endtask
  always @(observation_end or mon.result_seq or mon.accepted_record_seq)
    if(observation_end && mon.result_seq==expected_windows(scope_index) && mon.accepted_record_seq==EDGES && !local_done)
      begin dump_storage();local_done=1;end
  always @(mon.accepted_record_seq or mon.result_seq)if(monitor_ready)begin
    int ep_count,ph_count;
    ep_count=0;ph_count=0;
    foreach(mon.core.episode_pending_samples[i])ep_count+=mon.core.episode_pending_samples[i].count;
    foreach(mon.core.phase_pending_samples[i])ph_count+=mon.core.phase_pending_samples[i].count;
    checker.observe_storage(mon.core.history.size(),mon.core.clock_runs.size(),mon.core.phase_samples.size(),
      mon.core.episode_pending_samples.size(),ep_count,mon.core.phase_pending_samples.size(),ph_count);
    if(SNAPSHOT_STRIDE!=0 && mon.accepted_record_seq!=0 && mon.accepted_record_seq%SNAPSHOT_STRIDE==0 &&
       last_snapshot_edge!=mon.accepted_record_seq)begin
      dump_storage();last_snapshot_edge=mon.accepted_record_seq;
    end
  end
endmodule
module tb_bw_scale;
  timeunit 1fs;timeprecision 1fs;
  import bw_mon_pkg::*;import bw_history_input_pkg::*;
  logic clk=0,valid0=0,valid1=0,known0=1,known1=1;
  logic [63:0] bytes0=0,bytes1=0;
  logic reset_p0=1,reset_g=1;
  bit deadline=0,overrun_done=0;
  string directory,actual_path;
  bw_mon_setup setup();
  bw_history_point #(.INDEX(0)) p0(clk,valid0,known0,reset_p0,bytes0,0);
  bw_history_point #(.INDEX(1)) p1(clk,valid1,known1,1'b1,bytes1,1);
  bw_history_group g0(clk,reset_g,2);
  initial begin
    if(!$value$plusargs("HISTORY_DIR=%s",directory) || !$value$plusargs("ACTUAL=%s",actual_path))
      $fatal(1,"HISTORY_ARGUMENTS_REQUIRED");
    storage_fd=$fopen({directory,"/storage-runs.txt"},"w");if(!storage_fd)$fatal(1,"HISTORY_STORAGE_OPEN");
    actual_fd=$fopen(actual_path,"w");if(!actual_fd)$fatal(1,"HISTORY_ACTUAL_OPEN");
    $fdisplay(actual_fd,"scope,records,windows,total_bytes,total_events,event_segments_peak,clock_segments_peak,phase_samples_peak,episode_pending_runs_peak,episode_pending_count_peak,phase_pending_runs_peak,phase_pending_count_peak,event_segments_final,clock_segments_final,transport_frames_final,transport_controls_final,drain_checkpoints");
    add_point_member("history.group","history.p0");add_point_member("history.group","history.p1");
    wait(monitor_ready);
    if($time!=measurement_start_ticks || measurement_start_ticks==0)$fatal(1,"HISTORY_READY_ORIGIN");
    // Known numeric API literals complement the actual >32-bit public sums.
    if(checked_add(64'hffffffffffffffff,0,"history.numeric")!=64'hffffffffffffffff ||
       checked_mul(64'hffffffffffffffff,1,"history.numeric")!=64'hffffffffffffffff ||
       checked_sub(64'hffffffffffffffff,64'hfffffffffffffffe,"history.numeric")!=1 ||
       checked_mul(16384,checked_mul(80001,64'd4294967295,"history.numeric"),"history.numeric")!=64'd5629569901646561280 ||
       ns_to_ticks(40000,"history.numeric")!=64'd40000000000)
      $fatal(1,"HISTORY_NUMERIC_LITERAL");
    $display("HISTORY_RUN_START scopes=3 edges=%0d windows=%0d end_ticks=%0d",EDGES,WINDOWS,END_TICKS);
    #END_TICKS;observation_end=1;deadline<=1;
    wait(completed_scopes==3);
    if(OVERRUN_EDGES!=0)begin
      wait(overrun_done);
      // Detectable over-budget sampling is a runtime warning with isolation:
      // both points stop accepting and the dependent group is disabled, while
      // the in-budget endpoint evidence above remains intact.
      if(!scope_disabled(BW_POINT,"history.p0") || !scope_disabled(BW_POINT,"history.p1") ||
         !scope_disabled(BW_GROUP,"history.group"))$fatal(1,"HISTORY_OVERRUN_NOT_ISOLATED");
      if(p0.mon.accepted_record_seq!=EDGES || p1.mon.accepted_record_seq!=EDGES ||
         g0.mon.accepted_record_seq!=EDGES)$fatal(1,"HISTORY_OVERRUN_ACCEPTED_PAST_BUDGET");
    end else begin
      if($time!=measurement_start_ticks+END_TICKS || core_failure_pending())$fatal(1,"HISTORY_FINAL_FAILURE");
    end
    if(core_failure_pending())$fatal(1,"HISTORY_FINAL_FAILURE");
    if(acknowledged_frame_seq(g0.mon.group_handle,0)!=EDGES || acknowledged_frame_seq(g0.mon.group_handle,1)!=EDGES)
      $fatal(1,"HISTORY_ACK_INCOMPLETE");
    $fclose(actual_fd);$fclose(storage_fd);
    $display("HISTORY_PASS scopes=3 raw=%0d windows=%0d end_ticks=%0d",EDGES*3,WINDOWS,$time);
    // Same ending-contract settle step as the scale driver: the endpoint
    // marker keeps its tick and the final input slot closes before finish.
    // A run that ends exactly at the immutable T+40us budget cannot spend a
    // drain tick: it finishes from the postponed region of the endpoint tick,
    // after the same-tick settlement of the endpoint's last publication.
    if(END_TICKS<BW_MONITOR_LIMIT_TICKS)#1;
    if(END_TICKS<BW_MONITOR_LIMIT_TICKS || OVERRUN_EDGES!=0)$finish;
  end
  initial begin
    if(RESETS)begin
      wait(monitor_ready);
      #(measurement_start_ticks+P0_RESET_ASSERT-$time);reset_p0=0;
      #(measurement_start_ticks+P0_RESET_RELEASE-$time);reset_p0=1;
    end
  end
  initial begin
    if(RESETS)begin
      wait(monitor_ready);
      #(measurement_start_ticks+G_RESET_ASSERT-$time);reset_g=0;
      #(measurement_start_ticks+G_RESET_RELEASE-$time);reset_g=1;
    end
  end
  initial begin
    int fd,rc,v0,k0,v1,k1;
    bw_u64_t tick,b0,b1;
    wait(monitor_ready);
    fd=$fopen({directory,"/event-input.txt"},"r");if(!fd)$fatal(1,"HISTORY_INPUT_OPEN");
    for(bw_u64_t i=1;i<=EDGES;i++)begin
      rc=$fscanf(fd,"%d %d %d %d %d %d %d\n",tick,v0,k0,b0,v1,k1,b1);
      if(rc!=7)$fatal(1,"HISTORY_INPUT_EOF edge=%0d",i);
      #(measurement_start_ticks+tick-$time-1);valid0=(v0==2)?1'bx:v0[0];known0=k0[0];bytes0=b0;
      valid1=(v1==2)?1'bx:v1[0];known1=k1[0];bytes1=b1;
      #1;clk=1;#1;clk=0;
    end
    if($fscanf(fd,"%d",tick)!=-1)$fatal(1,"HISTORY_INPUT_UNCONSUMED");$fclose(fd);
    // Deliberate real sampling edges past the immutable T+40us budget.
    for(bw_u64_t i=1;i<=OVERRUN_EDGES;i++)begin
      #(measurement_start_ticks+tick+i*500000-$time-1);valid0=1;known0=1;bytes0=64;
      valid1=1;known1=1;bytes1=64;
      #1;clk=1;#1;clk=0;
    end
    if(OVERRUN_EDGES!=0)overrun_done=1;
  end
  always @(deadline or completed_scopes)if(deadline)begin
    HISTORY_ALL_SETTLED:assert final(completed_scopes==3)endpoint_finish();else end_failure();
  end
  function automatic void endpoint_finish();
    // Postponed-region finish for budget-ending runs: the final-value assert
    // runs after every same-tick Active/NBA/Reactive/ReNBA settlement, so the
    // endpoint's last publication has closed its batch and the report can
    // complete inside the immutable budget, without any drain tick.
    if(END_TICKS>=BW_MONITOR_LIMIT_TICKS && OVERRUN_EDGES==0 && completed_scopes==3)$finish;
  endfunction
  function automatic void end_failure();
    if(completed_scopes!=3)$fatal(1,"HISTORY_END_INCOMPLETE completed=%0d",completed_scopes);
  endfunction
endmodule
