memory_advice.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/0dd2268b92c5b700cb4620667fc790f6b5e2d7eb7d76215be59d353e35673eae/source/tests/scale/memory_advice.c
