bw_slot_settlement.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/177633fb387a1acf7fc635ff653e03ffd4b358222aeda118c6f1d825044e8a46/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
