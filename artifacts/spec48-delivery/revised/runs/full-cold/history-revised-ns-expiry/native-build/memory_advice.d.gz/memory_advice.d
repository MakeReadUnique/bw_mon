memory_advice.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/bc1bfb3f02a175b61fca6fe013c6af31916b14a60ad9cb100bffa4f5e88b7a16/source/tests/scale/memory_advice.c
