package bw_history_input_pkg;
  timeunit 1fs; timeprecision 1fs;
  import bw_mon_pkg::*;
  int actual_fd=0,storage_fd=0,completed_scopes=0;
  bit observation_end=0;
  localparam bw_u64_t BASIS=64'd1;
  localparam bw_u64_t WIDTH=64'd80000;
  localparam bw_u64_t STRIDE=64'd1;
  localparam bw_u64_t EDGES=64'd80000;
  localparam bw_u64_t WINDOWS=64'd239997;
  localparam bw_u64_t END_TICKS=64'd40000000000;
  localparam bw_u64_t EXPIRY=64'd0;
  localparam bw_u64_t SNAPSHOT_STRIDE=64'd0;
  localparam bw_u64_t WINDOWS_0=64'd79999;
  localparam bw_u64_t WINDOWS_1=64'd79999;
  localparam bw_u64_t WINDOWS_2=64'd79999;
  localparam bw_u64_t OVERRUN_EDGES=64'd0;
  localparam bw_u64_t P0_RESET_ASSERT=64'd0;
  localparam bw_u64_t P0_RESET_RELEASE=64'd0;
  localparam bw_u64_t G_RESET_ASSERT=64'd0;
  localparam bw_u64_t G_RESET_RELEASE=64'd0;
  localparam bw_u64_t RESETS=64'd0;
  function automatic bw_u64_t expected_windows(int scope);
    case(scope) 0:return WINDOWS_0; 1:return WINDOWS_1; default:return WINDOWS_2; endcase
  endfunction
  function automatic bit close_real(real actual,real expected);
    return $abs(actual-expected)<=1e-9+1e-12*$abs(expected);
  endfunction
endpackage
