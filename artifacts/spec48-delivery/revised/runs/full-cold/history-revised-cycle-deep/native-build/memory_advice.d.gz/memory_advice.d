memory_advice.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/d3590930cdc587778b3b7ac45f0543291dd1114e3b0de3ab31be9096e54c0a83/source/tests/scale/memory_advice.c
