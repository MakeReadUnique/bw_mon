bw_end_coordinator.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/6ce16cbab27afdd7a60ba8d786217c7e7516b4b0facea6627461e6ce916c9ad6/source/rtl/bw_end_coordinator.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
