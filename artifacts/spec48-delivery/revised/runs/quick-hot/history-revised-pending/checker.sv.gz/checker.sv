// Assertions are in the public fixture.
