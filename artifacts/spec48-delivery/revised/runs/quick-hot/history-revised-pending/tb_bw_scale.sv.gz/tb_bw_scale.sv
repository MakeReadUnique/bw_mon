module tb_bw_scale;
  timeunit 1fs;timeprecision 1fs;
  import bw_mon_pkg::*;
  logic clk=0,valid=1;
  bw_mon_setup setup();
  bw_point_mon #(.POINT_ID("pending.subject"),.FIXED_BYTES(8),.WINDOW_WIDTH(1),.UPDATE_STRIDE(1),
    .EPISODE_ENABLE(1),.SILENCE_THRESHOLD(30000),.PHASE_ENABLE(1)) point_mon
    (.clk(clk),.reset_n(1'b1),.valid(valid));
  int episode_runs_peak=0,phase_runs_peak=0,episode_count_peak=0,phase_count_peak=0;
  int history_peak=0,clock_peak=0;
  always @(point_mon.result_seq)if(monitor_ready && point_mon.result_seq!=0)begin
    int ep,ph;
    ep=0;ph=0;
    foreach(point_mon.core.episode_pending_samples[i])ep+=point_mon.core.episode_pending_samples[i].count;
    foreach(point_mon.core.phase_pending_samples[i])ph+=point_mon.core.phase_pending_samples[i].count;
    if(ep>episode_count_peak)episode_count_peak=ep;
    if(ph>phase_count_peak)phase_count_peak=ph;
    if(point_mon.core.episode_pending_samples.size()>episode_runs_peak)episode_runs_peak=point_mon.core.episode_pending_samples.size();
    if(point_mon.core.phase_pending_samples.size()>phase_runs_peak)phase_runs_peak=point_mon.core.phase_pending_samples.size();
    if(point_mon.core.history.size()>history_peak)history_peak=point_mon.core.history.size();
    if(point_mon.core.clock_runs.size()>clock_peak)clock_peak=point_mon.core.clock_runs.size();
  end
  initial begin
    wait(monitor_ready);
    #250000;
    repeat(6)begin clk=1;#1;clk=0;#499999;end
    valid=0;clk=1;#1;clk=0;
    #(measurement_start_ticks+64'd30003250001-$time);
    if(point_mon.raw_record.record_seq!=7 || point_mon.accepted_record_seq!=7 || point_mon.result_seq!=30003 ||
       point_mon.episode_result_seq!=1 || point_mon.episode_result.status!=BW_EPISODE_COMPLETE ||
       point_mon.episode_result.first_ticks!=measurement_start_ticks+250000 || point_mon.episode_result.last_ticks!=measurement_start_ticks+2750000 ||
       point_mon.episode_result.tail_ticks!=measurement_start_ticks+3250000 || point_mon.episode_result.confirmation_ticks!=measurement_start_ticks+64'd30003250000 ||
       point_mon.episode_result.byte_count!=48 || point_mon.episode_result.event_count!=6 ||
       point_mon.episode_result.duration_ticks!=3000000 || !point_mon.episode_result.e2e_valid ||
       $abs(point_mon.episode_result.e2e_gbps-16.0)>1e-10)
      $fatal(1,"long known quiet must retain the literal six-transfer episode and exact original tail/Q");
    if(point_mon.episode_result.variation.sample_count!=3 ||
       point_mon.episode_result.variation.first_sample_ticks!=measurement_start_ticks+1000000 ||
       point_mon.episode_result.variation.last_sample_ticks!=measurement_start_ticks+3000000 ||
       !point_mon.episode_result.variation.minmax_valid || !point_mon.episode_result.variation.stddev_valid ||
       !point_mon.episode_result.variation.cv_valid || point_mon.episode_result.last_steady_found ||
       $abs(point_mon.episode_result.variation.mean_gbps-16.0)>1e-10 ||
       point_mon.episode_result.variation.stddev_gbps!=0 || point_mon.episode_result.variation.cv_pct!=0)
      $fatal(1,"30000 confirmation-only publications after-tail suffix under fixed K=2 must be excluded without losing the owned prefix");
    if(episode_count_peak<30000 || phase_count_peak<30000 ||
       point_mon.core.episode_pending_samples.size()!=0 || point_mon.core.phase_pending_samples.size()!=0)
      $fatal(1,"HISTORY_PENDING_RETENTION_OR_RELEASE");
    $display("HISTORY_PENDING_STORAGE episode_runs_peak=%0d episode_count_peak=%0d phase_runs_peak=%0d phase_count_peak=%0d history_peak=%0d clock_peak=%0d episode_final=%0d phase_final=%0d",episode_runs_peak,episode_count_peak,phase_runs_peak,phase_count_peak,history_peak,clock_peak,point_mon.core.episode_pending_samples.size(),point_mon.core.phase_pending_samples.size());
    $display("TB_PASS variation_pending_retention episode_bytes=48 events=6 selected_samples=3 mean=16 sigma=0");$finish;
  end
endmodule
