// Existing production contract uses no generated package.
