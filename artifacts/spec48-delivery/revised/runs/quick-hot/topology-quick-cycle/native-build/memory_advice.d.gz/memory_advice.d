memory_advice.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/f3da60cee4ce1990a5cb975273e867d306c0d8d2eac36bb7e94fd1c439da3de0/source/tests/scale/memory_advice.c
