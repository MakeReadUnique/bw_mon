bw_slot_settlement.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/09efd0159b28c9ba932cac80b378f1051fef1bd33a8906f8def915b32905c99c/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
