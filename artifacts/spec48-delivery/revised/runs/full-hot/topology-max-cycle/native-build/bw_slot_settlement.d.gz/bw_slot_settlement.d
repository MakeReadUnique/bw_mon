bw_slot_settlement.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/579e9dd5d00fd8675d7c1a300ce645fd34eb490dedba2317a6190b0a45e17e55/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
