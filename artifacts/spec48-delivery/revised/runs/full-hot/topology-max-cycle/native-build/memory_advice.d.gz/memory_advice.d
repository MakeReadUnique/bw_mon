memory_advice.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/579e9dd5d00fd8675d7c1a300ce645fd34eb490dedba2317a6190b0a45e17e55/source/tests/scale/memory_advice.c
