memory_advice.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/177633fb387a1acf7fc635ff653e03ffd4b358222aeda118c6f1d825044e8a46/source/tests/scale/memory_advice.c
