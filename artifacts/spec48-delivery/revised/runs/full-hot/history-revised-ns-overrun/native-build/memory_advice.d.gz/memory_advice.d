memory_advice.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/e2385c6a56a6195383b0e8ec12a0db639de74db59c7cc45bca23d3ab78219de8/source/tests/scale/memory_advice.c
