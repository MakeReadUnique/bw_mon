memory_advice.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/850607c1d09761a70c60bf6967cc459257a84f9ace1c5c62edbf4b46530f1e50/source/tests/scale/memory_advice.c
