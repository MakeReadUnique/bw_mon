module bw_history_checker(
  input int scope_index,
  input bit local_done,
  input int source_handle,
  input string scope_id,
  input bw_mon_pkg::bw_record_t raw_record,
  input logic [63:0] accepted_record_seq,total_bytes,total_events,
  input logic [63:0] result_seq,
  input logic [63:0] stats_epoch,
  input logic [63:0] window_start_ticks,
  input logic [63:0] window_end_ticks,
  input logic [63:0] window_start_cycle,
  input logic [63:0] window_end_cycle,
  input logic [63:0] coverage_ticks,
  input logic [63:0] coverage_cycles,
  input logic [63:0] window_bytes,
  input logic [63:0] window_events,
  input logic [63:0] window_warmup,
  input logic [63:0] window_full,
  input logic [63:0] bytes_complete,
  input logic [63:0] events_complete,
  input logic [63:0] denominator_valid,
  input logic [63:0] window_valid,
  input logic [63:0] member_reset_coverage,
  input real bandwidth_gbps,
  input real bytes_per_cycle
);
  timeunit 1fs;timeprecision 1fs;
  import bw_mon_pkg::*;import bw_history_input_pkg::*;
  bw_u64_t records=0,windows=0;
  int raw_fd=0,window_fd=0,rc;
  string directory;
  bit done=0;
  int event_peak=0,clock_peak=0,phase_peak=0,ep_runs_peak=0,ep_count_peak=0,ph_runs_peak=0,ph_count_peak=0;
  int event_final=0,clock_final=0,drains=0;bw_u64_t last_drain=0;
  initial begin
    if(!$value$plusargs("HISTORY_DIR=%s",directory))$fatal(1,"HISTORY_DIRECTORY_REQUIRED");
    wait(monitor_ready);
    raw_fd=$fopen($sformatf("%s/raw-%0d.txt",directory,scope_index),"r");
    window_fd=$fopen($sformatf("%s/window-%0d.txt",directory,scope_index),"r");
    if(!raw_fd || !window_fd)$fatal(1,"HISTORY_REFERENCE_OPEN");
  end
  task automatic observe_storage(int ev,int ck,int ph,int er,int ec,int pr,int pc);
    if(ev>event_peak)event_peak=ev;if(ck>clock_peak)clock_peak=ck;if(ph>phase_peak)phase_peak=ph;
    if(er>ep_runs_peak)ep_runs_peak=er;if(ec>ep_count_peak)ep_count_peak=ec;
    if(pr>ph_runs_peak)ph_runs_peak=pr;if(pc>ph_count_peak)ph_count_peak=pc;
    event_final=ev;clock_final=ck;
    if(EXPIRY && accepted_record_seq!=0 && accepted_record_seq%2048==0 && accepted_record_seq!=last_drain)begin
      if(ev!=0)$fatal(1,"HISTORY_DRAIN_MISMATCH scope=%s edge=%0d segments=%0d",scope_id,accepted_record_seq,ev);
      drains++;last_drain=accepted_record_seq;
    end
  endtask
  always @(accepted_record_seq) if(monitor_ready && accepted_record_seq!=0)begin
    bw_u64_t e_seq;
    bw_u64_t e_epoch;
    bw_u64_t e_tick;
    bw_u64_t e_edge_index;
    bw_u64_t e_byte_inc;
    bw_u64_t e_event_inc;
    bw_u64_t e_bytes_complete;
    bw_u64_t e_events_complete;
    bw_u64_t e_reset_points;
    bw_u64_t e_total_bytes;
    bw_u64_t e_total_events;
    bw_u64_t e_source_epoch;
    records++;
    rc=$fscanf(raw_fd,"%d %d %d %d %d %d %d %d %d %d %d %d\n",e_seq,e_epoch,e_tick,e_edge_index,e_byte_inc,e_event_inc,e_bytes_complete,e_events_complete,e_reset_points,e_total_bytes,e_total_events,e_source_epoch);
    if(rc!=12)$fatal(1,"HISTORY_REFERENCE_EOF scope=%s kind=raw checked=%0d",scope_id,records);
    e_tick+=measurement_start_ticks;
    if(accepted_record_seq!==e_seq)$fatal(1,"HISTORY_RAW_MISMATCH scope=%s checked=%0d field=seq actual=%0.17g expected=%0.17g",scope_id,records,accepted_record_seq,e_seq);
    if(stats_epoch!==e_epoch)$fatal(1,"HISTORY_RAW_MISMATCH scope=%s checked=%0d field=epoch actual=%0.17g expected=%0.17g",scope_id,records,stats_epoch,e_epoch);
    if(raw_record.timestamp_ticks!==e_tick)$fatal(1,"HISTORY_RAW_MISMATCH scope=%s checked=%0d field=tick actual=%0.17g expected=%0.17g",scope_id,records,raw_record.timestamp_ticks,e_tick);
    if(raw_record.edge_index!==e_edge_index)$fatal(1,"HISTORY_RAW_MISMATCH scope=%s checked=%0d field=edge_index actual=%0.17g expected=%0.17g",scope_id,records,raw_record.edge_index,e_edge_index);
    if(raw_record.byte_inc!==e_byte_inc)$fatal(1,"HISTORY_RAW_MISMATCH scope=%s checked=%0d field=byte_inc actual=%0.17g expected=%0.17g",scope_id,records,raw_record.byte_inc,e_byte_inc);
    if(raw_record.event_inc!==e_event_inc)$fatal(1,"HISTORY_RAW_MISMATCH scope=%s checked=%0d field=event_inc actual=%0.17g expected=%0.17g",scope_id,records,raw_record.event_inc,e_event_inc);
    if(raw_record.bytes_complete!==e_bytes_complete)$fatal(1,"HISTORY_RAW_MISMATCH scope=%s checked=%0d field=bytes_complete actual=%0.17g expected=%0.17g",scope_id,records,raw_record.bytes_complete,e_bytes_complete);
    if(raw_record.events_complete!==e_events_complete)$fatal(1,"HISTORY_RAW_MISMATCH scope=%s checked=%0d field=events_complete actual=%0.17g expected=%0.17g",scope_id,records,raw_record.events_complete,e_events_complete);
    if(raw_record.reset_points!==e_reset_points)$fatal(1,"HISTORY_RAW_MISMATCH scope=%s checked=%0d field=reset_points actual=%0.17g expected=%0.17g",scope_id,records,raw_record.reset_points,e_reset_points);
    if(total_bytes!==e_total_bytes)$fatal(1,"HISTORY_RAW_MISMATCH scope=%s checked=%0d field=total_bytes actual=%0.17g expected=%0.17g",scope_id,records,total_bytes,e_total_bytes);
    if(total_events!==e_total_events)$fatal(1,"HISTORY_RAW_MISMATCH scope=%s checked=%0d field=total_events actual=%0.17g expected=%0.17g",scope_id,records,total_events,e_total_events);
    if(raw_record.source_epoch!==e_source_epoch)$fatal(1,"HISTORY_RAW_MISMATCH scope=%s checked=%0d field=source_epoch actual=%0.17g expected=%0.17g",scope_id,records,raw_record.source_epoch,e_source_epoch);
    if(raw_record.record_seq!=records)$fatal(1,"HISTORY_ORIGINAL_SEQUENCE");
  end
  always @(result_seq) if(monitor_ready && result_seq!=0)begin
    bw_u64_t e_seq;
    bw_u64_t e_epoch;
    bw_u64_t e_left;
    bw_u64_t e_right;
    bw_u64_t e_left_cycle;
    bw_u64_t e_right_cycle;
    bw_u64_t e_coverage_ticks;
    bw_u64_t e_coverage_cycles;
    bw_u64_t e_bytes;
    bw_u64_t e_events;
    bw_u64_t e_warmup;
    bw_u64_t e_full;
    bw_u64_t e_bytes_complete;
    bw_u64_t e_events_complete;
    bw_u64_t e_denominator_valid;
    bw_u64_t e_window_valid;
    bw_u64_t e_reset;
    real e_gbps;
    real e_bpc;
    windows++;
    rc=$fscanf(window_fd,"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %f %f\n",e_seq,e_epoch,e_left,e_right,e_left_cycle,e_right_cycle,e_coverage_ticks,e_coverage_cycles,e_bytes,e_events,e_warmup,e_full,e_bytes_complete,e_events_complete,e_denominator_valid,e_window_valid,e_reset,e_gbps,e_bpc);
    if(rc!=19)$fatal(1,"HISTORY_REFERENCE_EOF scope=%s kind=window checked=%0d",scope_id,windows);
    e_left+=measurement_start_ticks;
    e_right+=measurement_start_ticks;
    if(result_seq!==e_seq)$fatal(1,"HISTORY_WINDOW_MISMATCH scope=%s checked=%0d field=seq actual=%0.17g expected=%0.17g",scope_id,windows,result_seq,e_seq);
    if(stats_epoch!==e_epoch)$fatal(1,"HISTORY_WINDOW_MISMATCH scope=%s checked=%0d field=epoch actual=%0.17g expected=%0.17g",scope_id,windows,stats_epoch,e_epoch);
    if(window_start_ticks!==e_left)$fatal(1,"HISTORY_WINDOW_MISMATCH scope=%s checked=%0d field=left actual=%0.17g expected=%0.17g",scope_id,windows,window_start_ticks,e_left);
    if(window_end_ticks!==e_right)$fatal(1,"HISTORY_WINDOW_MISMATCH scope=%s checked=%0d field=right actual=%0.17g expected=%0.17g",scope_id,windows,window_end_ticks,e_right);
    if(window_start_cycle!==e_left_cycle)$fatal(1,"HISTORY_WINDOW_MISMATCH scope=%s checked=%0d field=left_cycle actual=%0.17g expected=%0.17g",scope_id,windows,window_start_cycle,e_left_cycle);
    if(window_end_cycle!==e_right_cycle)$fatal(1,"HISTORY_WINDOW_MISMATCH scope=%s checked=%0d field=right_cycle actual=%0.17g expected=%0.17g",scope_id,windows,window_end_cycle,e_right_cycle);
    if(coverage_ticks!==e_coverage_ticks)$fatal(1,"HISTORY_WINDOW_MISMATCH scope=%s checked=%0d field=coverage_ticks actual=%0.17g expected=%0.17g",scope_id,windows,coverage_ticks,e_coverage_ticks);
    if(coverage_cycles!==e_coverage_cycles)$fatal(1,"HISTORY_WINDOW_MISMATCH scope=%s checked=%0d field=coverage_cycles actual=%0.17g expected=%0.17g",scope_id,windows,coverage_cycles,e_coverage_cycles);
    if(window_bytes!==e_bytes)$fatal(1,"HISTORY_WINDOW_MISMATCH scope=%s checked=%0d field=bytes actual=%0.17g expected=%0.17g",scope_id,windows,window_bytes,e_bytes);
    if(window_events!==e_events)$fatal(1,"HISTORY_WINDOW_MISMATCH scope=%s checked=%0d field=events actual=%0.17g expected=%0.17g",scope_id,windows,window_events,e_events);
    if(window_warmup!==e_warmup)$fatal(1,"HISTORY_WINDOW_MISMATCH scope=%s checked=%0d field=warmup actual=%0.17g expected=%0.17g",scope_id,windows,window_warmup,e_warmup);
    if(window_full!==e_full)$fatal(1,"HISTORY_WINDOW_MISMATCH scope=%s checked=%0d field=full actual=%0.17g expected=%0.17g",scope_id,windows,window_full,e_full);
    if(bytes_complete!==e_bytes_complete)$fatal(1,"HISTORY_WINDOW_MISMATCH scope=%s checked=%0d field=bytes_complete actual=%0.17g expected=%0.17g",scope_id,windows,bytes_complete,e_bytes_complete);
    if(events_complete!==e_events_complete)$fatal(1,"HISTORY_WINDOW_MISMATCH scope=%s checked=%0d field=events_complete actual=%0.17g expected=%0.17g",scope_id,windows,events_complete,e_events_complete);
    if(denominator_valid!==e_denominator_valid)$fatal(1,"HISTORY_WINDOW_MISMATCH scope=%s checked=%0d field=denominator_valid actual=%0.17g expected=%0.17g",scope_id,windows,denominator_valid,e_denominator_valid);
    if(window_valid!==e_window_valid)$fatal(1,"HISTORY_WINDOW_MISMATCH scope=%s checked=%0d field=window_valid actual=%0.17g expected=%0.17g",scope_id,windows,window_valid,e_window_valid);
    if(member_reset_coverage!==e_reset)$fatal(1,"HISTORY_WINDOW_MISMATCH scope=%s checked=%0d field=reset actual=%0.17g expected=%0.17g",scope_id,windows,member_reset_coverage,e_reset);
    if(!close_real(bandwidth_gbps,e_gbps))$fatal(1,"HISTORY_WINDOW_MISMATCH scope=%s checked=%0d field=gbps actual=%0.17g expected=%0.17g",scope_id,windows,bandwidth_gbps,e_gbps);
    if(!close_real(bytes_per_cycle,e_bpc))$fatal(1,"HISTORY_WINDOW_MISMATCH scope=%s checked=%0d field=bpc actual=%0.17g expected=%0.17g",scope_id,windows,bytes_per_cycle,e_bpc);
  end
  always @(observation_end or local_done or windows or records)begin
    if(observation_end && local_done && !done && windows==expected_windows(scope_index) && records==EDGES)begin
      bw_u64_t surplus;
      if($fscanf(raw_fd,"%d",surplus)!=-1 || $fscanf(window_fd,"%d",surplus)!=-1)
        $fatal(1,"HISTORY_REFERENCE_UNCONSUMED scope=%s",scope_id);
      if(retained_frame_count(source_handle)!=0 || retained_control_count(source_handle)!=0)
        $fatal(1,"HISTORY_TRANSPORT_NOT_RELEASED scope=%s",scope_id);
      done=1;
      $fdisplay(actual_fd,"%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d",scope_index,records,windows,total_bytes,total_events,event_peak,clock_peak,phase_peak,ep_runs_peak,ep_count_peak,ph_runs_peak,ph_count_peak,event_final,clock_final,retained_frame_count(source_handle),retained_control_count(source_handle),drains);
      $fclose(raw_fd);$fclose(window_fd);completed_scopes++;
    end
  end
endmodule
