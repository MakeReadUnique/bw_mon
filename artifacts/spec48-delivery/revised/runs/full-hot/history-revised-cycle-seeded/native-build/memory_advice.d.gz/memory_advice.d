memory_advice.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/60ff0cd0557e28dab79e0c6227113c4e8d131e622dd022a42faec51b5756ec3d/source/tests/scale/memory_advice.c
