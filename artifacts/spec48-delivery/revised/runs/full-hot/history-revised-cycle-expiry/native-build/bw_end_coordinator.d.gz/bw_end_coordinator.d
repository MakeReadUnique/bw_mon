bw_end_coordinator.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/0e86fe63287f04c9dbe34e69ca2a456f2bade2d197d75857bfb35d1a90cb7c68/source/rtl/bw_end_coordinator.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
