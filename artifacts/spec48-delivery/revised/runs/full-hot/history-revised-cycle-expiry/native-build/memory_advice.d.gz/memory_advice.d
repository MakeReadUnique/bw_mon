memory_advice.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/0e86fe63287f04c9dbe34e69ca2a456f2bade2d197d75857bfb35d1a90cb7c68/source/tests/scale/memory_advice.c
