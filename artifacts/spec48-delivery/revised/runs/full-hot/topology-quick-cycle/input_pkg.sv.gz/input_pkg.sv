package bw_scale_input_pkg;
  timeunit 1fs;timeprecision 1fs;
  typedef longint unsigned ref_u64;
  localparam ref_u64 POINTS=64'd128;
  localparam ref_u64 GROUPS=64'd32;
  localparam ref_u64 SCOPES=64'd160;
  localparam ref_u64 EDGES=64'd512;
  localparam ref_u64 END_TICKS=64'd256000000;
  localparam ref_u64 BASIS=64'd1;
  localparam ref_u64 WIDTH=64'd128;
  localparam ref_u64 STRIDE=64'd1;
  localparam ref_u64 RESET_START=64'd100100000;
  localparam ref_u64 RESET_END=64'd101100000;
  localparam ref_u64 UNKNOWN_TICK=64'd96250000;
  localparam ref_u64 ACTIVE_EDGES=64'd384;
  localparam ref_u64 UNKNOWN_EDGE=64'd193;
  localparam ref_u64 GROUP_RESET_START=64'd128100000;
  localparam ref_u64 GROUP_RESET_END=64'd129100000;
  localparam ref_u64 GATE_EDGE=64'd203;
  localparam ref_u64 RELEASE_TICK=64'd101250000;
  localparam ref_u64 CONTROL_HOLD_TICK=64'd101100000;
  localparam ref_u64 SLOW_CONSUMER=64'd8;
  localparam ref_u64 TIMER_BOUND_NS=64'd101;
  localparam ref_u64 CYCLE_WATERMARK=64'd202;
  localparam ref_u64 SLOW_ACK=64'd202;
  localparam ref_u64 HELD_FRAMES=64'd1;
  localparam ref_u64 HELD_CONTROLS=64'd1;
  int variant=0; //0 baseline,1 unknown-size on p0,2 p0 known reset.
  int actual_fd=0,resource_fd=0,edge_fd=0,completed_scopes=0,resources_done=0;
  ref_u64 input_edge=0;
  bit observation_end=0;
typedef struct {
  ref_u64 seq;
  ref_u64 epoch;
  ref_u64 left;
  ref_u64 right;
  ref_u64 left_cycle;
  ref_u64 right_cycle;
  ref_u64 coverage_ticks;
  ref_u64 coverage_cycles;
  ref_u64 bytes;
  ref_u64 events;
  ref_u64 warmup;
  ref_u64 full;
  ref_u64 bytes_complete;
  ref_u64 events_complete;
  ref_u64 denominator_valid;
  ref_u64 window_valid;
  ref_u64 reset;
  real gbps;
  real bpc;
} ref_window_t;
typedef struct {
  ref_u64 seq;
  ref_u64 epoch;
  ref_u64 tick;
  ref_u64 edge_index;
  ref_u64 byte_inc;
  ref_u64 event_inc;
  ref_u64 bytes_complete;
  ref_u64 events_complete;
  ref_u64 reset_points;
  ref_u64 total_bytes;
  ref_u64 total_events;
  ref_u64 source_epoch;
} ref_raw_t;
  function automatic ref_u64 clock_tick(ref_u64 edge_index);
    ref_u64 k;k=edge_index;
    if(k<=512)return 250000+(k-1)*500000;k-=512;
    $fatal(1,"SCALE_REFERENCE_CLOCK edge_index=%0d",edge_index);return 0;
  endfunction
  function automatic ref_u64 rank_lt(ref_u64 tick);
    ref_u64 n,total;total=0;
    n=0;if(tick>250000)n=(tick-250000+500000-1)/500000;if(n>512)n=512;total+=n;
    return total;
  endfunction
  function automatic ref_u64 cardinality(bit is_group,int index);
    if(!is_group)return 1;
    case(index)
      0:return 3;
      1:return 4;
      2:return 5;
      3:return 6;
      4:return 7;
      5:return 8;
      6:return 9;
      7:return 10;
      8:return 4;
      9:return 4;
      10:return 4;
      11:return 4;
      12:return 4;
      13:return 4;
      14:return 4;
      15:return 4;
      16:return 4;
      17:return 4;
      18:return 4;
      19:return 4;
      20:return 4;
      21:return 4;
      22:return 4;
      23:return 8;
      24:return 8;
      25:return 8;
      26:return 8;
      27:return 8;
      28:return 8;
      29:return 8;
      30:return 8;
      31:return 8;
      default:$fatal(1,"SCALE_REFERENCE_GROUP index=%0d",index);
    endcase
    return 0;
  endfunction
  function automatic ref_u64 direct_count(int index);
    case(index)
      0:return 3;
      1:return 2;
      2:return 2;
      3:return 2;
      4:return 2;
      5:return 2;
      6:return 2;
      7:return 2;
      8:return 2;
      9:return 2;
      10:return 2;
      11:return 2;
      12:return 2;
      13:return 2;
      14:return 2;
      15:return 2;
      16:return 2;
      17:return 2;
      18:return 2;
      19:return 2;
      20:return 2;
      21:return 2;
      22:return 2;
      23:return 8;
      24:return 8;
      25:return 8;
      26:return 8;
      27:return 8;
      28:return 8;
      29:return 8;
      30:return 8;
      31:return 8;
      default:$fatal(1,"SCALE_REFERENCE_GROUP index=%0d",index);
    endcase
    return 0;
  endfunction
  function automatic bit affected(bit is_group,int index);
    if(!is_group)return index==0;
    case(index)
      0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22:return 1;
      default:return 0;
    endcase
  endfunction
  function automatic string expected_id(bit is_group,int index);
    if(is_group)return $sformatf("scale.g%0d",index);
    return $sformatf("tb_bw_scale.points[%0d].slot.mon",index);
  endfunction
  function automatic ref_u64 leaf_weight(bit is_group,int index);
    if(!is_group)return index+1;
    case(index)
      0:return 6;
      1:return 10;
      2:return 15;
      3:return 21;
      4:return 28;
      5:return 36;
      6:return 45;
      7:return 55;
      8:return 17;
      9:return 18;
      10:return 19;
      11:return 20;
      12:return 21;
      13:return 22;
      14:return 23;
      15:return 24;
      16:return 25;
      17:return 26;
      18:return 27;
      19:return 28;
      20:return 29;
      21:return 30;
      22:return 31;
      23:return 236;
      24:return 300;
      25:return 364;
      26:return 428;
      27:return 492;
      28:return 556;
      29:return 620;
      30:return 684;
      31:return 748;
      default:$fatal(1,"TOPOLOGY_REFERENCE_WEIGHT");
    endcase
    return 0;
  endfunction

  function automatic ref_u64 reset_begin(bit is_group,int index);
    if(index!=0)return 0;
    return is_group ? GROUP_RESET_START : RESET_START;
  endfunction
  function automatic ref_u64 reset_release(bit is_group,int index);
    return is_group ? GROUP_RESET_END : RESET_END;
  endfunction
  function automatic ref_u64 pre_reset_count(bit is_group,int index);
    ref_u64 t;t=reset_begin(is_group,index);
    if(t==0)return 0;
    if(BASIS==0)return t/(STRIDE*1000000);
    return (rank_lt(t)-1)/STRIDE;
  endfunction
  function automatic ref_u64 publication_count(bit is_group,int index);
    if(index==0)begin
      if(BASIS==0)return pre_reset_count(is_group,index)+(END_TICKS-reset_release(is_group,index))/(STRIDE*1000000);
      return pre_reset_count(is_group,index)+(EDGES-rank_lt(reset_release(is_group,index))-1)/STRIDE;
    end
    if(BASIS==0)return END_TICKS/(STRIDE*1000000);
    return (EDGES-1)/STRIDE;
  endfunction
  function automatic ref_window_t interval_counts(bit is_group,int index,ref_u64 left,ref_u64 right);
    ref_window_t v;ref_u64 a,b,lo,hi,n,odd,m;
    m=cardinality(is_group,index);lo=rank_lt(left);hi=rank_lt(right);
    if(lo>ACTIVE_EDGES)lo=ACTIVE_EDGES;if(hi>ACTIVE_EDGES)hi=ACTIVE_EDGES;
    n=hi-lo;odd=(hi+1)/2-(lo+1)/2;
    v.bytes=leaf_weight(is_group,index)*n+3*m*odd;v.events=m*n;
    v.bytes_complete=1;v.events_complete=1;v.reset=0;
    if(affected(is_group,index) && left<=UNKNOWN_TICK && UNKNOWN_TICK<right)begin v.bytes-=4;v.bytes_complete=0;end
    a=(left>RESET_START)?left:RESET_START;b=(right<RESET_END)?right:RESET_END;
    if(affected(is_group,index) && a<b)begin
      lo=rank_lt(a);hi=rank_lt(b);v.bytes-=hi-lo+3*((hi+1)/2-(lo+1)/2);v.events-=hi-lo;v.reset=is_group;
    end
    return v;
  endfunction
  function automatic ref_window_t reference_window(ref_u64 seq,bit is_group,int index);
    ref_window_t v;ref_u64 rank,origin,anchor,left,right,lc,rc,cc;bit after_reset,full;
    after_reset=index==0 && seq>pre_reset_count(is_group,index);
    rank=after_reset ? seq-pre_reset_count(is_group,index) : seq;origin=after_reset ? reset_release(is_group,index) : 0;
    lc=0;rc=0;cc=0;
    if(BASIS==0)begin
      right=origin+rank*STRIDE*1000000;left=(right-origin>=WIDTH*1000000)?right-WIDTH*1000000:origin;
      full=right-origin>=WIDTH*1000000;
    end else begin
      anchor=rank_lt(origin)+1;rc=anchor+rank*STRIDE;lc=(rc-anchor>=WIDTH)?rc-WIDTH:anchor;
      left=clock_tick(lc);right=clock_tick(rc);cc=rc-lc;full=cc==WIDTH;
    end
    v=interval_counts(is_group,index,left,right);v.seq=seq;v.epoch=after_reset;v.left=bw_mon_pkg::measurement_start_ticks+left;v.right=bw_mon_pkg::measurement_start_ticks+right;
    v.left_cycle=lc;v.right_cycle=rc;v.coverage_ticks=right-left;v.coverage_cycles=cc;v.full=full;v.warmup=!full;
    v.denominator_valid=right>left;v.window_valid=full && v.bytes_complete && v.denominator_valid;
    v.gbps=v.denominator_valid ? real'(v.bytes)*1000000.0/real'(right-left) : 0;
    v.bpc=(cc!=0)?real'(v.bytes)/real'(cc):0;return v;
  endfunction
  function automatic ref_raw_t reference_raw(ref_u64 edge_index,bit is_group,int index);
    ref_raw_t r;ref_window_t v,total;ref_u64 tick,left;bit epoch;
    tick=clock_tick(edge_index);epoch=index==0 && tick>=reset_begin(is_group,index);left=epoch ? reset_release(is_group,index) : 0;
    v=interval_counts(is_group,index,tick,tick+1);
    if(epoch && tick<left)begin total.bytes=0;total.events=0;end
    else total=interval_counts(is_group,index,left,tick+1);
    r.seq=edge_index;r.epoch=epoch;r.tick=bw_mon_pkg::measurement_start_ticks+tick;r.edge_index=edge_index;r.byte_inc=v.bytes;r.event_inc=v.events;
    r.bytes_complete=v.bytes_complete;r.events_complete=v.events_complete;
    r.reset_points=affected(is_group,index) && RESET_START<=tick && tick<RESET_END;
    r.total_bytes=total.bytes;r.total_events=total.events;
    r.source_epoch=!is_group && index==0 && tick>=RESET_START;return r;
  endfunction
  function automatic bit close_real(real actual,real expected);
    return $abs(actual-expected)<=1e-9+1e-12*$abs(expected);
  endfunction
endpackage
