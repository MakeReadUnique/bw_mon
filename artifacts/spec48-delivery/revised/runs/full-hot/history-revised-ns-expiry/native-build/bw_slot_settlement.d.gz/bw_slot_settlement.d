bw_slot_settlement.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/bc1bfb3f02a175b61fca6fe013c6af31916b14a60ad9cb100bffa4f5e88b7a16/source/rtl/bw_slot_settlement.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
