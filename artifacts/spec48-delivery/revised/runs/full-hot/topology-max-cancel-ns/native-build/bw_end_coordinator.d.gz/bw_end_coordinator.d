bw_end_coordinator.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/654b6f3f0d11c016fe4cec51357ea07fba6325d149d62d1cea423c9e5a83c98b/source/rtl/bw_end_coordinator.c \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/svdpi.h \
 /home/eda/app/synopsys/vcs/W-2024.09-SP1/include/vpi_user.h
