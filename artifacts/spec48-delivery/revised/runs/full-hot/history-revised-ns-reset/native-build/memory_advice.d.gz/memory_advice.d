memory_advice.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/8e6534768c78c40c9b1af21d61bbe1ac1e52d29b988d0aa3200630c56a63a87c/source/tests/scale/memory_advice.c
