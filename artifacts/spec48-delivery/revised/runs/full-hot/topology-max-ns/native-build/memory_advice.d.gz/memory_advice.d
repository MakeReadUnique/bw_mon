memory_advice.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/8484ab968b60302b301875cdaf3d8ea488e1f3b3ddd94b781f6b3324dc614a52/source/tests/scale/memory_advice.c
