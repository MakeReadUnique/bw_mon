memory_advice.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/09efd0159b28c9ba932cac80b378f1051fef1bd33a8906f8def915b32905c99c/source/tests/scale/memory_advice.c
