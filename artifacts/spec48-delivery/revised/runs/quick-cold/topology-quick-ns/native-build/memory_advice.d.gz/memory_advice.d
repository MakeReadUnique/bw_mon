memory_advice.o: \
 /home/eda/bw-mon-ticket62-candidate-runs/revised/builds/6ce16cbab27afdd7a60ba8d786217c7e7516b4b0facea6627461e6ce916c9ad6/source/tests/scale/memory_advice.c
