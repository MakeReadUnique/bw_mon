module bw_scale_point #(parameter bw_mon_pkg::bw_protocol_t PROTOCOL=bw_mon_pkg::BW_VALID_ONLY,parameter bit DYNAMIC=0)
  (input logic clk,input int scope_index);
  timeunit 1fs;timeprecision 1fs;
  import bw_mon_pkg::*;import bw_scale_input_pkg::*;
  logic reset_n=1;logic [63:0] size_bytes;bit local_done=0;
  always_comb begin
    size_bytes=scope_index+1+3*(input_edge%2);
    if(scope_index==0 && input_edge==UNKNOWN_EDGE)size_bytes='x;
  end
  initial begin
    wait(monitor_ready);
    if(scope_index==0 && variant==2)begin #RESET_START;reset_n=0;#(RESET_END-RESET_START);reset_n=1;end
  end
  bw_point_mon #(.WINDOW_BASIS(bw_mon_pkg::bw_basis_t'(bw_scale_input_pkg::BASIS)),.WINDOW_WIDTH(bw_scale_input_pkg::WIDTH),.UPDATE_STRIDE(bw_scale_input_pkg::STRIDE),.FIXED_BYTES(64),.DYNAMIC_BYTES(DYNAMIC),.PROTOCOL(PROTOCOL),
    .CREDIT_ENABLE(PROTOCOL==BW_CREDIT),.CREDIT_CAPACITY(16),.CREDIT_INITIAL(16),.CREDIT_INITIAL_KNOWN(1),.CREDIT_RETURN_TIMING(BW_RETURN_NEXT_CYCLE),
    .BACKPRESSURE_ENABLE(PROTOCOL==BW_VALID_READY),.BACKPRESSURE_BASIS(bw_basis_t'(BASIS)),.BACKPRESSURE_THRESHOLD(4),
    .SHORTAGE_ENABLE(PROTOCOL==BW_CREDIT),.SHORTAGE_BASIS(bw_basis_t'(BASIS)),.SHORTAGE_THRESHOLD(4),.EPISODE_ENABLE(1),.SILENCE_THRESHOLD(30)) mon
    (.clk(clk),.reset_n(reset_n),.valid(input_edge<=ACTIVE_EDGES),.ready(1'b1),.flitv(input_edge<=ACTIVE_EDGES),.lcrdv(input_edge<=ACTIVE_EDGES),.size_bytes(size_bytes),.size_known(1'b1));
  bw_scale_checker checker(.is_group(1'b0),
    .scope_index(scope_index),
    .scope_id(mon.scope_id),
    .local_done(local_done),
    .source_handle(mon.transport_source),
    .raw_record(mon.raw_record),
    .accepted_record_seq(mon.accepted_record_seq),
    .result_seq(64'(mon.result_seq)),
    .stats_epoch(64'(mon.stats_epoch)),
    .window_start_ticks(64'(mon.window_start_ticks)),
    .window_end_ticks(64'(mon.window_end_ticks)),
    .window_start_cycle(64'(mon.window_start_cycle)),
    .window_end_cycle(64'(mon.window_end_cycle)),
    .coverage_ticks(64'(mon.coverage_ticks)),
    .coverage_cycles(64'(mon.coverage_cycles)),
    .window_bytes(64'(mon.window_bytes)),
    .window_events(64'(mon.window_events)),
    .window_warmup(64'(mon.window_warmup)),
    .window_full(64'(mon.window_full)),
    .bytes_complete(64'(mon.bytes_complete)),
    .events_complete(64'(mon.events_complete)),
    .denominator_valid(64'(mon.denominator_valid)),
    .window_valid(64'(mon.window_valid)),
    .member_reset_coverage(64'(mon.member_reset_coverage)),
    .bandwidth_gbps(mon.bandwidth_gbps),
    .bytes_per_cycle(mon.bytes_per_cycle),
    .total_bytes(mon.total_bytes),
    .total_events(mon.total_events));
  always @(observation_end)if(observation_end)begin
    if(mon.raw_control.control_seq!=((scope_index==0 && variant==2)?3:1) ||
       mon.backpressure_supported!=(PROTOCOL==BW_VALID_READY) || mon.backpressure_enabled!=(PROTOCOL==BW_VALID_READY) ||
       mon.shortage_supported!=(PROTOCOL==BW_CREDIT) || mon.shortage_enabled!=(PROTOCOL==BW_CREDIT) ||
       mon.backpressure_hit_count!=0 || mon.shortage_hit_count!=0 ||
       ((PROTOCOL==BW_CREDIT) && (!mon.credit_trusted || mon.credit_anomaly || mon.credit_balance!=16)))
      $fatal(1,"SCALE_HINT_CONTROL_MISMATCH scope=%s protocol=%0d",mon.scope_id,PROTOCOL);
    local_done=1;
  end

  ref_u64 history_peak=0,clock_peak=0,episode_pending_peak=0,phase_pending_peak=0,frame_peak=0,control_peak=0;
  ref_u64 pending_frames_peak=0,pending_controls_peak=0,pending_timers_peak=0,confirmed_phases=0;
  task automatic observe_resources();
    ref_u64 n;
    if(mon.core.history.size()>history_peak)history_peak=mon.core.history.size();
    if(mon.core.clock_runs.size()>clock_peak)clock_peak=mon.core.clock_runs.size();
    n=0;foreach(mon.core.episode_pending_samples[i])n+=mon.core.episode_pending_samples[i].count;
    if(n>episode_pending_peak)episode_pending_peak=n;
    n=0;foreach(mon.core.phase_pending_samples[i])n+=mon.core.phase_pending_samples[i].count;
    if(n>phase_pending_peak)phase_pending_peak=n;
    if(retained_frame_count(mon.transport_source)>frame_peak)frame_peak=retained_frame_count(mon.transport_source);
    if(retained_control_count(mon.transport_source)>control_peak)control_peak=retained_control_count(mon.transport_source);
    if(mon.core.pending_frames.size()>pending_frames_peak)pending_frames_peak=mon.core.pending_frames.size();
    if(mon.core.pending_member_controls.size()>pending_controls_peak)pending_controls_peak=mon.core.pending_member_controls.size();
    if(mon.core.pending_timers.size()>pending_timers_peak)pending_timers_peak=mon.core.pending_timers.size();
    if(mon.phase_active && mon.phase_confirmation_ticks!=0)confirmed_phases=1;
  endtask
  always @(mon.accepted_record_seq or mon.result_seq or mon.raw_record or mon.raw_control or mon.phase_result_seq)
    if(monitor_ready)observe_resources();
  always @(observation_end)if(observation_end)begin
    observe_resources();
    if(confirmed_phases==0)$fatal(1,"TOPOLOGY_NO_CONFIRMED_PHASE scope=%s",mon.scope_id);
    $fdisplay(resource_fd,"point,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d",
      scope_index,history_peak,clock_peak,episode_pending_peak,phase_pending_peak,frame_peak,control_peak,
      pending_frames_peak,pending_controls_peak,pending_timers_peak,
      mon.core.history.size(),mon.core.clock_runs.size(),mon.core.episode_pending_samples.size(),mon.core.phase_pending_samples.size(),
      retained_frame_count(mon.transport_source),retained_control_count(mon.transport_source));
    resources_done++;
  end
endmodule
module bw_scale_group #(parameter string GROUP_ID="") (input logic clk,input int scope_index);
  timeunit 1fs;timeprecision 1fs;
  import bw_mon_pkg::*;import bw_scale_input_pkg::*;
  bit local_done=0;logic stats_reset_n=1;
  initial begin
    wait(monitor_ready);
    if(scope_index==0)begin #GROUP_RESET_START;stats_reset_n=0;#(GROUP_RESET_END-GROUP_RESET_START);stats_reset_n=1;end
  end
  bw_group_mon #(.GROUP_ID(GROUP_ID),.WINDOW_BASIS(bw_mon_pkg::bw_basis_t'(bw_scale_input_pkg::BASIS)),.WINDOW_WIDTH(bw_scale_input_pkg::WIDTH),.UPDATE_STRIDE(bw_scale_input_pkg::STRIDE),.EPISODE_ENABLE(1),.SILENCE_THRESHOLD(30)) mon(.clk(clk),.reset_n(stats_reset_n));
  bw_scale_checker checker(.is_group(1'b1),
    .scope_index(scope_index),
    .scope_id(mon.scope_id),
    .local_done(local_done),
    .source_handle(mon.transport_source),
    .raw_record(mon.raw_record),
    .accepted_record_seq(mon.accepted_record_seq),
    .result_seq(64'(mon.result_seq)),
    .stats_epoch(64'(mon.stats_epoch)),
    .window_start_ticks(64'(mon.window_start_ticks)),
    .window_end_ticks(64'(mon.window_end_ticks)),
    .window_start_cycle(64'(mon.window_start_cycle)),
    .window_end_cycle(64'(mon.window_end_cycle)),
    .coverage_ticks(64'(mon.coverage_ticks)),
    .coverage_cycles(64'(mon.coverage_cycles)),
    .window_bytes(64'(mon.window_bytes)),
    .window_events(64'(mon.window_events)),
    .window_warmup(64'(mon.window_warmup)),
    .window_full(64'(mon.window_full)),
    .bytes_complete(64'(mon.bytes_complete)),
    .events_complete(64'(mon.events_complete)),
    .denominator_valid(64'(mon.denominator_valid)),
    .window_valid(64'(mon.window_valid)),
    .member_reset_coverage(64'(mon.member_reset_coverage)),
    .bandwidth_gbps(mon.bandwidth_gbps),
    .bytes_per_cycle(mon.bytes_per_cycle),
    .total_bytes(mon.total_bytes),
    .total_events(mon.total_events));
  always @(observation_end)if(observation_end)begin
    if(mon.direct_member_count!=direct_count(scope_index) || mon.recursive_point_count!=cardinality(1,scope_index) ||
       mon.accepted_control_count!=cardinality(1,scope_index)+((variant==2 && affected(1,scope_index))?2:0))
      $fatal(1,"SCALE_GROUP_MEMBERS_CONTROLS scope=%s",mon.scope_id);
    for(int m=0;m<mon.direct_member_count;m++)
      $fdisplay(edge_fd,"%0d,%0d,%s,%s",scope_index,m,source_kind_name(member_source(mon.group_handle,m)),source_name(member_source(mon.group_handle,m)));
    for(int m=0;m<mon.direct_member_count;m++)
      if(acknowledged_frame_seq(mon.group_handle,m)!=EDGES)$fatal(1,"SCALE_ACK_MISMATCH scope=%s member=%0d",mon.scope_id,m);
    local_done=1;
  end

  always @(mon.raw_record or mon.accepted_record_seq)if(monitor_ready && mon.direct_member_count!=0)begin
    for(int i=0;i<mon.direct_member_count;i++)
      if(acknowledged_frame_seq(mon.group_handle,i)>mon.accepted_record_seq)
        $fatal(1,"TOPOLOGY_ACK_BEFORE_ACCEPT scope=%s",mon.scope_id);
  end

  ref_u64 history_peak=0,clock_peak=0,episode_pending_peak=0,phase_pending_peak=0,frame_peak=0,control_peak=0;
  ref_u64 pending_frames_peak=0,pending_controls_peak=0,pending_timers_peak=0,confirmed_phases=0;
  task automatic observe_resources();
    ref_u64 n;
    if(mon.core.history.size()>history_peak)history_peak=mon.core.history.size();
    if(mon.core.clock_runs.size()>clock_peak)clock_peak=mon.core.clock_runs.size();
    n=0;foreach(mon.core.episode_pending_samples[i])n+=mon.core.episode_pending_samples[i].count;
    if(n>episode_pending_peak)episode_pending_peak=n;
    n=0;foreach(mon.core.phase_pending_samples[i])n+=mon.core.phase_pending_samples[i].count;
    if(n>phase_pending_peak)phase_pending_peak=n;
    if(retained_frame_count(mon.transport_source)>frame_peak)frame_peak=retained_frame_count(mon.transport_source);
    if(retained_control_count(mon.transport_source)>control_peak)control_peak=retained_control_count(mon.transport_source);
    if(mon.core.pending_frames.size()>pending_frames_peak)pending_frames_peak=mon.core.pending_frames.size();
    if(mon.core.pending_member_controls.size()>pending_controls_peak)pending_controls_peak=mon.core.pending_member_controls.size();
    if(mon.core.pending_timers.size()>pending_timers_peak)pending_timers_peak=mon.core.pending_timers.size();
    if(mon.phase_active && mon.phase_confirmation_ticks!=0)confirmed_phases=1;
  endtask
  always @(mon.accepted_record_seq or mon.result_seq or mon.raw_record or mon.raw_control or mon.phase_result_seq)
    if(monitor_ready)observe_resources();
  always @(observation_end)if(observation_end)begin
    observe_resources();
    if(confirmed_phases==0)$fatal(1,"TOPOLOGY_NO_CONFIRMED_PHASE scope=%s",mon.scope_id);
    $fdisplay(resource_fd,"group,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d",
      scope_index,history_peak,clock_peak,episode_pending_peak,phase_pending_peak,frame_peak,control_peak,
      pending_frames_peak,pending_controls_peak,pending_timers_peak,
      mon.core.history.size(),mon.core.clock_runs.size(),mon.core.episode_pending_samples.size(),mon.core.phase_pending_samples.size(),
      retained_frame_count(mon.transport_source),retained_control_count(mon.transport_source));
    resources_done++;
  end
endmodule
module tb_bw_scale;
  timeunit 1fs;timeprecision 1fs;
  import bw_mon_pkg::*;import bw_scale_input_pkg::*;
  logic clk=0;bit deadline=0;string variant_name,actual_path;
  bw_test_consumer_gate slow_gate;
  bw_mon_setup setup();
  for(genvar p=0;p<POINTS;p++)begin:points
    bw_scale_point #(.PROTOCOL(bw_protocol_t'(p%3)),.DYNAMIC(1)) slot(.clk(clk),.scope_index(p));
  end
  for(genvar g=0;g<GROUPS;g++)begin:groups
    bw_scale_group #(.GROUP_ID($sformatf("scale.g%0d",g))) slot(.clk(clk),.scope_index(g));
  end
  initial begin
    if(!$value$plusargs("VARIANT=%s",variant_name))variant_name="baseline";
    case(variant_name)"baseline":variant=0;"unknown":variant=1;"reset":variant=2;default:$fatal(1,"SCALE_VARIANT_INVALID");endcase
    if(!$value$plusargs("ACTUAL=%s",actual_path))actual_path="actual.csv";
    actual_fd=$fopen(actual_path,"w");if(actual_fd==0)$fatal(1,"SCALE_ACTUAL_OPEN");
    edge_fd=$fopen({actual_path,".edges.csv"},"w");
    $fdisplay(edge_fd,"group,member,kind,source");
    resource_fd=$fopen({actual_path,".resources.csv"},"w");
    $fdisplay(resource_fd,"kind,index,history_peak,clock_peak,episode_pending_peak,phase_pending_peak,frame_peak,control_peak,pending_frames_peak,pending_controls_peak,pending_timers_peak,history_final,clock_final,episode_pending_final,phase_pending_final,frames_final,controls_final");
    $fdisplay(actual_fd,"kind,index,scope,cardinality,direct_members,checked_windows,checked_records,window_seq,window_epoch,window_left,window_right,window_left_cycle,window_right_cycle,window_coverage_ticks,window_coverage_cycles,window_bytes,window_events,window_warmup,window_full,window_bytes_complete,window_events_complete,window_denominator_valid,window_window_valid,window_reset,window_gbps,window_bpc,raw_seq,raw_epoch,raw_tick,raw_edge_index,raw_byte_inc,raw_event_inc,raw_bytes_complete,raw_events_complete,raw_reset_points,raw_total_bytes,raw_total_events,raw_source_epoch,diff_count");
    add_point_member("scale.g0","tb_bw_scale.points[0].slot.mon");
    add_point_member("scale.g0","tb_bw_scale.points[1].slot.mon");
    add_point_member("scale.g0","tb_bw_scale.points[2].slot.mon");
    add_group_member("scale.g1","scale.g0");
    add_point_member("scale.g1","tb_bw_scale.points[3].slot.mon");
    add_group_member("scale.g2","scale.g1");
    add_point_member("scale.g2","tb_bw_scale.points[4].slot.mon");
    add_group_member("scale.g3","scale.g2");
    add_point_member("scale.g3","tb_bw_scale.points[5].slot.mon");
    add_group_member("scale.g4","scale.g3");
    add_point_member("scale.g4","tb_bw_scale.points[6].slot.mon");
    add_group_member("scale.g5","scale.g4");
    add_point_member("scale.g5","tb_bw_scale.points[7].slot.mon");
    add_group_member("scale.g6","scale.g5");
    add_point_member("scale.g6","tb_bw_scale.points[8].slot.mon");
    add_group_member("scale.g7","scale.g6");
    add_point_member("scale.g7","tb_bw_scale.points[9].slot.mon");
    add_group_member("scale.g8","scale.g0");
    add_point_member("scale.g8","tb_bw_scale.points[10].slot.mon");
    add_group_member("scale.g9","scale.g0");
    add_point_member("scale.g9","tb_bw_scale.points[11].slot.mon");
    add_group_member("scale.g10","scale.g0");
    add_point_member("scale.g10","tb_bw_scale.points[12].slot.mon");
    add_group_member("scale.g11","scale.g0");
    add_point_member("scale.g11","tb_bw_scale.points[13].slot.mon");
    add_group_member("scale.g12","scale.g0");
    add_point_member("scale.g12","tb_bw_scale.points[14].slot.mon");
    add_group_member("scale.g13","scale.g0");
    add_point_member("scale.g13","tb_bw_scale.points[15].slot.mon");
    add_group_member("scale.g14","scale.g0");
    add_point_member("scale.g14","tb_bw_scale.points[16].slot.mon");
    add_group_member("scale.g15","scale.g0");
    add_point_member("scale.g15","tb_bw_scale.points[17].slot.mon");
    add_group_member("scale.g16","scale.g0");
    add_point_member("scale.g16","tb_bw_scale.points[18].slot.mon");
    add_group_member("scale.g17","scale.g0");
    add_point_member("scale.g17","tb_bw_scale.points[19].slot.mon");
    add_group_member("scale.g18","scale.g0");
    add_point_member("scale.g18","tb_bw_scale.points[20].slot.mon");
    add_group_member("scale.g19","scale.g0");
    add_point_member("scale.g19","tb_bw_scale.points[21].slot.mon");
    add_group_member("scale.g20","scale.g0");
    add_point_member("scale.g20","tb_bw_scale.points[22].slot.mon");
    add_group_member("scale.g21","scale.g0");
    add_point_member("scale.g21","tb_bw_scale.points[23].slot.mon");
    add_group_member("scale.g22","scale.g0");
    add_point_member("scale.g22","tb_bw_scale.points[24].slot.mon");
    add_point_member("scale.g23","tb_bw_scale.points[25].slot.mon");
    add_point_member("scale.g23","tb_bw_scale.points[26].slot.mon");
    add_point_member("scale.g23","tb_bw_scale.points[27].slot.mon");
    add_point_member("scale.g23","tb_bw_scale.points[28].slot.mon");
    add_point_member("scale.g23","tb_bw_scale.points[29].slot.mon");
    add_point_member("scale.g23","tb_bw_scale.points[30].slot.mon");
    add_point_member("scale.g23","tb_bw_scale.points[31].slot.mon");
    add_point_member("scale.g23","tb_bw_scale.points[32].slot.mon");
    add_point_member("scale.g24","tb_bw_scale.points[33].slot.mon");
    add_point_member("scale.g24","tb_bw_scale.points[34].slot.mon");
    add_point_member("scale.g24","tb_bw_scale.points[35].slot.mon");
    add_point_member("scale.g24","tb_bw_scale.points[36].slot.mon");
    add_point_member("scale.g24","tb_bw_scale.points[37].slot.mon");
    add_point_member("scale.g24","tb_bw_scale.points[38].slot.mon");
    add_point_member("scale.g24","tb_bw_scale.points[39].slot.mon");
    add_point_member("scale.g24","tb_bw_scale.points[40].slot.mon");
    add_point_member("scale.g25","tb_bw_scale.points[41].slot.mon");
    add_point_member("scale.g25","tb_bw_scale.points[42].slot.mon");
    add_point_member("scale.g25","tb_bw_scale.points[43].slot.mon");
    add_point_member("scale.g25","tb_bw_scale.points[44].slot.mon");
    add_point_member("scale.g25","tb_bw_scale.points[45].slot.mon");
    add_point_member("scale.g25","tb_bw_scale.points[46].slot.mon");
    add_point_member("scale.g25","tb_bw_scale.points[47].slot.mon");
    add_point_member("scale.g25","tb_bw_scale.points[48].slot.mon");
    add_point_member("scale.g26","tb_bw_scale.points[49].slot.mon");
    add_point_member("scale.g26","tb_bw_scale.points[50].slot.mon");
    add_point_member("scale.g26","tb_bw_scale.points[51].slot.mon");
    add_point_member("scale.g26","tb_bw_scale.points[52].slot.mon");
    add_point_member("scale.g26","tb_bw_scale.points[53].slot.mon");
    add_point_member("scale.g26","tb_bw_scale.points[54].slot.mon");
    add_point_member("scale.g26","tb_bw_scale.points[55].slot.mon");
    add_point_member("scale.g26","tb_bw_scale.points[56].slot.mon");
    add_point_member("scale.g27","tb_bw_scale.points[57].slot.mon");
    add_point_member("scale.g27","tb_bw_scale.points[58].slot.mon");
    add_point_member("scale.g27","tb_bw_scale.points[59].slot.mon");
    add_point_member("scale.g27","tb_bw_scale.points[60].slot.mon");
    add_point_member("scale.g27","tb_bw_scale.points[61].slot.mon");
    add_point_member("scale.g27","tb_bw_scale.points[62].slot.mon");
    add_point_member("scale.g27","tb_bw_scale.points[63].slot.mon");
    add_point_member("scale.g27","tb_bw_scale.points[64].slot.mon");
    add_point_member("scale.g28","tb_bw_scale.points[65].slot.mon");
    add_point_member("scale.g28","tb_bw_scale.points[66].slot.mon");
    add_point_member("scale.g28","tb_bw_scale.points[67].slot.mon");
    add_point_member("scale.g28","tb_bw_scale.points[68].slot.mon");
    add_point_member("scale.g28","tb_bw_scale.points[69].slot.mon");
    add_point_member("scale.g28","tb_bw_scale.points[70].slot.mon");
    add_point_member("scale.g28","tb_bw_scale.points[71].slot.mon");
    add_point_member("scale.g28","tb_bw_scale.points[72].slot.mon");
    add_point_member("scale.g29","tb_bw_scale.points[73].slot.mon");
    add_point_member("scale.g29","tb_bw_scale.points[74].slot.mon");
    add_point_member("scale.g29","tb_bw_scale.points[75].slot.mon");
    add_point_member("scale.g29","tb_bw_scale.points[76].slot.mon");
    add_point_member("scale.g29","tb_bw_scale.points[77].slot.mon");
    add_point_member("scale.g29","tb_bw_scale.points[78].slot.mon");
    add_point_member("scale.g29","tb_bw_scale.points[79].slot.mon");
    add_point_member("scale.g29","tb_bw_scale.points[80].slot.mon");
    add_point_member("scale.g30","tb_bw_scale.points[81].slot.mon");
    add_point_member("scale.g30","tb_bw_scale.points[82].slot.mon");
    add_point_member("scale.g30","tb_bw_scale.points[83].slot.mon");
    add_point_member("scale.g30","tb_bw_scale.points[84].slot.mon");
    add_point_member("scale.g30","tb_bw_scale.points[85].slot.mon");
    add_point_member("scale.g30","tb_bw_scale.points[86].slot.mon");
    add_point_member("scale.g30","tb_bw_scale.points[87].slot.mon");
    add_point_member("scale.g30","tb_bw_scale.points[88].slot.mon");
    add_point_member("scale.g31","tb_bw_scale.points[89].slot.mon");
    add_point_member("scale.g31","tb_bw_scale.points[90].slot.mon");
    add_point_member("scale.g31","tb_bw_scale.points[91].slot.mon");
    add_point_member("scale.g31","tb_bw_scale.points[92].slot.mon");
    add_point_member("scale.g31","tb_bw_scale.points[93].slot.mon");
    add_point_member("scale.g31","tb_bw_scale.points[94].slot.mon");
    add_point_member("scale.g31","tb_bw_scale.points[95].slot.mon");
    add_point_member("scale.g31","tb_bw_scale.points[96].slot.mon");
    wait(monitor_ready);
    if($time!=measurement_start_ticks || measurement_start_ticks==0)$fatal(1,"SCALE_READY_ORIGIN");
    $display("ACCEPTANCE_READY");$fflush();
    $display("SCALE_RUN_START points=%0d groups=%0d scopes=%0d edges=%0d end_ticks=%0d basis=%0d W=%0d S=%0d variant=%s waves=0",POINTS,GROUPS,SCOPES,EDGES,measurement_start_ticks+END_TICKS,BASIS,WIDTH,STRIDE,variant_name);
    #END_TICKS;deadline<=1;observation_end=1;
    wait(completed_scopes==SCOPES && resources_done==SCOPES);
    if($time!=measurement_start_ticks+END_TICKS || core_failure_pending())$fatal(1,"SCALE_FINAL_FAILURE");
    foreach(bw_test_storage_peak[resource])$display("TOPOLOGY_STORAGE resource=%s queue_high_water=%0d",resource,bw_test_storage_peak[resource]);
    $fclose(actual_fd);$fclose(resource_fd);$fclose(edge_fd);
    $display("SCALE_PASS points=%0d groups=%0d scopes=%0d checked_raw=%0d end_ticks=%0d",POINTS,GROUPS,completed_scopes,EDGES*SCOPES,$time);
    // The endpoint marker keeps its exact tick; one more representable slot
    // lets the final posted input generation close so the ending protocol
    // settles every scope normally instead of reporting an interruption.
    #1;
    $finish;
  end
  initial begin
    wait(monitor_ready);
    for(ref_u64 k=1;k<=EDGES;k++)begin
      #(measurement_start_ticks+clock_tick(k)-$time-1);input_edge=k;
      if(k==GATE_EDGE)begin
        slow_gate.resume_after_seq=GATE_EDGE;
        slow_gate.paused=1;
      end
      #1;clk=1;#1;clk=0;
      if(k%64==0)begin $display("TOPOLOGY_PROGRESS edge=%0d ticks=%0d",k,$time);$fflush();end
    end
  end
  initial begin
    wait(monitor_ready);
    for(ref_u64 n=1;n*1000000000<END_TICKS;n++)begin
      #1000000000;
      $display("SCALE_PROGRESS at_ticks=%0d input_edges_before=%0d",$time,rank_lt($time-measurement_start_ticks));
    end
  end

  initial slow_gate=bw_test_gate_for("scale.g8");
  initial begin : control_hold_arm
    wait(monitor_ready);
    #(measurement_start_ticks+CONTROL_HOLD_TICK-1-$time);
    slow_gate.resume_after_seq=SLOW_ACK;
    slow_gate.resume_after_groups.push_back("scale.g1");
    slow_gate.resume_after_groups.push_back("scale.g9");
    slow_gate.resume_after_groups.push_back("scale.g10");
    slow_gate.resume_after_groups.push_back("scale.g11");
    slow_gate.resume_after_groups.push_back("scale.g12");
    slow_gate.resume_after_groups.push_back("scale.g13");
    slow_gate.resume_after_groups.push_back("scale.g14");
    slow_gate.resume_after_groups.push_back("scale.g15");
    slow_gate.resume_after_groups.push_back("scale.g16");
    slow_gate.resume_after_groups.push_back("scale.g17");
    slow_gate.resume_after_groups.push_back("scale.g18");
    slow_gate.resume_after_groups.push_back("scale.g19");
    slow_gate.resume_after_groups.push_back("scale.g20");
    slow_gate.resume_after_groups.push_back("scale.g21");
    slow_gate.resume_after_groups.push_back("scale.g22");
    slow_gate.paused=1;
  end
  task automatic observe_interaction();
    bw_control_frame_t pending;
    bw_u64_t seen_controls;
    wait(monitor_ready);
    // Event one: the member reset release control is forwarded in its own
    // stamp slot; the held consumer keeps it unread in that original slot.
    // Waits use variables (function calls have no wait sensitivity).
    #(measurement_start_ticks+CONTROL_HOLD_TICK-1-$time);
    seen_controls=groups[0].slot.mon.control_result_seq;
    wait(groups[0].slot.mon.control_result_seq!=seen_controls);
    if(retained_control_count(groups[0].slot.mon.transport_source)!=1 ||
       retained_frame_count(groups[0].slot.mon.transport_source)!=0 ||
       registered_sources[groups[0].slot.mon.transport_source].control_acks[groups[8].slot.mon.group_handle]
         ==registered_sources[groups[0].slot.mon.transport_source].last_control_seq ||
       !peek_member_control(groups[8].slot.mon.group_handle,0,pending) ||
       pending.value.timestamp_ticks!=measurement_start_ticks+CONTROL_HOLD_TICK)
      $fatal(1,"TOPOLOGY_CONTROL_HOLD ticks=%0d controls=%0d",$time,
        retained_control_count(groups[0].slot.mon.transport_source));
    $display("TOPOLOGY_BACKLOG_CONTROL source=scale.g0 consumers=16 retained_controls=%0d retained_frames=0",
      retained_control_count(groups[0].slot.mon.transport_source));
    wait(registered_sources[groups[0].slot.mon.transport_source].control_acks[groups[8].slot.mon.group_handle]
         ==registered_sources[groups[0].slot.mon.transport_source].last_control_seq);
    if($time!=measurement_start_ticks+CONTROL_HOLD_TICK || retained_control_count(groups[0].slot.mon.transport_source)!=0)
      $fatal(1,"TOPOLOGY_CONTROL_RELEASE ticks=%0d",$time);
    $display("TOPOLOGY_CONTROL_RELEASE original_time=1 released_controls=1");
    // Event two: the gate edge slot holds the slot's own frame unread while
    // the fifteen fast peers already published, accepted and acked it.
    wait(group_batches["scale.g1"].acked>=203);
    wait(group_batches["scale.g9"].acked>=203);
    wait(group_batches["scale.g10"].acked>=203);
    wait(group_batches["scale.g11"].acked>=203);
    wait(group_batches["scale.g12"].acked>=203);
    wait(group_batches["scale.g13"].acked>=203);
    wait(group_batches["scale.g14"].acked>=203);
    wait(group_batches["scale.g15"].acked>=203);
    wait(group_batches["scale.g16"].acked>=203);
    wait(group_batches["scale.g17"].acked>=203);
    wait(group_batches["scale.g18"].acked>=203);
    wait(group_batches["scale.g19"].acked>=203);
    wait(group_batches["scale.g20"].acked>=203);
    wait(group_batches["scale.g21"].acked>=203);
    wait(group_batches["scale.g22"].acked>=203);
    if(groups[8].slot.mon.accepted_record_seq!=SLOW_ACK ||
       acknowledged_frame_seq(groups[8].slot.mon.group_handle,0)!=SLOW_ACK ||
       groups[0].slot.mon.accepted_record_seq!=GATE_EDGE ||
       retained_frame_count(groups[0].slot.mon.transport_source)!=HELD_FRAMES ||
       retained_control_count(groups[0].slot.mon.transport_source)!=0 ||
       groups[0].slot.mon.core.history.size()<4)
      $fatal(1,"TOPOLOGY_SAME_TIME_HOLD slow=%0d/%0d source=%0d frames=%0d/%0d",
        groups[8].slot.mon.accepted_record_seq,SLOW_ACK,groups[0].slot.mon.accepted_record_seq,
        retained_frame_count(groups[0].slot.mon.transport_source),HELD_FRAMES);
    if(BASIS==0 && groups[8].slot.mon.window_end_ticks>measurement_start_ticks+TIMER_BOUND_NS*1000000)
      $fatal(1,"TOPOLOGY_DELAY_TIMER_WATERMARK");
    if(BASIS==1 && groups[8].slot.mon.window_end_cycle>202)
      $fatal(1,"TOPOLOGY_DELAY_CYCLE_WATERMARK");
    $display("TOPOLOGY_BACKLOG source=scale.g0 consumers=16 fast_ack=%0d slow_ack=%0d retained_frames=%0d retained_controls=0 history_segments=%0d",
      GATE_EDGE,SLOW_ACK,HELD_FRAMES,groups[0].slot.mon.core.history.size());

    wait(group_batches["scale.g8"].acked>=GATE_EDGE);
    if($time!=measurement_start_ticks+RELEASE_TICK)$fatal(1,"TOPOLOGY_RELEASE_NOT_ORIGINAL_TIME ticks=%0d",$time);
    if(groups[8].slot.mon.accepted_record_seq!=GATE_EDGE ||
       acknowledged_frame_seq(groups[8].slot.mon.group_handle,0)!=GATE_EDGE ||
       retained_frame_count(groups[0].slot.mon.transport_source)!=0 ||
       retained_control_count(groups[0].slot.mon.transport_source)!=0)
      $fatal(1,"TOPOLOGY_SAME_TIME_RELEASE ticks=%0d",$time);
    $display("TOPOLOGY_INTERACTION_PASS original_time=1 all_consumers_released=1 basis=%0d",BASIS);
    $fflush();
  endtask
  initial begin : same_time_interaction
    observe_interaction();
  end
  always @(deadline or completed_scopes)if(deadline)begin
    SCALE_ALL_SCOPES_SETTLED:assert final(completed_scopes==SCOPES)else end_failure();
  end
  function automatic void end_failure();
    if(completed_scopes!=SCOPES)$fatal(1,"SCALE_END_INCOMPLETE completed=%0d expected=%0d time=%0d",completed_scopes,SCOPES,$time);
  endfunction
endmodule
