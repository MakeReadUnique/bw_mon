  // Cumulative receipts survive dequeue, lost wakeups, reset and shutdown.
  // Only the native raw-clock observer creates expected edges. The ledger
  // class lives in the registry types so sources hold their own handle.
  bw_point_batch point_batches[string];
  function automatic bit point_completion_failed(bw_point_batch batch);
    return core_failure_seen || monitoring_shared_disabled || batch.cancelled;
  endfunction
  function automatic void register_point_completion(string id);
    if(!point_batches.exists(id))begin
      point_batches[id]=new;
      if(point_by_id.exists(id))
        registered_sources[registered_points[point_by_id[id]].transport_source].point_ledger=point_batches[id];
    end
  endfunction
  function automatic void cancel_point_completion(string id);
    if(point_batches.exists(id))begin
      point_batches[id].cancelled=1;
      note_settlement_activity(BW_POINT,id);
    end
  endfunction
  function automatic void point_work_requested(string id,bw_u64_t grant,chandle watch=null,
                                               bw_point_batch ledger=null);
    bw_point_batch batch;
    if(!monitor_ready)return;
    if(ledger!=null)batch=ledger;
    else begin
      if(!point_batches.exists(id))return;
      batch=point_batches[id];
    end
    if(point_completion_failed(batch))return;
    if(batch.input_generation==BW_U64_MAX)begin
      runtime_scope_error(BW_POINT,id,"INTEGER_OVERFLOW","input generation exhausted");return;
    end
    batch.input_generation++;
    batch.grant=grant;
    // A watch-carrying request already marked this watcher dirty.
    if(watch==null)note_settlement_activity(BW_POINT,id);
  endfunction
  function automatic void expect_point_edge(string id,bw_u64_t ticks,chandle watch=null,
                                            bw_point_batch ledger=null);
    bw_point_batch batch;
    if(!monitor_ready || ticks<=measurement_start_ticks)return;
    if(ledger==null && scope_failed(BW_POINT,id))return;
    batch=ledger!=null ? ledger : point_batches[id];
    if(point_completion_failed(batch))return;
    if(batch.expected!=0 && ticks<=batch.ticks)begin
      runtime_scope_error(BW_POINT,id,"EDGE_TIME","actual sampling edges must have distinct increasing timestamps");return;
    end
    if(batch.expected==BW_U64_MAX || batch.input_generation==BW_U64_MAX)begin
      runtime_scope_error(BW_POINT,id,"INTEGER_OVERFLOW","expected-edge ledger exhausted");return;
    end
    batch.expected++;batch.input_generation++;batch.ticks=ticks;
    batch.grant=request_slot_settlement(id,watch);
  endfunction
  // Real workers pass their owner-held ledger. Component callers retain the
  // ID lookup; a missing cached watch retains the typed activity fallback.
  function automatic void point_capture_receipt(string id,bw_u64_t seq,bw_point_batch ledger=null);
    bw_point_batch batch;
    if(ledger!=null)batch=ledger;
    else begin if(!point_batches.exists(id))return;batch=point_batches[id];end
    if(point_completion_failed(batch))return;
    if(seq!=batch.captured+1)begin
      runtime_scope_error(BW_POINT,id,"CAPTURE_SEQUENCE","duplicate or out-of-order capture receipt");return;
    end
    batch.captured=seq;
    if(batch.settlement_watch!=null)bw_native_mark_settlement_watch(batch.settlement_watch);
    else note_settlement_activity(BW_POINT,id);
  endfunction
  function automatic void point_inflight_receipt(string id,bw_u64_t seq,bw_point_batch ledger=null);
    bw_point_batch batch;
    if(ledger!=null)batch=ledger;
    else begin if(!point_batches.exists(id))return;batch=point_batches[id];end
    if(point_completion_failed(batch))return;
    batch.inflight=seq;
    if(batch.settlement_watch!=null)bw_native_mark_settlement_watch(batch.settlement_watch);
    else note_settlement_activity(BW_POINT,id);
  endfunction
  function automatic void point_publication_receipt(string id,bw_u64_t seq,bw_point_batch ledger=null);
    bw_point_batch batch;
    if(ledger!=null)batch=ledger;
    else begin if(!point_batches.exists(id))return;batch=point_batches[id];end
    if(point_completion_failed(batch))return;
    batch.published=seq;
    if(batch.settlement_watch!=null)bw_native_mark_settlement_watch(batch.settlement_watch);
    else note_settlement_activity(BW_POINT,id);
  endfunction
  function automatic void point_core_receipt(string id,bw_u64_t seq,bw_point_batch ledger=null);
    bw_point_batch batch;
    if(ledger!=null)batch=ledger;
    else begin if(!point_batches.exists(id))return;batch=point_batches[id];end
    if(point_completion_failed(batch))return;
    batch.accepted=seq;
    if(batch.settlement_watch!=null)bw_native_mark_settlement_watch(batch.settlement_watch);
    else note_settlement_activity(BW_POINT,id);
    // A wakeup is expendable. The next coordinator audit reads this durable
    // receipt even when this advisory request is deliberately lost.
`ifdef BW_MON_TEST_FAULTS
    if(take_point_fault(id,"notice"))return;
`endif
    void'(request_slot_settlement(id,batch.settlement_watch));
  endfunction
  function automatic void close_point_batch(string id,bw_point_batch ledger=null);
    bw_point_batch batch;
    string stage;
    if(ledger!=null)batch=ledger;
    else begin
      if(!point_batches.exists(id))return;
      batch=point_batches[id];
    end
    if(point_completion_failed(batch))return;
    stage="";
    if(batch.captured!=batch.expected)stage="CAPTURE";
    else if(batch.inflight!=batch.expected)stage="INFLIGHT";
    else if(batch.published!=batch.expected)stage="PUBLICATION";
    else if(batch.accepted!=batch.expected)stage="CORE_RECEIPT";
    if(stage!="")begin
      runtime_scope_error(BW_POINT,id,"POINT_COMPLETION",$sformatf("stage=%s original_ticks=%0d edge=%0d captured=%0d inflight=%0d published=%0d accepted=%0d input_generation=%0d",stage,batch.ticks,batch.expected,batch.captured,batch.inflight,batch.published,batch.accepted,batch.input_generation));return;
    end
    batch.closed_generation=batch.input_generation;
    settle_target_requests(BW_POINT,id,batch.expected);
  endfunction
  function automatic bit point_batch_complete(string id);
    if(!point_batches.exists(id))return 0;
    return point_batches[id].closed_generation==point_batches[id].input_generation;
  endfunction
  typedef enum {BW_SCOPE_RUNNING,BW_SCOPE_NORMAL,BW_SCOPE_DISABLED,BW_SCOPE_INTERRUPTED,BW_SCOPE_UNOBSERVED} bw_scope_terminal_t;
  bw_scope_terminal_t scope_terminals[string];
  function automatic bw_scope_terminal_t scope_terminal_state(bw_scope_t kind,string id);
    if(scope_disabled(kind,id))return BW_SCOPE_DISABLED;
    if(!scope_terminals.exists(scope_key(kind,id)))return BW_SCOPE_RUNNING;
    return scope_terminals[scope_key(kind,id)];
  endfunction
  // Durable batch-ledger stage names for an interrupted ending.
  function automatic string point_batch_stage(string id);
    bw_point_batch batch;
    if(!point_batches.exists(id))return "UNREGISTERED";
    batch=point_batches[id];
    if(batch.captured!=batch.expected)return "CAPTURE";
    if(batch.inflight!=batch.expected)return "INFLIGHT";
    if(batch.published!=batch.expected)return "PUBLICATION";
    if(batch.accepted!=batch.expected)return "CORE_RECEIPT";
    if(batch.closed_generation!=batch.input_generation)return "GENERATION";
    return "NONE";
  endfunction
  function automatic void note_point_terminal(string id,bit actions_complete,string stage="");
    string state,key;
    bw_scope_terminal_t terminal;
    key=scope_key(BW_POINT,id);
    if(scope_terminals.exists(key))return;
    if(!point_batches.exists(id))point_batches[id]=new;
    if(scope_disabled(BW_POINT,id))begin terminal=BW_SCOPE_DISABLED;state="DISABLED";stage="MONITOR_DISABLED";end
    else if(!actions_complete || !point_batch_complete(id))begin
      terminal=BW_SCOPE_INTERRUPTED;state="INTERRUPTED";
      if(stage=="" || stage=="NONE")stage=point_batch_stage(id);
    end
    else if(point_batches[id].expected==0)begin terminal=BW_SCOPE_UNOBSERVED;state="UNOBSERVED";stage="NONE";end
    else begin terminal=BW_SCOPE_NORMAL;state="NORMAL";stage="NONE";end
    scope_terminals[key]=terminal;
    interrupt_target_requests(BW_POINT,id,terminal==BW_SCOPE_DISABLED);
    $display("BW_POINT_TERMINAL scope=%s state=%s expected=%0d captured=%0d inflight=%0d published=%0d accepted=%0d input_generation=%0d closed_generation=%0d time_ticks=%0d stage=%s",id,state,point_batches[id].expected,point_batches[id].captured,point_batches[id].inflight,point_batches[id].published,point_batches[id].accepted,point_batches[id].input_generation,point_batches[id].closed_generation,$time,stage);
  endfunction
