  // Group receipts are independent of the collector queues. Native actual
  // clock edges establish obligations even when capture or publication fails.
  // The ledger class lives in the registry types so groups hold their own
  // handle.
  bw_group_batch group_batches[string];
  function automatic void cancel_all_group_completion();
    foreach(group_batches[id])begin
      group_batches[id].cancelled=1;
      note_settlement_activity(BW_GROUP,id);
    end
  endfunction
  function automatic void register_group_completion(string id);
    if(!group_batches.exists(id))begin
      group_batches[id]=new;
      if(group_by_id.exists(id))begin
        registered_groups[group_by_id[id]].ledger=group_batches[id];
        registered_sources[registered_groups[group_by_id[id]].source_handle].group_ledger=group_batches[id];
      end
    end
  endfunction
  function automatic void group_work_requested(string id,bw_u64_t grant,chandle watch=null,
                                               bw_group_batch ledger=null);
    bw_group_batch batch;
    if(!monitor_ready)return;
    if(ledger!=null)batch=ledger;
    else begin
      if(!group_batches.exists(id))return;
      batch=group_batches[id];
    end
    if(scope_failed(BW_GROUP,id))return;
    if(batch.input_generation==BW_U64_MAX)begin
      runtime_scope_error(BW_GROUP,id,"INTEGER_OVERFLOW","group input generation exhausted");return;
    end
    batch.input_generation++;batch.grant=grant;
    // A watch-carrying request already marked this watcher dirty.
    if(watch==null)note_settlement_activity(BW_GROUP,id);
  endfunction
  function automatic void expect_group_edge(string id,bw_u64_t ticks,chandle watch=null,
                                            bw_group_batch ledger=null);
    bw_group_batch batch;
    if(!monitor_ready || ticks<=measurement_start_ticks || scope_failed(BW_GROUP,id))return;
    if(ledger!=null)batch=ledger;
    else begin
      if(!group_batches.exists(id))return;
      batch=group_batches[id];
    end
    if(batch.expected!=0 && ticks<=batch.ticks)begin runtime_scope_error(BW_GROUP,id,"GROUP_CLOCK","actual group edges must strictly increase");return;end
    if(batch.expected==BW_U64_MAX)begin runtime_scope_error(BW_GROUP,id,"INTEGER_OVERFLOW","group edge ledger exhausted");return;end
    batch.expected++;batch.ticks=ticks;
    group_work_requested(id,request_slot_settlement(id,watch,BW_GROUP),watch,batch);
  endfunction
  function automatic void group_reset_expected(string id);
    if(!group_batches.exists(id) || scope_failed(BW_GROUP,id))return;
    if(group_batches[id].reset_expected==BW_U64_MAX)begin runtime_scope_error(BW_GROUP,id,"INTEGER_OVERFLOW","group reset ledger exhausted");return;end
    group_batches[id].reset_expected++;
    note_settlement_activity(BW_GROUP,id);
  endfunction
  function automatic void group_reset_captured(string id);
    if(!group_batches.exists(id) || scope_failed(BW_GROUP,id))return;
    if(group_batches[id].reset_captured==BW_U64_MAX)begin runtime_scope_error(BW_GROUP,id,"INTEGER_OVERFLOW","group reset capture ledger exhausted");return;end
    group_batches[id].reset_captured++;
    note_settlement_activity(BW_GROUP,id);
  endfunction
  function automatic void group_core_receipt(string id,bw_u64_t seq);
    if(scope_failed(BW_GROUP,id))return;
    group_batches[id].accepted=seq;
`ifdef BW_MON_TEST_FAULTS
    if(take_group_fault(id,"notice"))return;
`endif
    group_work_requested(id,request_slot_settlement(id,null,BW_GROUP));
  endfunction
  function automatic bit group_batch_complete(string id);
    if(!group_batches.exists(id) || scope_failed(BW_GROUP,id) || group_batches[id].cancelled)return 0;
    return group_batches[id].input_generation==group_batches[id].closed_generation;
  endfunction
  function automatic bit group_producers_pending(int handle);
    bw_source_state source;
    foreach(registered_groups[handle].members[m])begin
      source=registered_sources[registered_groups[handle].members[m]];
      if(source_failed(source))continue;
      // Each source holds its own ledger handle from registration, avoiding
      // keyed lookups in this per-member audit check.
      if(source.kind==BW_POINT)begin
        if(source.point_ledger==null && point_batches.exists(source.id))
          source.point_ledger=point_batches[source.id];
        if(source.point_ledger!=null &&
           source.point_ledger.closed_generation!=source.point_ledger.input_generation)return 1;
      end
      else begin
        if(source.group_ledger==null && group_batches.exists(source.id))
          source.group_ledger=group_batches[source.id];
        // A cancelled ledger counts as complete, exactly like the keyed
        // group_batch_complete query the failure path relies on.
        if(source.group_ledger!=null && !source.group_ledger.cancelled &&
           source.group_ledger.closed_generation!=source.group_ledger.input_generation)return 1;
      end
    end
    return 0;
  endfunction
  function automatic void close_group_batch(string id,bw_group_batch ledger=null);
    bw_group_batch batch;
    string stage;
    if(scope_failed(BW_GROUP,id))return;
    if(ledger!=null)batch=ledger;
    else begin
      if(!group_batches.exists(id))return;
      batch=group_batches[id];
    end
    stage="";
    if(batch.captured!=batch.expected)stage="CAPTURE";
    else if(batch.held!=batch.expected)stage="HELD";
    else if(batch.published!=batch.expected)stage="PUBLICATION";
    else if(batch.accepted!=batch.expected)stage="CORE_RECEIPT";
    else if(batch.acked!=batch.expected)stage="INPUT_ACK";
    if(stage!="")begin
      runtime_scope_error(BW_GROUP,id,"GROUP_COMPLETION",$sformatf("stage=%s original_ticks=%0d edge=%0d captured=%0d held=%0d published=%0d accepted=%0d acked=%0d",stage,batch.ticks,batch.expected,batch.captured,batch.held,batch.published,batch.accepted,batch.acked));return;
    end
    batch.closed_generation=batch.input_generation;
    settle_target_requests(BW_GROUP,id,batch.expected);
  endfunction
  // Group twin of the point terminal: idempotent, evidence-based, and typed.
  // The owner passes its durable action evidence; the frozen batch ledger
  // decides NORMAL / UNOBSERVED / INTERRUPTED, never a queue-length proxy.
  function automatic void note_group_terminal(string id,bit actions_complete,string stage="");
    string state,key;
    bw_scope_terminal_t terminal;
    key=scope_key(BW_GROUP,id);
    if(scope_terminals.exists(key))return;
    if(!group_batches.exists(id))group_batches[id]=new;
    if(scope_disabled(BW_GROUP,id))begin terminal=BW_SCOPE_DISABLED;state="DISABLED";stage="MONITOR_DISABLED";end
    else if(!actions_complete || !group_batch_complete(id))begin terminal=BW_SCOPE_INTERRUPTED;state="INTERRUPTED";
      if(stage=="" || stage=="NONE")begin
        stage="GENERATION";
        if(group_batches[id].captured!=group_batches[id].expected)stage="CAPTURE";
        else if(group_batches[id].held!=group_batches[id].expected)stage="HELD";
        else if(group_batches[id].published!=group_batches[id].expected)stage="PUBLICATION";
        else if(group_batches[id].accepted!=group_batches[id].expected)stage="CORE_RECEIPT";
        else if(group_batches[id].acked!=group_batches[id].expected)stage="INPUT_ACK";
      end
    end
    else if(group_batches[id].expected==0)begin terminal=BW_SCOPE_UNOBSERVED;state="UNOBSERVED";stage="NONE";end
    else begin terminal=BW_SCOPE_NORMAL;state="NORMAL";stage="NONE";end
    scope_terminals[key]=terminal;
    interrupt_target_requests(BW_GROUP,id,terminal==BW_SCOPE_DISABLED);
    $display("BW_GROUP_TERMINAL scope=%s state=%s expected=%0d captured=%0d held=%0d published=%0d accepted=%0d acked=%0d reset_expected=%0d reset_captured=%0d input_generation=%0d closed_generation=%0d time_ticks=%0d stage=%s",
      id,state,group_batches[id].expected,group_batches[id].captured,group_batches[id].held,
      group_batches[id].published,group_batches[id].accepted,group_batches[id].acked,
      group_batches[id].reset_expected,group_batches[id].reset_captured,
      group_batches[id].input_generation,group_batches[id].closed_generation,$time,stage);
  endfunction
