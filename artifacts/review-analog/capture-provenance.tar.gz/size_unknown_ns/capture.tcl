if {[catch {
source {/tmp/bw-mon-spec13/wt-28/artifacts/review-analog/open-view.tcl}
wvSetDefaultValue -win $w -analogFormat Engineer -analogPrecision 12
set fd [open {/tmp/bw-mon-spec13-oct26/analog28/bw-analog-qaef32q4/values.tsv} w]
wvSetCursor -win $w 105.5
puts $fd "105.5\tp0_GBps\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/ports[0]/dut/mon/p0_GBps}]"
wvSetCursor -win $w 105.5
puts $fd "105.5\tall_dmc_GBps\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/all_dmc/all_dmc_GBps}]"
wvSetCursor -win $w 105.5
puts $fd "105.5\tp0_bytes_complete\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/ports[0]/dut/mon/p0_bytes_complete}]"
wvSetCursor -win $w 105.5
puts $fd "105.5\tp0_events_complete\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/ports[0]/dut/mon/p0_events_complete}]"
wvSetCursor -win $w 115.5
puts $fd "115.5\tp0_bytes_complete\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/ports[0]/dut/mon/p0_bytes_complete}]"
close $fd
wvSetDefaultValue -win $w -analogFormat Engineer -analogPrecision 2
wvSetCursor -win $w 105.5
set fd [open {/tmp/bw-mon-spec13-oct26/analog28/bw-analog-qaef32q4/ready} w]
puts $fd [wvGetXWindowId -id $w]
close $fd
set deadline [expr {[clock seconds] + 30}]
while {![file exists {/tmp/bw-mon-spec13-oct26/analog28/bw-analog-qaef32q4/capture-now}]} {
  if {[clock seconds] > $deadline} {error "capture handshake timeout"}
  after 100
  update
}
after 800
update
wvSaveSignal -win $w {/tmp/bw-mon-spec13-oct26/analog28/bw-analog-qaef32q4/reopened.sav}
wvCapture -win $w -file {/tmp/bw-mon-spec13/wt-28/artifacts/review-analog/size_unknown_ns.png}
wvExit

} err]} {puts stderr $err; puts stderr $errorInfo; wvExit}
