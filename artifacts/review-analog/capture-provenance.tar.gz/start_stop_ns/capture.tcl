if {[catch {
source {/tmp/bw-mon-spec13/wt-28/artifacts/review-analog/open-view.tcl}
wvSetDefaultValue -win $w -analogFormat Engineer -analogPrecision 12
set fd [open {/tmp/bw-mon-spec13-oct26/analog28/bw-analog-dg7vwb_9/values.tsv} w]
wvSetCursor -win $w 20
puts $fd "20\tp0_GBps\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/ports[0]/dut/mon/p0_GBps}]"
wvSetCursor -win $w 30
puts $fd "30\tp0_GBps\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/ports[0]/dut/mon/p0_GBps}]"
wvSetCursor -win $w 60
puts $fd "60\tp0_GBps\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/ports[0]/dut/mon/p0_GBps}]"
wvSetCursor -win $w 70
puts $fd "70\tp0_GBps\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/ports[0]/dut/mon/p0_GBps}]"
wvSetCursor -win $w 40
puts $fd "40\tall_dmc_GBps\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/all_dmc/all_dmc_GBps}]"
close $fd
wvSetDefaultValue -win $w -analogFormat Engineer -analogPrecision 2
wvSetCursor -win $w 40
set fd [open {/tmp/bw-mon-spec13-oct26/analog28/bw-analog-dg7vwb_9/ready} w]
puts $fd [wvGetXWindowId -id $w]
close $fd
set deadline [expr {[clock seconds] + 30}]
while {![file exists {/tmp/bw-mon-spec13-oct26/analog28/bw-analog-dg7vwb_9/capture-now}]} {
  if {[clock seconds] > $deadline} {error "capture handshake timeout"}
  after 100
  update
}
after 800
update
wvSaveSignal -win $w {/tmp/bw-mon-spec13-oct26/analog28/bw-analog-dg7vwb_9/reopened.sav}
wvCapture -win $w -file {/tmp/bw-mon-spec13/wt-28/artifacts/review-analog/start_stop_ns.png}
wvExit

} err]} {puts stderr $err; puts stderr $errorInfo; wvExit}
