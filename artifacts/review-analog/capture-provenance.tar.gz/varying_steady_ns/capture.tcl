if {[catch {
source {/tmp/bw-mon-spec13/wt-28/artifacts/review-analog/open-view.tcl}
wvSetDefaultValue -win $w -analogFormat Engineer -analogPrecision 12
set fd [open {/tmp/bw-mon-spec13-oct26/analog28/bw-analog-0a192c5q/values.tsv} w]
wvSetCursor -win $w 136.5
puts $fd "136.5\tp0_phase_candidate\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/ports[0]/dut/mon/p0_phase_candidate}]"
wvSetCursor -win $w 136.5
puts $fd "136.5\tp0_phase_confirmed\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/ports[0]/dut/mon/p0_phase_confirmed}]"
wvSetCursor -win $w 137.5
puts $fd "137.5\tp0_phase_confirmed\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/ports[0]/dut/mon/p0_phase_confirmed}]"
wvSetCursor -win $w 137.5
puts $fd "137.5\tp0_GBps\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/ports[0]/dut/mon/p0_GBps}]"
wvSetCursor -win $w 137.5
puts $fd "137.5\tall_dmc_GBps\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/all_dmc/all_dmc_GBps}]"
close $fd
wvSetDefaultValue -win $w -analogFormat Engineer -analogPrecision 2
wvSetCursor -win $w 138.5
set fd [open {/tmp/bw-mon-spec13-oct26/analog28/bw-analog-0a192c5q/ready} w]
puts $fd [wvGetXWindowId -id $w]
close $fd
set deadline [expr {[clock seconds] + 30}]
while {![file exists {/tmp/bw-mon-spec13-oct26/analog28/bw-analog-0a192c5q/capture-now}]} {
  if {[clock seconds] > $deadline} {error "capture handshake timeout"}
  after 100
  update
}
after 800
update
wvSaveSignal -win $w {/tmp/bw-mon-spec13-oct26/analog28/bw-analog-0a192c5q/reopened.sav}
wvCapture -win $w -file {/tmp/bw-mon-spec13/wt-28/artifacts/review-analog/varying_steady_ns.png}
wvExit

} err]} {puts stderr $err; puts stderr $errorInfo; wvExit}
