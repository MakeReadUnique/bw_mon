if {[catch {
source {/tmp/bw-mon-spec13/wt-28/artifacts/review-analog/open-view.tcl}
wvSetDefaultValue -win $w -analogFormat Engineer -analogPrecision 12
set fd [open {/tmp/bw-mon-spec13-oct26/analog28/bw-analog-x_gwhex5/values.tsv} w]
wvSetCursor -win $w 50
puts $fd "50\tp0_GBps\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/ports[0]/dut/mon/p0_GBps}]"
wvSetCursor -win $w 75
puts $fd "75\tp0_GBps\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/ports[0]/dut/mon/p0_GBps}]"
wvSetCursor -win $w 100
puts $fd "100\tp0_GBps\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/ports[0]/dut/mon/p0_GBps}]"
wvSetCursor -win $w 138
puts $fd "138\tp0_GBps\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/ports[0]/dut/mon/p0_GBps}]"
wvSetCursor -win $w 50
puts $fd "50\tall_dmc_GBps\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/all_dmc/all_dmc_GBps}]"
wvSetCursor -win $w 75
puts $fd "75\tall_dmc_GBps\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/all_dmc/all_dmc_GBps}]"
close $fd
wvSetDefaultValue -win $w -analogFormat Engineer -analogPrecision 2
wvSetCursor -win $w 50
set fd [open {/tmp/bw-mon-spec13-oct26/analog28/bw-analog-x_gwhex5/ready} w]
puts $fd [wvGetXWindowId -id $w]
close $fd
set deadline [expr {[clock seconds] + 30}]
while {![file exists {/tmp/bw-mon-spec13-oct26/analog28/bw-analog-x_gwhex5/capture-now}]} {
  if {[clock seconds] > $deadline} {error "capture handshake timeout"}
  after 100
  update
}
after 800
update
wvSaveSignal -win $w {/tmp/bw-mon-spec13-oct26/analog28/bw-analog-x_gwhex5/reopened.sav}
wvCapture -win $w -file {/tmp/bw-mon-spec13/wt-28/artifacts/review-analog/varying_ns.png}
wvExit

} err]} {puts stderr $err; puts stderr $errorInfo; wvExit}
