if {[catch {
source {/tmp/bw-mon-spec13/wt-28/artifacts/review-analog/open-view.tcl}
wvSetDefaultValue -win $w -analogFormat Engineer -analogPrecision 12
set fd [open {/tmp/bw-mon-spec13-oct26/analog28/bw-analog-all3wga2/values.tsv} w]
wvSetCursor -win $w 105.5
puts $fd "105.5\tp0_GBps\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/ports[0]/dut/mon/p0_GBps}]"
wvSetCursor -win $w 105.5
puts $fd "105.5\tall_dmc_GBps\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/all_dmc/all_dmc_GBps}]"
wvSetCursor -win $w 105.5
puts $fd "105.5\tp0_epoch\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/ports[0]/dut/mon/p0_epoch}]"
wvSetCursor -win $w 105.5
puts $fd "105.5\tall_dmc_epoch\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/all_dmc/all_dmc_epoch}]"
wvSetCursor -win $w 105.5
puts $fd "105.5\tp0_window_full\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/ports[0]/dut/mon/p0_window_full}]"
wvSetCursor -win $w 105.5
puts $fd "105.5\tall_dmc_member_reset\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/all_dmc/all_dmc_member_reset}]"
wvSetCursor -win $w 115.5
puts $fd "115.5\tp0_window_full\t[wvGetCurValueString -win $w {/tb_acceptance_ns/scene/ports[0]/dut/mon/p0_window_full}]"
close $fd
wvSetDefaultValue -win $w -analogFormat Engineer -analogPrecision 2
wvSetCursor -win $w 105.5
set fd [open {/tmp/bw-mon-spec13-oct26/analog28/bw-analog-all3wga2/ready} w]
puts $fd [wvGetXWindowId -id $w]
close $fd
set deadline [expr {[clock seconds] + 30}]
while {![file exists {/tmp/bw-mon-spec13-oct26/analog28/bw-analog-all3wga2/capture-now}]} {
  if {[clock seconds] > $deadline} {error "capture handshake timeout"}
  after 100
  update
}
after 800
update
wvSaveSignal -win $w {/tmp/bw-mon-spec13-oct26/analog28/bw-analog-all3wga2/reopened.sav}
wvCapture -win $w -file {/tmp/bw-mon-spec13/wt-28/artifacts/review-analog/point_reset_ns.png}
wvExit

} err]} {puts stderr $err; puts stderr $errorInfo; wvExit}
